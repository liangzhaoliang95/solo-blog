title: One Day One Words - 2023
date: '2023-04-10 20:02:42'
updated: '2025-01-25 12:27:33'
tags: [随便写写]
permalink: /articles/2023/04/10/1681128162515.html
---
![](https://b3logfile.com/bing/20201029.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
2025-01-25 不等和等下去，同样苦涩。
```

