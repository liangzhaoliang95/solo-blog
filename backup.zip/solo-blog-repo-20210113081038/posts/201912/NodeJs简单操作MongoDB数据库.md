title: NodeJs--简单操作MongoDB数据库
date: '2019-12-12 12:00:46'
updated: '2019-12-12 12:00:46'
tags: [NodeJs, Mongo]
permalink: /articles/2019/12/12/1576123246925.html
---
## NodeJs--简单操作MongoDB数据库

1. 引入NPM包（mongoose）

2. 传入数据库连接地址创建连接

3. 构建文档模型

4. 根据文档密模型查询数据

5. 高级查询请自行查阅官方文档

```
var mongoose = require('mongoose');
mongoose.Promise = global.Promise;
mongoose.connect("mongodb://userName:passWord@host:port/database?authSource=authBase", {useNewUrlParser: true, reconnectTries: Number.MAX_VALUE, useCreateIndex:true});
mongoose.connection;
var Schema = mongoose.Schema;
var schema = new Schema({
	id: String,
	z:String,
});
var m = mongoose.model('m3u8', schema, 'm3u8');
async function  test() {
	let rs = await m.find({})
	console.log(rs)
}
test()

```

结果如下
![image.png](https://img.hacpai.com/file/2019/12/image-dc5fc22e.png)
![image.png](https://img.hacpai.com/file/2019/12/image-63bc63cf.png)


