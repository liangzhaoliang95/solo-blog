title: NodeJs--简单操作mysql数据库
date: '2019-12-12 11:57:52'
updated: '2019-12-12 11:57:52'
tags: [NodeJs, Mysql]
permalink: /articles/2019/12/12/1576123072715.html
---
## Node操作Mysql数据库

1. 引入NPM包（mysql2），此组件采用promise，方便使用async

2. 传入连接配置创建连接池

3. 构建SQL并执行

4. 具体高级用法，请自行查阅官方文档
```
const mysql = require('mysql2');
var DB = mysql.createPool(
	{host: "xxx.xxx.xxx.xxx",
		port: 3306,
		user: "root",
		password: "xxxxxxxx",
		connectionLimit: 5,
		database: "study",
		charset: 'utf8mb4'}
).promise();
async function test () {
	let sql = `select * from teacher `
	let rs = await DB.query(sql)
	console.log(rs[0])
}
test()
```
输出如下
![image.png](https://img.hacpai.com/file/2019/12/image-27ca597e.png)

![image.png](https://img.hacpai.com/file/2019/12/image-0d7d9fd4.png)

