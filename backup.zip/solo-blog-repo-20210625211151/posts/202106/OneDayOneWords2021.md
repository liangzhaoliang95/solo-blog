title: One Day One Words - 2021
date: '2021-06-25 14:53:25'
updated: '2021-06-25 15:21:16'
tags: [随便写写]
permalink: /articles/2021/06/25/1624604005727.html
---
![](https://b3logfile.com/bing/20191010.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)
```
2021-06-25 按照自己的内在心灵轨道往前走，不要被人推着赶着往前走。知道自己是个什么样的人。知道什么样的生活适合自己。知道在任何一种结果来临之前，我们必然要付出很多播种与耕耘。
```
