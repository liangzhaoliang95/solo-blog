title: Mysql & Mariadb 新建用户并授权
date: '2019-08-26 14:47:43'
updated: '2019-08-26 14:47:43'
tags: [Mysql]
permalink: /MysqlnewUser
---
### 方法一：
```
create user newuser@localhost identified by '123456';
flush privileges;
```
此时新建的用户只有本地登录，如需全IP访问，将localhost改为%即可

### 方法二：
```
insert into mysql.user(user,host,password) values('ggo','localhost',password('1234'));
flush privileges;
```
此时新建的用户只有本地登录，如需全IP访问，将localhost改为%即可


### 新建一个my用户并且授权全部操作权限

```
 grant all privileges on *.* to my@localhost identified by '123456';
 flush privileges;
```

### 指定部分授权

```
 grant insert,update,delete,select on *.* to mytest@localhost;
 flush privileges;
```

### 小提示

1.如果需要全网使用，只需将localhost改为%或者指定IP
2.创建完用户或者赋予完权限后需要用flush privileges 去更新权限
