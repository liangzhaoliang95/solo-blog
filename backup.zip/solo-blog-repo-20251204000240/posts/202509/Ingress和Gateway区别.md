title: Ingress和Gateway区别
date: '2025-09-05 11:51:05'
updated: '2025-09-05 11:51:05'
tags: [k8s]
permalink: /articles/2025/09/05/1757044265139.html
---
Kubernetes 中的两个重要流量入口组件：**Ingress** 和 **Gateway**。它们用于将外部请求从集群之外接入到你的集群内部服务，是你设计服务网关、API 入口、安全边界管理、流量控制等的重要组成部分。

---

## 📌 一句话理解

| 名称     | 一句话解释 |
|----------|-------------|
| Ingress  | 基于第七层 HTTP/HTTPS 的流量接入控制器 |
| Gateway (Gateway API) | 下一代更通用更强大的流量接入和扩展标准，支持 L4/L7 |

---

## 🧠 Ingress 是啥？

### Ingress 是 Kubernetes 的一种资源类型，用于配置 HTTP 路由规则。

它按规则路由“︳外部请求➡集群内部服务”。

---

### 🧱 Ingress 的关键组件：

1. **Ingress资源（Ingress Object）**
   
   - 写在 YAML 中，定义域名/路径如何转发到对应 service
   - 只能管 L7（HTTP），不支持 TCP/UDP
2. **Ingress Controller**
   
   - 实际负责流量接入的控制器，比如：
     - `nginx-ingress-controller` ✅（最流行）
     - `traefik`（也同时支持 L4）
     - `alb-ingress-controller`（专用于 AWS）
   - 它监听 Kubernetes API 中的所有 Ingress 对象并创建/更新负载均衡规则等

---

### ✅ Ingress 示例

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: my-ingress
spec:
  rules:
    - host: example.com
      http:
        paths:
          - path: /api
            pathType: Prefix
            backend:
              service:
                name: my-api-service
                port:
                  number: 80
```

这个规则意味着：

> 用户访问 `http://example.com/api` 会转发到服务 `my-api-service:80`

---

### 🚫 Ingress限制：

| 限制点 | 说明 |
|--------|------|
| 仅支持 HTTP/HTTPS | 无法转 TCP/UDP、gRPC、WebSocket 控制能力弱 |
| 扩展性较差 | 想支持 header-based routing、认证、WAF 等，需要特定实现支持 |
| 不统一 | 各家 Ingress Controller 有差异，无法统一配置跨云、跨集群 |

---

## 🧠 Gateway 是啥？（Gateway API）

> Gateway 是 Kubernetes 官方提出的 **下一代统一流量入口标准** —— Gateway API。

2019 开始构思，2023 起逐渐成熟（v1beta1 版本已出）

---

### 🌟 Gateway 的特点：

| 特点 | 描述 |
|------|------|
| ✨ 标准化定义 接入方式 | 官方定义了 HTTP、TCP、TLS 等控制规范 |
| 🧱 组件解耦 | Gateway、Route、Listener、Backend，职责分离，层级清晰 |
| 🤖 可扩展 | 支持自定义路由、插件、负载策略等 |
| 🧩 插件式架构 | 各种 Provider（如 Istio, Envoy, Nginx）都可以实现支持 |
| ✅ 支持 L4/L7  | 不仅支持 HTTP，还支持 TCP、TLS 等流量转发 |

---

### 🚀 Gateway 架构组件（四大资源）

| 组件 | 功能 |
|------|------|
| GatewayClass | 定义网关控制器类型（比如 nginx / envoy） |
| Gateway      | 网关实例，定义公网/内网监听的地址、端口 |
| HTTPRoute / TCPRoute | 路由规则 |
| Service      | 你的业务服务 |

---

### Gateway 示例 YAML

```yaml
apiVersion: gateway.networking.k8s.io/v1beta1
kind: Gateway
metadata:
  name: my-gateway
spec:
  gatewayClassName: nginx
  listeners:
    - name: http
      port: 80
      protocol: HTTP
      hostname: "api.example.com"
      allowedRoutes:
        namespaces:
          from: All
```

```yaml
apiVersion: gateway.networking.k8s.io/v1beta1
kind: HTTPRoute
metadata:
  name: route-to-api
spec:
  parentRefs:
    - name: my-gateway
  rules:
    - matches:
        - path:
            type: PathPrefix
            value: /v1
      backendRefs:
        - name: my-api-service
          port: 80
```

---

## ✅ Ingress vs Gateway 对比总结：

| 维度         | Ingress                    | Gateway API                      |
|--------------|----------------------------|----------------------------------|
| 成熟度       | 稳定（已广泛使用）         | 发展中（v1beta1）                |
| 技术层级     | L7 (HTTP/HTTPS)            | 支持 L4/L7（HTTP/TCP/TLS/UDP）   |
| 插件扩展性   | 差，控制器特定实现         | 标准跨控制器扩展机制             |
| 控制粒度     | 较粗粒度                   | 多层配置、跨命名空间更优雅       |
| 多协议能力   | 仅支持 HTTP                | ✅ 支持 TLS、TCP、UDP            |
| 解耦程度     | 低，服务耦合在 Ingress 中  | 高，Gateway / Route 独立配置     |
| 云原生趋势   | 逐渐被 Gateway 替代        | ✅ 和 Istio / Linkerd 等轻松集成 |

---

## 💡 哪个更适合你？

| 使用场景       | 建议方案            |
|----------------|---------------------|
| 简单 HTTP 接入 | Ingress 足够         |
| 高级路由控制   | Gateway 推荐         |
| 跨命名空间共享网关 | Gateway            |
| 统一 API 入口、安全策略分离 | Gateway ✅ |
| 你已在用 Istio | Gateway 强烈推荐（原生支持）|

---

## 🔧 DevOps / SRE 补充建议

✅ 在生产中：

- **Ingress 适合中小型集群/简单路由**
- **Gateway 适合原生服务网格、API Gateway、跨团队治理场景**
- 如果你使用 cert-manager，可将 TLS 自动 / 动态配置结合 Gateway 使用
- Traefik / Istio / nginx 都支持 Gateway controller 插件化部署

---

## 🌟 总结图

```
+----------------------+
        |   External Traffic   |
        +----------+-----------+
                   |
+-----------------------------------------------+
| Ingress (HTTP)               (old, limited)    |
| Gateway API (HTTP, TCP, TLS) (new, scalable)  |
+-------------+----------------+----------------+
              |                |
            Service         Route (HTTP/TCP)
               \              /
                +-----------+
                    Pod / Workload
```



