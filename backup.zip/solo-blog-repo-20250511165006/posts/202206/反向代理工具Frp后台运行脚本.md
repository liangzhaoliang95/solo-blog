title: 反向代理工具Frp后台运行脚本
date: '2022-06-10 17:45:03'
updated: '2022-06-13 12:16:13'
tags: [linux]
permalink: /frpStartShell
---
后台运行FRP的shell脚本

```
# /bin/sh

nohup /usr/src/frp/frps -c /usr/src/frp/frps.ini &
```

FRP服务端配置文件示例

```
[common]

bind_port = 7000

dashboard_port = 7500

# dashboard 用户名密码，默认都为 admin

dashboard_user = admin

dashboard_pwd = @@@@面板密码

admin_addr = 127.0.0.1

admin_port = 7400

admin_user = admin

admin_pwd = @@@@连接密码
```

