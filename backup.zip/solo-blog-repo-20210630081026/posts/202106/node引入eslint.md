title: node引入eslint
date: '2021-06-28 15:44:18'
updated: '2021-06-28 15:44:18'
tags: [NodeJs]
permalink: /articles/2021/06/28/1624866258147.html
---
# 引入eslint

## 1. 配置.eslintrc.js文件

```
此文件用来配置eslint代码检查时的规则
```

```
module.exports = {
    "env": {
        "es2021": true,
        "commonjs": true,
        "node": true
    },
    "extends": [
        "eslint:recommended"
    ],
    "parser": "@typescript-eslint/parser",
    "parserOptions": {
        "ecmaVersion": 12
    },
    "plugins": [
        "@typescript-eslint"
    ],
    "rules": {
        "no-console": ["off"], //检查代码中的console
        "no-unused-vars": ["off"], //未定义的变量
        "no-useless-escape": ["off"], //不必要的字符转义
        "no-prototype-builtins": ["warn"], //禁止直接调用 Object.prototypes 的内置属性
        "no-constant-condition": ["warn"] //禁止在条件中使用常量表达式 while(true) 这种
    }
};
```

规则可配置为off,warn,error三个级别

```
off:忽略提示
warn:忽略提示，打印警告信息
error:中断代码检查，需强制修改代码
```

更详细的规则可参考 https://eslint.bootcss.com/docs/rules/

## 2. 配置.eslintignore文件

```
此文件是用来配置免检查的目录或者文件
```

```
# Created by .ignore support plugin (hsz.mobi)
### Example user template template
### Example user template

# IntelliJ project files
.idea
dist
node_modules
src/support
src/tempTest
src/cache
src/grpc-datacenter
src/grpc
src/mq
src/mongo
src/moduleTest
src/health
```

## 3. package.json引入eslint依赖

```
"eslint": "^7.28.0",
    "@typescript-eslint/eslint-plugin": "^4.27.0",
    "@typescript-eslint/parser": "^4.27.0",
```

## 4. 编译前置检查

修改package.json文件,配置prestart

```
"scripts": {
    "test": "jest",
    "prestart": "eslint src && cnpm run build",
    "start": "cross-env NODE_PATH=dist node dist/ts.js ",
    "build": "tsc -p .",
    "postbuild": "cpy src/grpc-datacenter/src/main/proto dist/grpc-datacenter/src/main/proto",
    "lint": "eslint src"
  },
```



