title: K8S相关命令
date: '2022-06-10 17:45:03'
updated: '2022-06-10 17:45:03'
tags: [Solo]
permalink: /articles/2021/06/28/1624866121392.html
---
![](https://b3logfile.com/bing/20171202.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
kubectl get deployment -owide -ndev  //获取服务

kubectl rollout restart deployment/wxopen -ntest //重启服务

kubectl set image deployment/bill main=docker.plaso.cn/bill:5.06.061170ba -ntest //发布服务

kubectl -ndev exec -it -c main timetable-55b5bc46-5w7ml -- sh //进入容器

kubectl.exe logs -f -ndev wxopen-6d57d9987-8ttsn -c main //查看日志

kubectl.exe -ndev get pod | grep -E "boss.*Running" | awk '{print $1}' | head -1

kubectl -n test logs -f wxopen-8bb794fb-wb466 main // 查看日志
```



