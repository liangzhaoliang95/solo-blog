title: MongoDB启动和停止脚本示例
date: '2022-06-10 17:45:03'
updated: '2022-06-10 17:45:03'
tags: [Solo]
permalink: /mongoShell
---
**启动脚本**
```
#!/bin/sh

cd /usr/src/mongodb

./bin/mongod -f mongodb.conf
```
**停止脚本**
```
# /bin/sh

cd /usr/src/mongodb

./bin/mongod --shutdown --dbpath ./db
```
**MongoDB配置文件**
```
port=27017 #端口  

dbpath=/usr/src/mongodb/db #数据库存文件存放目录  

logpath=/usr/src/mongodb/mongodb.log #日志文件存放路径  

logappend=true #使用追加的方式写日志  

fork=true#不以守护程序的方式启用，即不在后台运行  

maxConns=100#最大同时连接数  

auth=true#不启用验证  

journal=true#每次写入会记录一条操作日志（通过journal可以重新构造出写入的数据）。

#即使宕机，启动时wiredtiger会先将数据恢复到最近一次的checkpoint点，然后重放后续的journal日志来恢复。

storageEngine=wiredTiger#存储引擎有mmapv1、wiretiger、mongorocks

bind_ip=0.0.0.0#这样就可外部访问了，例如从win10中去连虚拟机中的MongoDB
```
