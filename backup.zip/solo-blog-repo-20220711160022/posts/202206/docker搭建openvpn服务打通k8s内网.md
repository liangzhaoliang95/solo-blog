title: docker搭建openvpn服务，打通k8s内网
date: '2022-06-10 17:45:03'
updated: '2022-06-10 17:45:03'
tags: [docker, Linux]
permalink: /articles/2021/12/07/1638857872489.html
---
## 1.下载

```
docker pull kylemanna/openvpn
```

## 2.全局变量(方便设置)

```
OVPN_DATA="/root/ovpn-data"
// 下面的全局变量换成你的服务器的外网ip
IP="xxx.xxx.xxx.xxx"
```

## 3.创建文件目录

```
mkdir ${OVPN_DATA}
```

## 4.配置

```
docker run -v ${OVPN_DATA}:/etc/openvpn --rm kylemanna/openvpn ovpn_genconfig -u tcp://${IP}
```

## 5.初始化

```
docker run -v ${OVPN_DATA}:/etc/openvpn --rm -it kylemanna/openvpn ovpn_initpki

Enter PEM pass phrase: 输入123456（你是看不见的） 
Verifying - Enter PEM pass phrase: 输入123456（你是看不见的） 
Common Name (eg: your user, host, or server name) [Easy-RSA CA]:回车一下 
Enter pass phrase for /etc/openvpn/pki/private/ca.key:输入123456
```

## 5.创建用户

```
docker run -v ${OVPN_DATA}:/etc/openvpn --rm -it kylemanna/openvpn easyrsa build-client-full CLIENTNAME nopass

Enter pass phrase for /etc/openvpn/pki/private/ca.key:输入123456
```

## 6.生成密钥

```
docker run -v ${OVPN_DATA}:/etc/openvpn --rm kylemanna/openvpn ovpn_getclient CLIENTNAME > ${OVPN_DATA}/CLIENTNAME.ovpn
```

## 7.生成docker容器

```
docker run --name openvpn -v ${OVPN_DATA}:/etc/openvpn -d -p 1194:1194 --privileged kylemanna/openvpn
```

### 撤销签署的证书(删除用户)

```
进入docker

easyrsa revoke client1 
easyrsa gen-crl 
cp /etc/openvpn/pki/crl.pem /etc/openvpn/crl.pem 
编辑${OVPN_DATA}/openvpn.conf 

crl-verify /etc/openvpn/crl.pe 
重启Docker
```

