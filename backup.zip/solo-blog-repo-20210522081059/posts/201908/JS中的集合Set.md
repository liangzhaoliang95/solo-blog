title: JS中的集合：Set
date: '2019-08-27 10:26:29'
updated: '2019-08-27 10:26:29'
tags: [JavaScript]
permalink: /JavaScriptSet
---
Set是ES6新出的一种数据结构，类似数组，但是不元素不能有重复，出现重复元素会丢弃重复元素
```
const set1 = new Set([1, 2, 3, 4, 5]);
```

### Set的常用方法

1. *`Set.prototype.add()`*
add() 方法用来向一个 Set 对象的末尾添加一个指定的值。并且返回Set本身
```
var mySet = new Set();

mySet.add(1);
mySet.add(5).add("some text"); // 可以链式调用

console.log(mySet);
// Set [1, 5, "some text"]

mySet.add(5).add(1);
console.log(mySet);
//Set [1, 5]  // 重复的值没有被添加进去
```


2. *`Set.prototype.delete()`*
删除Set中指定的元素，删除成功返回true，删除失败返回false
```
var mySet = new Set();
mySet.add("foo");

mySet.delete("bar"); // 返回 false，不包含 "bar" 这个元素
mySet.delete("foo"); // 返回 true，删除成功

mySet.has("foo");    // 返回 false，"foo" 已经成功删除
```

3. *`Set.prototype.forEach()`*
`forEach` 方法会依次为集合中的元素执行回调函数，就算元素的值是 `undefined `。回调函数有三个参数: 元素的值、元素的索引、正在遍历的集合对象。但是由于集合对象中没有索引(keys)，所以前两个参数都是[`Set`](https://developer.mozilla.org/zh-CN/docs/Web/API/Set "此页面仍未被本地化, 期待您的翻译!")中元素的值(**values**)，之所以这样设计回调函数是为了和[`Map`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map/foreach "forEach() 方法将会以插入顺序对 Map 对象中的每一个键值对执行一次参数中提供的回调函数。") 以及[`Array`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach "forEach() 方法对数组的每个元素执行一次提供的函数。")的 `forEach` 函数用法保持一致。如果提供了一个 `thisArg` 参数给 `forEach` 函数，则参数将会作为回调函数中的 `this`值。否则 `this` 值为 `undefined`。回调函数中 `this` 的绑定是根据[函数被调用时通用的 `this` 绑定规则来决定的](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Operators/this)。
`forEach` 函数为集合对象中每个元素都执行一次回调；它不会返回任何值。
```
function logSetElements(value1, value2, set) {
    console.log("s[" + value1 + "] = " + value2);
}

new Set(["foo", "bar", undefined]).forEach(logSetElements);
```
4. *`Set.prototype.clear()`*
清除Set中的所有元素
```
var mySet = new Set();
mySet.add(1);
mySet.add("foo");

mySet.size;       // 2
mySet.has("foo"); // true

mySet.clear();

mySet.size;       // 0
mySet.has("bar")  // false
```
