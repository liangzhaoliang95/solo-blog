title: node引入eslint
date: '2021-06-28 15:44:18'
updated: '2021-07-08 15:30:02'
tags: [NodeJs]
permalink: /articles/2021/06/28/1624866258147.html
---
# 引入eslint

## 1. 配置.eslintrc.js文件

```
此文件用来配置eslint代码检查时的规则
可以使用`eslint --init`自动生成
```

```
module.exports = {
	"env": {
		"es2021": true,
		"commonjs": true,
		"node": true
	},
	"extends": [
		"eslint:recommended", //使用官方建议规则js
		'plugin:@typescript-eslint/recommended'//ts 官方建议规则
	],
	"parser": "@typescript-eslint/parser",
	"parserOptions": {
		"ecmaVersion": 12
	},
	"plugins": [
		"@typescript-eslint"
	],
	"rules": {
		"no-console": ["error"], //检查代码中的console
		"no-unused-vars": ["off"], //未定义的变量
		"no-useless-escape": ["off"], //不必要的字符转义
		"no-prototype-builtins": ["off"], //禁止直接调用 Object.prototypes 的内置属性
		"no-constant-condition": ["off"], //禁止在条件中使用常量表达式 while(true) 这种
		"@typescript-eslint/no-var-requires": ["off"],//禁止使用require引入
		"@typescript-eslint/no-explicit-any": ["off"], //关闭any警告
		"@typescript-eslint/no-empty-interface": ["off"],//禁止空接口
		"@typescript-eslint/explicit-module-boundary-types":["off"],//ts每个函数都要显式声明返回值
		"@typescript-eslint/no-unused-vars":["warn"],//参数定义，却未使用
		"@typescript-eslint/no-empty-function":["off"],//函数体禁止空
		"@typescript-eslint/no-this-alias":["error",{
			"allowDestructuring": true, // Allow `const { props, state } = this`; false by default
			"allowedNames": ["that"] // Allow `const that= this`; `[]` by default
		}],//禁止this
	}
};
```

规则可配置为`off`,`warn`,`error`三个级别

```
off:忽略提示
warn:忽略提示，打印警告信息
error:中断代码检查，需强制修改代码
```

更详细的规则可参考 https://eslint.bootcss.com/docs/rules/

## 2. 配置.eslintignore文件

```
此文件是用来配置免检查的目录或者文件
```

```
# Created by .ignore support plugin (hsz.mobi)
### Example user template template
### Example user template

# IntelliJ project files
.idea
dist
node_modules
src/support
src/tempTest
src/cache
src/grpc-datacenter
src/grpc
src/mq
src/mongo
src/moduleTest
src/health
```

## 3. package.json引入eslint依赖

```
"eslint": "^7.28.0",
    "@typescript-eslint/eslint-plugin": "^4.27.0",
    "@typescript-eslint/parser": "^4.27.0", //将 TypeScript 转换成与 estree 兼容的形式，以便在ESLint中使用。
```

## 4. 编译前置检查

修改package.json文件,配置prestart

```
"scripts": {
    "test": "jest",
    "prestart": "eslint src && cnpm run build",
    "start": "cross-env NODE_PATH=dist node dist/ts.js ",
    "build": "tsc -p .",
    "postbuild": "cpy src/grpc-datacenter/src/main/proto dist/grpc-datacenter/src/main/proto",
    "lint": "eslint src"
  },
```



