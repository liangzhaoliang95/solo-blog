title: One Day One Words - 2023
date: '2023-04-10 20:02:42'
updated: '2023-04-11 08:05:00'
tags: [随便写写]
permalink: /articles/2023/04/10/1681128162515.html
---
![](https://b3logfile.com/bing/20191010.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
2023-04-11 我说，处不来，但是还得处，接着处，往死里处，这就是血缘关系。
```
```
2023-04-10 当你谈论它时，伤口就会愈合。
```
