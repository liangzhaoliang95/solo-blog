title: docker 常用命令
date: '2019-10-11 11:38:00'
updated: '2019-10-11 11:38:00'
tags: [docker]
permalink: /articles/2019/10/11/1570765080889.html
---
deploy.js -docker -release -v4.66.001 打包docker镜像
docker ps  查看docker启动的服务状态
docker exec -it  (docker id/name) sh   进入docker虚拟机
docker stop/start/restart  (docker id/name)   停止启动服务
DIR=www1 docker-compose -f docker-compose.yml -p www1 up -d      启动本项目服务
DIR=www1 docker-compose -f docker-compose.yml -p www1 down      停止本项目服务
docker state 查看占用资源
