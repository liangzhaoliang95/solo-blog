title: Promise、async、await执行顺序
date: '2022-06-10 17:45:03'
updated: '2022-06-10 17:45:03'
tags: [NodeJs, JavaScript]
permalink: /articles/2019/12/26/1577346362517.html
---
```
async function async1() {
    console.log("async1 start");
    await async2()
    console.log("async1 end");
};

async function async2() {
    console.log("async2 start");
    await async3();
    console.log("async2 end");
};

async function async3() {
    console.log("async3 start");
};

setTimeout(function () {
    console.log('setTimeout0');
}, 0);

console.log("start");

async1();

new Promise(function (resolve) {
    console.log("Promise1");
    resolve();
}).then(function () {
    console.log("Promise2");
});

console.log("all end");
```

![image.png](https://img.hacpai.com/file/2019/12/image-8a42e016.png)

[参考资料](https://lvdingjin.github.io/tech/2018/05/27/async-and-await.html)

