title: Nginx配置常用示例
date: '2022-06-10 17:45:03'
updated: '2022-06-13 12:16:37'
tags: [nginx]
permalink: /NginxConf
---
```
# For more information on configuration, see:

# * Official English Documentation: http://nginx.org/en/docs/

# * Official Russian Documentation: http://nginx.org/ru/docs/

  

user nginx;

worker_processes auto;

error_log /var/log/nginx/error.log;

pid /run/nginx.pid;

  

# Load dynamic modules. See /usr/share/nginx/README.dynamic.

include /usr/share/nginx/modules/*.conf;

  

events {

worker_connections 1024;

}

  

http {

log_format main '$remote_addr - $remote_user [$time_local] "$request" '

'$status $body_bytes_sent "$http_referer" '

'"$http_user_agent" "$http_x_forwarded_for"';

  

access_log /var/log/nginx/access.log main;

  

sendfile on;

tcp_nopush on;

tcp_nodelay on;

keepalive_timeout 65;

types_hash_max_size 2048;

  

include /etc/nginx/mime.types;

default_type application/octet-stream;

  

# Load modular configuration files from the /etc/nginx/conf.d directory.

# See http://nginx.org/en/docs/ngx_core_module.html#include

# for more information.

include /etc/nginx/conf.d/*.conf;

include /etc/nginx/sites-enabled/*;

upstream backend {

    server localhost:8080;

}

upstream IRServer {

server localhost:56666;

}

server {

  

listen 80 default_server;

#listen [::]:80 default_server;

server_name www.xiaozao520.cn;

access_log on;

location /favicon.ico {

log_not_found off;

access_log off;

}

location /IRServer/ {

#proxy_pass http://IRServer/;

proxy_set_header Host $host:$server_port;

proxy_set_header X-Real-IP $remote_addr;

client_max_body_size 10m;

return 301 https://$server_name;

}

location / {

#proxy_pass http://backend$request_uri;

proxy_set_header Host $host:$server_port;

proxy_set_header X-Real-IP $remote_addr;

client_max_body_size 10m;

return 301 https://$server_name$request_uri;

}

     location /static/ {

root "/usr/src/www/";

     }

error_page 404 /404.html;

location = /40x.html {

}
#此配置是指定URL重定向
location /wx/outSharePage.php {
    rewrite /(.+)$ /static/wx/outSharePage.html redirect;
}
location /wx/play.php {
    rewrite /(.+)$ /static/wx/play.html redirect;
}

  

error_page 500 502 503 504 /50x.html;

location = /50x.html {

}

}

server {

listen 443 ssl;

server_name www.xiaozao520.cn;

     ssl on;

ssl_certificate 1_www.xiaozao520.cn_bundle.crt;

ssl_certificate_key 2_www.xiaozao520.cn.key;

ssl_session_timeout 4h;

ssl_protocols TLSv1 TLSv1.1 TLSv1.2;

  

ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;

ssl_prefer_server_ciphers on;

location /favicon.ico {

log_not_found off;

access_log off;

}

     location /static/ {

root "/usr/src/www/";

}

location /IRServer/ {

proxy_pass http://IRServer/;

proxy_set_header Host $host:$server_port;

proxy_set_header X-Real-IP $remote_addr;

client_max_body_size 10m;

}

location / {

proxy_pass http://backend$request_uri;

proxy_set_header Host $host:$server_port;

proxy_set_header X-Real-IP $remote_addr;

client_max_body_size 10m;

}

error_page 404 /404.html;

location = /40x.html {

}

  

error_page 500 502 503 504 /50x.html;

location = /50x.html {

}

  
  
  

}

  

}
```

