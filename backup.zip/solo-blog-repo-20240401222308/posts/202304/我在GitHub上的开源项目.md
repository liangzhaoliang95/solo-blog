title: 我在 GitHub 上的开源项目
date: '2023-04-12 09:02:12'
updated: '2023-04-12 09:02:12'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [xzWXBot](https://github.com/liangzhaoliang95/xzWXBot) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/liangzhaoliang95/xzWXBot/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/liangzhaoliang95/xzWXBot/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/liangzhaoliang95/xzWXBot/network/members "分叉数")</span>





---

### 2. [solo-blog](https://github.com/liangzhaoliang95/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/liangzhaoliang95/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/liangzhaoliang95/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/liangzhaoliang95/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.geekz.cn`](https://www.geekz.cn "项目主页")</span>

✍️ 个人编程分享 - 日常记录各种坑

