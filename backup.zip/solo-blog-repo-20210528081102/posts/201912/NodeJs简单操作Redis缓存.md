title: NodeJs--简单操作Redis缓存
date: '2019-12-12 16:30:44'
updated: '2019-12-12 16:30:44'
tags: [NodeJs, redis]
permalink: /articles/2019/12/12/1576139444563.html
---
## NodeJs--简单操作Redis缓存

1. 引入NPM包（redis）
2. 传入连接配置创建连接
3. 使用建立的连接进行增删改查

```
var redis = require("redis");
var client = redis.createClient({
	host: "localnet",
	password: "xxxx",
	db: 1,
	retry_strategy: function (options) {
		if (options.error && options.error.code === 'ECONNREFUSED') {
			return new Error('The server refused the connection');
		}
		if (options.total_retry_time > 1000 * 60 * 60) {
			return new Error('Retry time exhausted');
		}
		if (options.attempt > 100) {
			return undefined;
		}
		return Math.min(options.attempt * 100, 3000);
	}
});
const {promisify} = require('util');
const del = promisify(client.del).bind(client);
const set = promisify(client.set).bind(client);
const get = promisify(client.get).bind(client);
const expire = promisify(client.expire).bind(client);
const redisOP={
	del: async function(key) {
		await del(key);
		console.log("删除成功")
	},
	setJson: async function(key, value, timeout) {
		value = JSON.stringify(value);
		var res = await set(key, value)
		if(timeout) await expire(key, timeout)
		return res;
	},
	getJson: async function(key) {
		var value = await get(key)
		value = JSON.parse(value)
		console.log(value)
		return value;
	}
}
async function test() {
	//设置redis的key和value和到期时间
	await redisOP.setJson("lzl:lzl","test",3600);
	//获取值
	await redisOP.getJson("lzl:lzl");
	//删除对应的KEY
	await redisOP.del("lzl:lzl")
}
test()
```
