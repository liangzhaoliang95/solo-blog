title: MySQL命令大全：以后再也不用担心忘记SQL该怎么写啦~
date: '2022-12-19 08:49:22'
updated: '2022-12-19 08:49:22'
tags: [mysql]
permalink: /articles/2022/12/19/1671410962873.html
---
<div itemprop="articleBody" class="article-content" data-v-54266f34=""><div class="markdown-body cache"><style>@charset "UTF-8";.markdown-body{word-break:break-word;line-height:1.75;font-weight:400;font-size:15px;overflow-x:hidden;color:#2b2b2b;font-family:-apple-system,system-ui,BlinkMacSystemFont,Helvetica Neue,PingFang SC,Hiragino Sans GB,Microsoft YaHei,Arial,sans-serif;background-image:linear-gradient(90deg,rgba(159,219,252,.15) 3%,transparent 0),linear-gradient(1turn,rgba(159,219,252,.15) 3%,transparent 0);background-size:20px 20px;background-position:50%}.markdown-body h1,.markdown-body h2,.markdown-body h3,.markdown-body h4,.markdown-body h5,.markdown-body h6{padding:30px 0;margin-top:35px;margin-bottom:10px;color:#4dd0e1}.markdown-body h1{font-size:30px;text-align:center;position:relative;width:max-content;margin:0 auto}.markdown-body h1:before{position:absolute;content:"";z-index:-1;top:-20px;height:100%;width:100px;left:0;right:0;margin:0 auto;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADsAAAA6CAYAAAAOeSEWAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAABkLSURBVGhDtZoHnJ1llcbP3Om9ZiYzmfSQhCQQIbRQVQKI9CYC68qKriJK0UXcZRcINqStIoiIqKCi1NACQihBWiCkkJ5MJlMyvd7p7d759v989/sy34yTbIj48Atz71ff855znvOc971xDrB/EtoGI7a9Z8Aq+wZML0mNj7dE95NZ1OKsj1dHo1GbnJpss9OTbWJyonvun4VP1Njuoagtb+m0it4By0iIt8LEeMvkr8XFWcfgkA1gYDLf47i2PzpsyU7UspKSLDoctagTZ7Vc08MzClMS7awJ2ZaflBB78CeET8TYla1dtrKt2w5KS7YCDGzEoz2RqKUmhGw6x2bhuXyOp2BoRXef1Q1E7Lj8TIsMD1sbxu1kcnYSAX1810RMTUmyMB7f2j1gC7NS7byinNiL/kH8Q8a+2NRh77b32El56VaPAe0YeGR2mh2bm+FdMRqP1rbZe+3dFsHT35qcb/Oz0rwzo7Gxs9feYPLS4kM2h8lawee5hPmlJXneFQeGAzJ2F564v7rFzi7Msu3d/Xgjzq5g8ArX8VCNN2vJ28daey0zZJabmGCLslP5HOf+Oygr3UzDGOf+JxrauXfQjslJt+dbuuyMgiwmk+sPAB/b2Lt2NdoMZnuY21qHIvbvUyZ4Z0ZQiXGrWjvsmPxsK4R0nmHA8ZCTQvxVQn5eRipklIBtcVbV1WtHYsjati47ZWKuTUpP9Z4yGk/xDBGe3v1mW4/dOrvYO7P/2G9jRSjf31FnXyaUXiB8r51WaJkM3kcfOSa2FR6qarIenooTLQHPLcC4mYThyw1tVpKWYlVERlZ8nC3Oz3Jzdn1nn5uvQ8OOHYvhR/CvsqffJbkCkZTvcYZ6Z0WTfTovw5Y1dtjXp+TbFPhgf7FfxpYxuMfr2uwo8rEtMmwXF+d6Z8wGmIR2PLyjo8cqOFffP2SLGexJEJCP9R29thkPXlpa4A5Y3w/jmuVNYYwO2QkY7WMtz3mVcE1hkualJdmSolzX8GnpKd4VZq80d1o7zN0RdWxGaqItgbn3B/+vsasgh/UMNBOvzYMZDxtDKp289KGaVguFQvb1yQWWwuB97GaSXqUUnVaYbSUwrDCEBz/C2CM8EhNrP13fbkeSh3OJgCAe2N1CWXKsGOc6TOr5U4q8MwYhDtkTda02MyPN+nnGBQEH7A37NHYz5KOZVv08qyjbSseEzKauPnsMj98wc6Ibcj5UUv7M8QWZTE52jEwGOVaD8U1Dw1YNWX0qM8VKyb80L/TrOPYOzH4KBJQTrK8M7+7KZjuM63sHBt17FubGoibCuf+tarWFGUmuwWeT8/vCXo1tZOYeZcazCaez8MwEzzM+HqhqtiJI5twxL1jeGLYk7jmKMF1JOCbg6Qj5nAdRqX7q3BYm8VAmQvW1lfcMc58IT95uIA3q+gftrDHPXUXJWkVEHJme5Bp5UmHsvIZ/O3l8ECE/FWcsItX2hr0ae8O2Wjs+J43QTbOZzGYQ/7Wtxq6eXjRK3r0By4YJ6Ty8EiYSJqcm2eGeV4Pox/ANENJR49RiEdfqcLflUJrEBZqgxYHrBjn2ExFURqKdVETN9YirJxKxR2rbrYeQv5ISmB6IsiDGNfZGWPeMgkzr58xnPaJ5p6XDZPKz4T77wayJ7jGhhXLwanOHTWBgq5n5q6YUwNJ7l3kKcRl7OJ7fF56l1GzvHbSD8dghTPi0wIRfv6XafjJ3ssv0PnZQ7nZx/etwzO1zJ3lHR2OETTw8x0tOx1AN3De0D7YV+63oGthjaJQ5Ur7eVVZjcdGInUyuaT73ZWg3efV8fZs7cc2E777Qi5eunVbghvPPymrt/krKGfcLd8ybYjdxrK6333Z09rjHZkNuLYzz0uIc+xWCZzz8nbHbe4dsY1e/XUOY+nimvtUaSazv4jXhaQasSbmYmpuenGwHZ8TKggSEQm08rMD7ahBOoExcMqXQegjnZ+CEvaEa1ZQUQkt39dj0zDS7krq+ARmpdws/nlNqD9WFbWN7l5u3wr9MyrcXKUsqWy3jTOaoML4DdaQ83YIoT4VYpEXvYQZLmbX5SLohBrgOj186Kc/iKTUPUhq+Rrm5ekOl3TWv1Mr6hqwbY0VOQXwEo+Moq4Z47q5qsU489G944LyJOW4LOLZOKtT/iI6+nGe/0dhuEd4ltj2NmiuCU4hnk5fHIi7+RK4uTEu0e+s7rAiRcw1CYy3OejvcYz+eXeI9MYY9nu3lYZl0KavJJ7Vjibzgjp319rUZE20j7CkJqFr5JQYgQ39f3eQaKpQk0afy8nl4uBzvjUUTRk7k3iebOm0pabDiyFn2XGu3dRME41CGVeBVqSiVnc6hIUpekp1VjHLDSOEcQlui5W/U8C7IKREjv1Gabw3wRwUTvpv7jybPtzHmIPZ49q6KRjuccqBQVCOtGvqXhrCFUUXJzOYSHt7Kw5Ix9H08dSje1o1JyL73IYXpEMmE5CRbw6wuykx2pR+Pd6/J4JpLiJKV6N9OnrcQNfQ0Zem6qQX2MmFXyWTE+DMO0kGx4e08DEjnXbsYuOq7niHB8jdY/wQ8Srm2XCZZUrOakF1CY5EKX0h93Tu/1J4kRdbDMT8MamgZK9xe3uDcvrPe++Y4f61rcZr7B53rN1c5N2ytcV5rCrvHt3T2Og19g+5nH7dvq3bqunr4NOwgK2MHA1jeEDuG7HNuLmtw7qpocl5t6nCPvdTQ7v4N4u3WTqeyu9cZHIo4f6lqdFoHh7wzMbzDeeGv3Hvzjlrnh2W1zofhHuftxpFn3VFe7zxS0+p0DlKVPbhhvBxhvwiFMgfP+mjHA08gEC4pybeLyK1iZldh8zC5VJQyUl8l59KZ0WJk2xaiYWxNrkXXJhA8r3PvZRur7ZZZRfadaRPsfiTmX9HGajC2tXd6V8dQTMhX0h8rNdJx9Ra8F8SbRNLzhPRnJmTZIUTYueTyWxyr7uv3rjC3OkzE8495oS+4xq6D5WoI0bO5WVCOSerl8rIeBrOI/Hkaw6ME5W1zSuzx2la3CRdWi3zIG+FDBvUp9LMgI/vggUmE7KkT81yGvOOgEYa/aUahhRAF5xLec3OzbF1r2O17BbVxIi7hzJIC64IYhXdJA+nh/5xVbOmE9J0QqjSxWk0pp37M2YEtgjS8GpimACu7xkqxdKJ6fEXyYl2Lre0ZtC8yELVewtWUnbfCPIhrvgDFz8WI5yhJKgcnFMZWEFrwhgzo5uWDDDA1oGSOzcu0xfx7vTlsv6posIMpJ6cGWPiw/BxL4PU7vbrpjgf8bMdu5OYwOdhm83DARUSa0ELknYIeEAaILuWxlhGa0M8+EuJCrpJT+ymENhN60pXBxa3LZ5TsucnlGaCmIEQ4Evru91yuz0xMtKaeXluI5zdh9Mm8vAlBn4aR07X64EH3vEKdXQkZJXPP/JxMvNRpLxEtHZ5RQgmNewnpouvVTpYTHdfOnmy5kFUGnpRTfEhXD9DiBdFFJB0/YWS9aj6pmc89r0BaQmgTRkgI+EsdKsYasJZOBF+QqTH474NK7LbyBvf7W+RgOxNyxfQY2/2hrp2+NkroxrzrQ55fSZkpJIa28znCgF6rb7H1hOSslATyvNflAh9pvHcX3lVE/Ya8FjTJIexa2Rq77nfU96unTnD7aME3+TAm6BFKYrPnqCNIqV5sq0ZGCiEV+Db+qWMQqpFgb5KPx48R6omeDl2EuP9DTYt9iGA/f1KBS1w/La+H4ktsSmLItvZHXLUkrCeflVtJ9DVVg1H7+sxiGvVM975rZpfabuqHVhuP5F1vewav5O8GamUe91yDanoYw47FWzC929O+DJnKA2opFY1Rjru5CE7kOcO0jJtQVUIynzuZEMeb+1CEOFXN8iFSGeRpCm1BTlJxVg49Azm819SO7Bu0axEbwn27GuxMck+TMQHDP8fn48gfDVIL4R8xKVPJ73MQBUIfA/Z54LMw5vmlE+w+VFo2A78X/SsyPA/RMD0z3e2qVLtfo7aeBslpMX0N0TEnLcUlKym1jyBFqSohmYntI5enBhYB9CY/2kNarhwJhNiMtRGyWnkQdKaCFyQwgydjyNUw4VchKxXv2/DoKdC+lkQbCX1NlKCGvJiBJkSGbCus6jfo4yGBNySgr+u7e20BCsxdVAcFlJ/tHd32+cIsNxSXUULUUx+dg/d47g7OPYFw2MxkSuyMwLHVTI6PBN6dS8Sppw45zHJSgDXV3aQzmz40Z6fDgBfiAXU0uZxby2zejee+j3eltoQMzhV6qSBogXwrEXDj7ElWxUQ8RrnSaoU0dxIsKaiMvMykXTu90NqJsGHP4z78SdLigUrLKat32nFwy/E07pfDFRdQ/7N5r57pQ1482uvWhMGhQcviGkVrKDUp0ToCxfhQal5n4Hs/g1jOgH4LWdwFOd1b1WzHET4vLZppv+Czjxo840OrDlG8jAJzv2tp5mLK1dsU/lfIOeWy5NxFxfl2BoYImlQtx9QF6mJRQKBsQYYuO2yaLYPBUXvu/VqYPxtHhNy7Y4hCkNLGPtKSklzCVKSHtMQxcqm5Kw1DhI2PTGZtcGDAvoLQ/u7MifYtWFBlxz2H9zo8RkwKzC5UYiG+p44ccqE62YAxLeT/TOpf8MXx8Qk0IJFRY1Go+viQVJpE5Ehjf49xfAZeqGIy/7us3nqxwQfCkjZypPxobVr/6YpQHIalUvuCyEwbSXC9PC8QnkFcXlrgLpoLIhIfKuaqlQkYIAwQnr/f3eyu7KttOw2lNpv8/BPHyjzVNER3o72gvEBKqRMTflndbP8BMweRDyeciEj5bFayFXqTLzheivgYJC0jwzwHa0MDDEotm48ndze5BBBElAnxxcRYHAFh3FfZaA9UNRmC354kNwUx8eHkmVj5dcTE5ZMnuEyr1QqlhtaJLuOYZv4v3KNo0TKrGPUZ1NILPKuWcvVn5Trv10SMB6h0j/ARMnlOuafCBIfnSWEx/Raif3HDzofYMM31dOyY9LBaLK3TjoX2fEqT4+2qaUVWSTQvyM6wC8nNJyEetXIyuLKrx04P7MKNnbJZlKUtNAIHo7i2dA/YU3Vtdi5l6jCepXy8hOedSSSsI8/HQg5Q+gxTKXwkMHkbESo+hjG0lbRRzQ3Fc5LOzDuFhs3Ptumpie7ilRDhlEJOq/hjsZljCxjkt7fWuPS/EekpXMggJQIk0G+eN9Xu2VmHWIkJe0nJRN4ptBBit2yutG9ML7J1DHAxebiAMrZ4VZlduqGS8I2tJc2iborUxmIN79c+kTovFxivPvrcSaP3n7RSKYTUmKt4N3rMOcw4JOneD3sP956jNaMglIeTER5Xbdlt15Tm2W10NEsYrA/N5JLCHHsR9tSqwxq08G3bqm1ZTbOtagnbo6SLvH/VzBL7W7jPzqFea0LmMLFzUuLtdwumuO3i1Vtq7OK15Xgw3l1PDmIXak+6QBEkvB9YJIzBcc/L20JIYaSZ/qAzVm5Ut4oowk3QehC+N3xo/1wTqt7zsYawfX9no9XjqdPXVLhrwyo/wucJYQkE1e4j8rLcBuHUItQQKqgMXb6LGvxFQlXw33AdZLR0V5P9Fr29lP73scNnosoyvdWPv4fPJ+uJrLVtMakqaL1M1cTvv0OLIZE6wk2a2IcIRUQh+DaejpdcXepBa7bKDRGM9PIVxTl2EwarZ72rooVuY4RQtMypdk6e1lLLehhY2lt7QEd7WxlCDvdIli6E9B4+ZIodmZEMccUGqgiZOqru9tkR3iJ8nCcXRWRZCSPMLPEjlx2LjQL1OM5qKAm+vhSuRqSfV5Ttrg8FdWcrnhMqCTex7DEM6qTsVEuM1+8hovaHQ6e6a1Fz0xLd3nUt4ToWWuzWNkhcoAIIjUx2ZpxjLzWF9+SYmngR1lok4TEoJxGfuijhI/7OICoFmadl2llcL9b1oRVJtbD+JLlv1KrhHG5811t9ELbzgk14ICUwqE+TDzftqHPz98vUSy3jSIwP8dCpkNqLDPTx+rArz4T5qLG3G2PrvJKKPoLBWE501NC3ilUX5mVjVIb9nIbgWcpPMiSXjbcL8K62UkR86m1/yfkSeMaHFuK04X0CE3J6SWzFUxw0BSNHlSzi3RmIRJwHq5udO3c16quLp6sbnffbupxbt+12vzOrzuvNHc7ycRbIxuJHgYU7YSASdQgxp7qz2ynv6HJeqW91doa7nLruXof+17sqhhu31Xif9o7HalqczV29Dnrb/f5EXZvzdH27U98/6LR5i3N0UM5zjHU71/lwjRWWltU5CAIn7F1MqLp/r9hQ5RoaxG+qmrxP4yNKcfsFLwuiprffeb2l03m2scO5h3Or2rudzjGrhk8x4Cqu2xcexilBvNEcdi5Yu4tKF3Ue4tzPy+td5/1md4tzw5iJ27NuXEYobYUdlb8z6GTWkdxaCvk2zHjd5mpKQ459mv5TkAp6mQb9Aq9HHQ8S6mrZnuc6vUG6WHusIhCJGNXl9byvnJyaiE7+Eoz8c5TYNQiUveENGpJpcIJ+biS8R0+rlcazGNs7pKB+zPLTOSX2KNWhlDAf4r2Spj72JORB5OyHULX+dlD/FOky/HFy5ygYU0sey/i8moeqdunXK1qC3RuaMOYHlI/raQMl3M+EeTV5WxD3Km8a8PkM8nr648sQ9+esKbf5e/nxiKBfAOQkxbv3SU9LYmqPV9V/Pn+V20VwTyVjTqCI6edEQUOFUXs9WmfSll8DyX2dt7GlnwkswaM3l9XZ0oNK3MTXbxpOV2sGk69s6XCJw4cY8KbyRrt9TrHt7Bm0rRBQe1+fHUWNfaapU0KbqxzbORC1M/LS3dJwIl3KOrwykQG/E+61q+isgniztdOKqNOziDgZqZIzFwPvqGiyg5NCtoCqoG5NxHhPZTOsnORulKskjoKMDeLuXQ3OmnC3syxARFXdfc57LR3OrdtrvSOOs55rnqhtcdoGhpxHdjc5EfJUuHZTlftX+G15rXPlhkrnLe59F7Lz8VGHdg8c5y2OLeMZ126qduq9XC3v7nd+FchLvYPJd15gPCu8XQnh/qpm59WGVudZzvvQO97kXTcGxhnEuJvR39tWY8cwK4uhcikk4a3Gdstg9l5B2t0wfaTdWkEou5vCPOV5PH73vFL3+DfXltnh6OxjkJD6Wd5F3g88tMe6CW/7YmI99VIL4u0oqUK8ocW4d8hFrXMVoOQU8s3U97MnjvDD/XRYkyhHM1MT3GVZQR2Tdv70U8EbA5vlo+CaPAaaSWoZXm50otGodxQ6L6txGKxzw5ZYORrBsPPrykZKQIy1n8bTjwb2fO4Te3ue7x6KOKvaYns1wtIddd4nx3mwot55qyl2360cp81zurg+CGqwU8v4/Of5uAVvPgObrwvHomY8jOtZ4fXWLnefdHVXv9044+8ZklCx75DXwcV1Sb27y+vInUQEuVYSaMgRJYfAwtoj0raFxIUW1A8nz35f02qLc9Lc9lG7CBkwtUR7bf+A+5uL6ehnH9Lat+5sIEfj3Cbj3NKRvP7Rjlo7FSmqavKvpSP8MRZ7NVbQYLSkqlC9ZW4sPH18gBTcORjrhMWmQWzFmK2UsvO90qQ1oZcI8UhkCLZPtRqMy0NirobAvjIpb4/sW06qKGyPR2oGIdlazjOOTk+kLYzaaYGSp63Wz6HsXsQ51wd+LTAuZOy+8GBNq7tF+IOdDU4kENJthNID5YRafZtzZ3mDs9LbRgzixcZ2l1h83OKFbDmEd0/FiFp7DWHgp0AQGzq6nf8hPF+oa3EehOz0ziCWcm4NpBRMhX1hn571oR9wqVVSDVPtUi32sQ0vbu7scZdY9aOt2ZSEL9BEBIW+dv20AKDd9/ep09oimYqHpyImkKDuRllS4PrlHNuIqDmCJmNJQba7q1joEaUQJuR/WdXsLrJrq/L6cdJsPOyXscJ7GLKqo8cOpqhrO//yQG6oS3kZwS9xPkRB3wi7diFMtDN+PLk5m1ath+8f0Fy80dbjhvVXub+U5mEqeal27UP+dWpPlknNxW79Ak6/7Tg3UMOF52j1xA1qK7Trd6nXC+8P9ttYQcumIonLSnJtBdJNa77axw1C2x3qR4Wqnj73x9f6MbV+CCYFBZO6y51aSh3gzVrsmwzJnULEbCJC1oZ7vIZ/9Iqmfvn2u5oWO5n8fApxcuWUApum5diPgY9lrA9EtvUNOzYf8vqAcJPsU5iOh7XtXQgt2uZhjKU2amF7HQyfEYWcZk5yQ1RDKNrLcq02k/9IGmldrB93KiokPw8EB2SsoKWXO5FmxXhlckqi+3vEUvLqwok5PHVkIWAszlqzy1p54zuLpnPZ3q9bod08JlLSb5DrNxDm38Sbvsg5EBywsT7oH+3XNW3uasGirFSrxRNdCllKiPZHZzJYLZb5qEcpae3pxMCuu9oibS5/QCOiLcYUrp+MmtJeURjFdVlxzqiae6D4h40NQt54HyGv3JRo10aVfv8YhtC0pSlVKcPFuxIXahr08mzCO4VzMlLSsZuomZ+RaucU0rXsw/sfF5+osUFonWob/7TrLdaUgdpV93fl9X+VIC0Y6tek2uI8OD3J5gT2Vj9ZmP0f4IM4iY7RQ5gAAAAASUVORK5CYII=) no-repeat 50%;background-size:64px 64px;opacity:.84}.markdown-body h1:after{position:absolute;content:"";width:150%;left:-25%;height:50%;bottom:12px;border-radius:50%;background:linear-gradient(transparent 80%,rgba(77,208,225,.8));background-size:400% 200%;opacity:.6;animation:h1Animate 6s linear infinite}@keyframes h1Animate{0%{background-position:100% 100%}50%{background-position:100% 50%}to{background-position:100% 100%}}.markdown-body h2{display:block;border-bottom:4px solid #4dd0e1;position:relative;font-size:24px;padding:12px 32px;margin:30px 0}.markdown-body h2:before{width:24px;height:24px;left:0;top:0;margin:auto;background-size:24px 24px;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAADGklEQVRYR81X32vTYBQ999s6mFjQgQ+DrbHiVFZYU4cDcQ/6pGhTFVYFEXGi82H+Bz448UnEF1Fx9ccEEcXpZE3d5tP2ooKiTacTHaLNpigMHDgnU9tcSbrWrkwWR0sbyEOSe885ObnfvV8IRT6oyPwoLQHBx+OVM5WJvSyEVAhnBOjt7yU/+/rr6r6l8TMO+F/EN0JQhICqQpD/xaRpcpAc9tS+M+9lBCia/oqBamK+zeDuQogQZaKJk3wcQjxSva7tGQGB2Ke1zIk3DNyMyNL+QpCnMQOaPsDAVuGAp9cjvbYc8Ec/bCYSg0zoiHilk1tHxqsqEsYlML4kjIpT/eurJxRNPweQU5VdrWaOEo1fgKAVbBgXIz73kF3R/ph+ghgdzMYWM29eAWlBJqgZaFlFYtC6nhWpaDqnSGlIlV1WjJ3DloDNgyNLncudqgX//Ucg3LxuStHGuhi8pqKCW3rqV342rwFjRznKm+/LNaN2yC237ThgF2wxcfMLeP6+ncrKzoPoKTGeLQbYbg4TNoC5iZPJY5HGVRdSNZAWYBclD3FzBQzrR8hACAKdzBzKA/4/IYioDQaOskBbpEG6PO8qKKSAEi3CnEb0Pw4oMf0OmKbTDWqh3Lw6EIiNBZi5lxh3wz4puBD5ovqAMvxhHSdFKxE1CQe3m/07TeTX4lcJdAhE+1Sv65Z5P/ByvIGTRowIZ9igbtXnmrOsbTvgj+kHBNMuBu9OdVw8EeU4nC1A0cYmAHZOTRrLhra4Z8ywnSN6vZHAFTA2WnnMfQB3qz73ddsOZM8CACFDIPSgQXqebXEgqgeZcAeEe6pXasm1f8ew3igMtAHWac0Uc/jYdyAaP0xEBwFsmgUPqbJ0NE2UKj4EGcahiOzuyhagaHpnmtgcVgTcCMuua7YdyAHbA3ArQNscVFbb4635aD6fnYaTvxxi9UNP7ddMXaRWVBdAcaLk6bDXPZCNZ9uBXEsDUX1T2Cc9yjig6Z0EHg3LK8/aqf6MwJKchkXfks1+0+JtSq3qLPa23BRR1B+T/6nkfMaW1r9hPt/MLtYfTLEpP+T9FNoAAAAASUVORK5CYII=)}.markdown-body h2:after,.markdown-body h2:before{content:"";display:block;position:absolute;bottom:0}.markdown-body h2:after{right:0;width:400px;height:10px;border-top-right-radius:24px;background:linear-gradient(90deg,#fff,#4dd0e1);max-width:50vw}.markdown-body h3{margin:30px 0;font-size:18px;position:relative;padding:4px 32px;width:max-content}.markdown-body h3:before{border-bottom:2px solid #4dd0e1;width:100%;content:"";display:block;height:28px;position:absolute;left:0;top:0;bottom:-2px;margin:auto;background-size:28px 28px;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAABRklEQVRYR2NkGGDAOMD2M4w6YDQERkNg+ITAppcfY/8zMv3wF+NdTUrZQpUQ2PT6cz8Dw/8CkMWMDIwNvqK8jcQ6gmIHNN19EaXPx1XPyMCghrCUKcpPlGc5MY6gyAE+Fx52MjL8j3cU5a1UYWXtZGBkEAVb+p8hxU+Mby5NHQCxnKEMaskzJ37uFmUetkmMjAzrfUX4woixHBJlZAA0y2EmPPYU4enLkhGeQIqRJDsAh+UgO7duNpD3IcVykkOA2paT5ABaWE60A2hlOdEO8D3/4CMDIyMfWvySFefoaYSoROh74eFXBgYGLiTNVLGc+BC48PAnAwMDG9QBVLOcaAd8P5ox+x/jf5AjGLgYfnwnKqv9/8/PwPO/kFF/MSj0cAKiouD/0bgYoixFU8RovWgJIX1EOYCQIZTIjzpgNARGQ2DAQwAAvHBaIdB7zxsAAAAASUVORK5CYII=);background-repeat:no-repeat;animation:h3AnimationBefore 2s infinite alternate}@keyframes h3AnimationBefore{0%{width:28px}25%{width:100%}50%{width:100%}to{width:100%}}.markdown-body h3:after{content:"";display:block;width:28px;height:28px;position:absolute;border:2px solid #4dd0e1;border-radius:50%;right:-15px;top:0;bottom:0;margin:auto;background-size:28px 28px;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAABRklEQVRYR2NkGGDAOMD2M4w6YDQERkNg+ITAppcfY/8zMv3wF+NdTUrZQpUQ2PT6cz8Dw/8CkMWMDIwNvqK8jcQ6gmIHNN19EaXPx1XPyMCghrCUKcpPlGc5MY6gyAE+Fx52MjL8j3cU5a1UYWXtZGBkEAVb+p8hxU+Mby5NHQCxnKEMaskzJ37uFmUetkmMjAzrfUX4woixHBJlZAA0y2EmPPYU4enLkhGeQIqRJDsAh+UgO7duNpD3IcVykkOA2paT5ABaWE60A2hlOdEO8D3/4CMDIyMfWvySFefoaYSoROh74eFXBgYGLiTNVLGc+BC48PAnAwMDG9QBVLOcaAd8P5ox+x/jf5AjGLgYfnwnKqv9/8/PwPO/kFF/MSj0cAKiouD/0bgYoixFU8RovWgJIX1EOYCQIZTIjzpgNARGQ2DAQwAAvHBaIdB7zxsAAAAASUVORK5CYII=);animation:h3AnimationAfter 2s infinite alternate}@keyframes h3AnimationAfter{0%{transform:rotate(0)}10%{transform:rotate(0)}50%{transform:rotate(-1turn)}to{transform:rotate(-1turn)}}.markdown-body h4{font-size:16px}.markdown-body h5{font-size:15px}.markdown-body h6{margin-top:5px}.markdown-body p{line-height:inherit;margin:22px 0;letter-spacing:2px;font-size:14px;word-spacing:2px}.markdown-body img{max-width:80%;border-radius:6px;display:block;margin:20px auto!important;object-fit:contain;box-shadow:0 0 16px hsla(0,0%,43.1%,.45)}.markdown-body figcaption{display:block;font-size:13px;color:#2b2b2b}.markdown-body figcaption:before{content:"";background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgBAMAAACBVGfHAAAAGFBMVEVHcExAuPtAuPpAuPtAuPpAuPtAvPxAuPokzOX5AAAAB3RSTlMAkDLqNegkoiUM7wAAAGBJREFUKM9jYBhcgMkBTUDVBE1BeDGqEtXychNUBeXlKEqACsrLQxB8lnCQQClCiWt5OYoSiAIkJVAF5eVBqAqAShTAAs7l5ShKWMwRAmAlSArASpAVgJUkCqIAscESHwCVVjMBK9JnbQAAAABJRU5ErkJggg==);display:inline-block;width:18px;height:18px;background-size:18px;background-repeat:no-repeat;background-position:50%;margin-right:5px;margin-bottom:-5px}.markdown-body hr{border:none;border-top:1px solid #4dd0e1;margin-top:32px;margin-bottom:32px}.markdown-body del{color:#4dd0e1}.markdown-body code{word-break:break-word;border-radius:2px;overflow-x:auto;background-color:rgba(77,208,225,.08);color:#26c6da;padding:.195em .4em}.markdown-body pre{font-family:Menlo,Monaco,Consolas,Courier New,monospace;overflow:auto;position:relative;line-height:1.75;box-shadow:0 0 8px hsla(0,0%,43.1%,.45);border-radius:4px;margin:16px}.markdown-body pre:before{content:"";display:block;height:30px;width:100%;margin-bottom:-7px;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAAAdCAYAAABcz8ldAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAhgSURBVGhD7Zp7bBTHHcdn33t7vvOdzy+ITVKDU0xIKG2ABCPTRCCaUiEVKWoqRJuASAhCitRCVKSoalFUKZBiSmmFRRJKRUnUtIpo+aNqGgwoOCmuFUIRzxjwE4zte+97drYzztji8HPvtkit/PnH+n1397Tz+83vN/PbMZhmmmmm+d+BoX8n5diihcGqgFQf5vk6BMAskWUlw3GyFnIvtqWSf91w7mKC3npfOLX7wYeiIa6BBWCOLLFRF2NB0JvIOP/80YG+k2ev6S699b/OzOfKBW5l5KsgyC4DCFQDnpEAdE1goc/dlNPc/Up7P711UiYNSMuyxeUzZPnHgGHWh5XADEkSAcdiN+AnEXIBhBComgFU0/xQR+jnj51sOUMf9Z0NKyL8S9+JPBEN8zuCMrsqGOA5QWAAyzLAxe53HBeYFgJp1c5Cx33nyIfpV3e+22/Sx32nev/sMCgVnmM4bjOniAtZWQAsz315EfsGQQc4hgWcjHkCmOj1rheuNn95cXwmDMiVp5etC/D8m5FwUWVQUYYGPh6mZYFUOgsGVa1pXvOZzVT2jRuH54RM230jEuI3RcIiL4l4UkxAJmuD/riVsqD7ct2m9nep7BtVTbVfZ0uE/UIk+CQflAHDjf8+Lg6MldYATGpH3c/Ul7p3dWXppVGM6eElJSHmnQWPbSlRlN1lJcUBjqNRnwJZVQO3B5P/uq5rK1d90pakckFcaKp5UJHY92JR8YlwkUDVySEZfGfQdO7E7Z8s2HL9TSoXTPXRud9nA8IBqSwcZgWeqpPj6BYw7yTbXBN9q2v9lQEq5zBmWA8vWLCptCi4tzwW8RQMQlFQATPLSh6vCSh/plJBkMyQBHZfWYnkKRgEktEVpTJXERN2Xzo4ex2VC6K6qXYpF5b3ypVRT8EgcAERSJXRbwCBOTFzXblM5RxGBaRt+ZPYA+LO0mgxz5K1Ig+UgAzKIuGnz39z6S+olDeaibaXRsU1RUFvgx+GwTWgPCaDgMw2XXpr9gwq50XV0bkxJiYeEiNF5cwE5XsiOEkAUkXkUW51SSOVchjl8WKef604XFSRbzCGCYeCoESStv/p8QU1VPIM3knNDynctnBRfsEYhgSlNCIGgQv2UCkvGIHZgteMh1nBW9W4F16RAM6yDVV7amZTaYQcr59cuuhhWRTWBvAMLxQGeyFSHOLnh0MvUskz5RF+fbRYDEy0mZgqQYUHOLhr//b6rGoqeaLqQG0pw3PrBbyA+4EQUkRmhvgqNUfICUipKK4OKUqIJVPKB0jpEhjmWWp64jdbKmVZZNYogcJm493gsifOqhDyeh9GYR/FM7sW+DA5CKR0MSK3tvKZkpwB5gRE4tjFEr7RL0iWBGV51vHFCyupNGWWPqLgnoer9mtyEGSJAzwLllDTGzyznDjRN/CwOFkoFb4bm0eVIXICgpvdGoEvrF7fC89zfLkkeV5HbOhWiTwTpKYvCAJLGshRdXtKMKAWlyxq+MPQLk1h66g5RE5ABJYNFrqY3wvJklJRUKg5ZWLFXIA86yek2uDOPkBNb3CM5Pf7DL2QyIrUGiLH+xC5Bmmm/ARnHUhC6PnzxWDK0RH5HuIjZGy27erU9AZ0dTIWXyG+NpBBrSFySxZw220IqeUPFoS6jVAPNadM7yDsgNB1qOkLuAziMYIb1PQGA75wIaKGPyAb+9oF16g5RE5ALIQ+tSyLWoWDEAK6aXW3JlK9VJoyx1oyvVkNdvo5KXXDAVkdnaKmNwx0xjH98w3JNmTCm+Bc9hKVhsgJSI9pvp9Vdd++jmq6AXB2/HHrhcs5aTkVDv0DFzoHvKdq/mQsKX/4t7KJLDpOJW+IbAvMGoMkxfwAWZB8DT7W1diTE+WcgKz6pK1bs6z3daPwmJDsSKt6ZsCyjlLJMz0DsDGZ8SdlDROBjOb8YeWOjptU8kTXusuaazu7oJrfEnQvdkpVcUn6PTVHyAkIIW7br/Unklni0EJIZ1WgGsauZR+fvUglz6zY0dGfVp09ybRNlfwgi3k8YSbvJJ29VMoLt9v6rZVQL7hOYUubndHJGclBtzn1byqNMCogi09/2nFb01/oj+f/5TyjauBOKtPcZ1r7qZQ3f2lRfxZPWi2anp8TSDAGExZMa2jr8u03L1M5L7q3Xc+iAeuHRl/ScvPcjSLDBnZS/cjtNHd2v3171Ewbs9N5q7Pn4otVMx3btBsCsoRbk1FxG5dMVgMDqfTpXl1/tuFMa5zKefPROdX59qLQBwLnNog8Wy1OcjB1N+QEsW/QsFNZuO35Xb1v98QLX4/Sx+O3wqujrQ6013ABUWI8+AaqBjAH01+ghL22+5X2PirnMG7r+esbnae/V1neauvGSoHjigTcVU7UGFm2DeK4ttxKpQ+mLPvl+o/PjnkAkw9HTqSMmVHhyAMx9iFcSh/BHTfLceO/C8mKjApBf9zszGhoY92m9sN+BGOY9AeD7eGniv8OTaOB4dgyTsQd9wS+IQu4lciYdkI7CLrNH3Rvbb9FL41i0tbzVP2iWJkobpN5fmM4IJfJskTP1Bk8A9HQmbpmGDBrWqdVCN/Yd7PjxKGOXn+bmbto3feVVcVB9qehIL8EJy8nChwgr0O2xxBnhGU5eP2CfYbl/m4gBRsbtneMORP9oGpjpcCsiKzHHfdOPiQ/wMniyFEu2dbiTQCAeN/vavC466BGYLttXc9fmXBXMGlAhiHHur+sq6uPiUI9z7CVHMPwBnLSuuN8FuC48/Oaz1ylt94XfrW5ouyprwWfYRkwNyCyYYjwkBHows1fa+tV/fzGxlv39b9gqvfPmQ+i/HK8KlcBjhHwfl8HEHyOd1JnuzZd66S3TTPNNNP8/wDAfwDG7G0m9LKBpwAAAABJRU5ErkJggg==) 10px 10px no-repeat;background-size:40px}.markdown-body pre>code{font-size:12px;padding:15px 12px;margin:0;word-break:normal;display:block;overflow-x:auto;color:#333;background:#f8f8f8}.markdown-body a{color:#4dd0e1;border-bottom:1px solid #4dd0e1;font-weight:400;text-decoration:none;margin:0 4px}.markdown-body a:active,.markdown-body a:hover{background-color:rgba(77,208,225,.1)}.markdown-body strong{color:#26c6da}.markdown-body strong:before{content:"「"}.markdown-body strong:after{content:"」"}.markdown-body em{font-style:normal;color:#4dd0e1;font-weight:700}.markdown-body table{display:inline-block!important;font-size:12px;width:auto;max-width:100%;overflow:auto;border:1px solid #f6f6f6}.markdown-body thead{background:#f6f6f6;color:#000;text-align:left}.markdown-body tr:nth-child(2n){background-color:rgba(77,208,225,.05)}.markdown-body td,.markdown-body th{padding:12px 7px;line-height:24px}.markdown-body td{min-width:120px}.markdown-body blockquote{margin:2em 0;padding:24px 32px;border-left:4px solid #26c6da;background:rgba(77,208,225,.15);position:relative}.markdown-body blockquote:before{content:"❝";top:8px;left:8px;color:#4dd0e1;font-size:30px;line-height:1;font-weight:700;position:absolute;opacity:.7}.markdown-body blockquote:after{content:"❞";font-size:30px;position:absolute;right:8px;bottom:0;color:#4dd0e1;opacity:.7}.markdown-body blockquote p{color:#595959;line-height:2}.markdown-body ol,.markdown-body ul{color:#595959;padding-left:28px}.markdown-body ol li,.markdown-body ul li{margin-bottom:0;list-style:inherit}.markdown-body ol li .task-list-item,.markdown-body ul li .task-list-item{list-style:none}.markdown-body ol li .task-list-item ol,.markdown-body ol li .task-list-item ul,.markdown-body ul li .task-list-item ol,.markdown-body ul li .task-list-item ul{margin-top:0}.markdown-body ol ol,.markdown-body ol ul,.markdown-body ul ol,.markdown-body ul ul{margin-top:3px}.markdown-body ol li{padding-left:6px}@media (max-width:720px){.markdown-body h1{font-size:24px}.markdown-body h2{font-size:20px}.markdown-body h3{font-size:18px}}</style><h2 data-id="heading-0">引言</h2>
<p>&nbsp; &nbsp;相信大家在编写<code>SQL</code>时一定有一个困扰，就是明明记得数据库中有个命令/函数，可以实现自己需要的功能，但偏偏不记得哪个命令该怎么写了，这时只能靠盲目的去百度，以此来寻找自己需要的命令。</p>
<blockquote>
<p>时间是最厉害的武器，少年定会白首，鲜花亦会凋零，沧海会演变桑田，高山也会化作平原。</p>
</blockquote>
<p>而我们每一位开发者，作为人类也不例外，无法抵挡时间的流逝，其记忆力会随着时间逐渐推移不断下降，而<code>MySQL</code>中的命令/函数那么多，咱们也并不能完全记住，所以对于前面的那种情况，在实际开发中也属常事，所以本章则会将一些常用的<code>SQL</code>命令/函数全部罗列出来，以后当需要用到时只需回来搜索即可。</p>
<blockquote>
<p>其实在撰写<a href="https://juejin.cn/column/7057537880624726053" target="_blank" title="https://juejin.cn/column/7057537880624726053">《JVM成神路》</a>这个专栏的时候，也曾出过一篇类似于的文章，名为<a href="https://juejin.cn/post/7082698950838321160" target="_blank" title="https://juejin.cn/post/7082698950838321160">《JVM参数大全》</a>，其中主要罗列了<code>JVM</code>通用参数、内存各区域的调整参数、<code>GC</code>垃圾回收的相关参数、性能监控与调优等参数，本章则属于它的姊妹篇，但区别在于：主角从<code>JVM</code>换成了<code>MySQL</code>。</p>
</blockquote>
<p>当大家以后需要使用某条命令/函数时，可以很好的利用这篇命令大全来辅助您，方式有两种：</p>
<ul>
<li>①按下<code>Ctrl+F</code>搜索快捷键，搜索关键词用于定位相应的命令。</li>
<li>②本文会以功能对所有命令进行分类，通过右侧的文章目录可按功能快捷调整命令位置。</li>
</ul>
<blockquote>
<p>当然，如若本文对你有些许帮助，那请不要忘了点赞支持一下噢~</p>
</blockquote>
<h2 data-id="heading-1">一、基础操作与库命令</h2>
<p>首先来介绍一些关于<code>MySQL</code>基础操作的命令，以及操作数据库相关的命令，<code>MySQL</code>中的所有命令默认是以<code>;</code>分好结尾的，因此在执行时一定要记得带上分号，否则<code>MySQL</code>会认为你这条命令还未结束，会继续等待你的命令输入，如下：<br>
<img src="https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5870e5cd0c484927bf3797dc2dec8510~tplv-k3u1fbpfcp-zoom-in-crop-mark:4536:0:0:0.awebp?" alt="等待输入" loading="lazy" class="medium-zoom-image"></p>
<h3 data-id="heading-2">1.1、MySQL基础操作命令</h3>
<ul>
<li><code>net start mysql</code>：<code>Windows</code>系统启动<code>MySQL</code>服务。</li>
<li><code>安装目录/mysql start</code>：<code>Linux</code>系统启动<code>MySQL</code>服务。
<ul>
<li><code>shutdown</code>：后面的<code>start</code>换成这个，表示关闭<code>MySQL</code>服务。</li>
<li><code>restart</code>：换成<code>restart</code>表示重启<code>MySQL</code>服务。</li>
</ul>
</li>
<li><code>ps -ef | grep mysql</code>：<code>Linux</code>查看<code>MySQL</code>后台进程的命令。</li>
<li><code>kill -9 MySQL进程ID</code>：强杀<code>MySQL</code>服务的命令。</li>
<li><code>mysql -h地址 -p端口 -u账号 -p</code>：客户端连接<code>MySQL</code>服务（需要二次输入密码）。</li>
<li><code>show status;</code>：查看<code>MySQL</code>运行状态。</li>
<li><code>SHOW VARIABLES like %xxx%;</code>：查看指定的系统变量。</li>
<li><code>show processlist;</code>：查看当前库中正在运行的所有客户端连接/工作线程。</li>
<li><code>show status like "Threads%";</code>：查看当前数据库的工作线程系统。</li>
<li><code>help data types;</code>：查看当前版本<code>MySQL</code>支持的所有数据类型。</li>
<li><code>help xxx</code>：查看<code>MySQL</code>的帮助信息。</li>
<li><code>quit</code>：退出当前数据库连接。</li>
</ul>
<h3 data-id="heading-3">1.2、MySQL库相关的命令</h3>
<ul>
<li><code>show databases;</code>：查看目前<code>MySQL</code>中拥有的所有库。</li>
<li><code>show engines;</code>：查看当前数据库支持的所有存储引擎。</li>
<li><code>use 库名;</code>：使用/进入指定的某个数据库。</li>
<li><code>show status;</code>：查看当前数据库的状态信息。</li>
<li><code>show grants;</code>：查看当前连接的权限信息。</li>
<li><code>show errors;</code>：查看当前库中记录的错误信息。</li>
<li><code>show warnings</code>：查看当前库抛出的所有警告信息。</li>
<li><code>show create database 库名;</code>：查看创建某个库的<code>SQL</code>详细信息。</li>
<li><code>show create table 表名;</code>：查看创建某张表的<code>SQL</code>详细信息。</li>
<li><code>show tables;</code>：查看一个库中的所有表。</li>
<li><code>desc 表名;</code>：查看一张表的字段结构。除开这种方式还有几种方式：
<ul>
<li><code>describe 表名;</code>：查看一张表的字段结构。</li>
<li><code>show columns from 表名;</code>：查看一张表的字段结构。</li>
<li><code>explain 表名;</code>：查看一张表的字段结构。</li>
</ul>
</li>
<li><code>create database 库名;</code>：新建一个数据库，后面还可以指定编码格式和排序规则。</li>
<li><code>drop database 库名;</code>：删除一个数据库。</li>
<li><code>ALTER DATABASE 库名 DEFAULT CHARACTER SET 编码格式 DEFAULT COLLATE 排序规则</code>：修改数据库的编码格式、排序规则。</li>
</ul>
<h3 data-id="heading-4">1.3、MySQL表相关的命令</h3>
<p>对于<code>MySQL</code>表相关的命令，首先来聊一聊创建表的<code>SQL</code>命令，如下：</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-keyword">CREATE</span> <span class="hljs-keyword">TABLE</span> `库名`.`表名`  (
    字段名称<span class="hljs-number">1</span> 数据类型(精度限制) [字段选项],
    字段名称<span class="hljs-number">2</span> 数据类型(精度限制) [字段选项]
) [表选项];
<span class="copy-code-btn">复制代码</span></code></pre>
<p>对于表中的每个字段，都需要用<code>,</code>分割，但最后一个字段后面无需跟<code>,</code>逗号，同时创建表时，对于每个字段都有多个字段选项，对于一张表而言也有多个表选项，下面一起来看看。</p>
<ul>
<li>字段选项（可以不写，不选使用默认值）：
<ul>
<li><code>NULL</code>：表示该字段可以为空。</li>
<li><code>NOT NULL</code>：表示改字段不允许为空。</li>
<li><code>DEFAULT 默认值</code>：插入数据时若未对该字段赋值，则使用这个默认值。</li>
<li><code>AUTO_INCREMENT</code>：是否将该字段声明为一个自增列。</li>
<li><code>PRIMARY KEY</code>：将当前字段声明为表的主键。</li>
<li><code>UNIQUE KEY</code>：为当前字段设置唯一约束，表示不允许重复。</li>
<li><code>CHARACTER SET 编码格式</code>：指定该字段的编码格式，如<code>utf8</code>。</li>
<li><code>COLLATE 排序规则</code>：指定该字段的排序规则（非数值类型生效）。</li>
<li><code>COMMENT 字段描述</code>：为当前字段添加备注信息，类似于代码中的注释。</li>
</ul>
</li>
<li>表选项（可以不写，不选使用默认值）：
<ul>
<li><code>ENGINE = 存储引擎名称</code>：指定表的存储引擎，如<code>InnoDB、MyISAM</code>等。</li>
<li><code>CHARACTER SET = 编码格式</code>：指定表的编码格式，未指定使用库的编码格式。</li>
<li><code>COLLATE = 排序规则</code>：指定表的排序规则，未指定则使用库的排序规则。</li>
<li><code>ROW_FORMAT = 格式</code>：指定存储行数据的格式，如<code>Compact、Redundant、Dynamic....</code>。</li>
<li><code>AUTO_INCREMENT = n</code>：设置自增列的步长，默认为<code>1</code>。</li>
<li><code>DATA DIRECTORY = 目录</code>：指定表文件的存储路径。</li>
<li><code>INDEX DIRECTORY = 目录</code>：指定索引文件的存储路径。</li>
<li><code>PARTITION BY ...</code>：表分区选项，后续讲《MySQL表分区》再细聊。</li>
<li><code>COMMENT 表描述</code>：表的注释信息，可以在这里添加一张表的备注。</li>
</ul>
</li>
</ul>
<p>整体看下来会发现选项还蛮多，下面贴个例子感受一下：</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- 在 db_zhuzi 库下创建一张名为 zz_user 的用户表</span>
<span class="hljs-keyword">CREATE</span> <span class="hljs-keyword">TABLE</span> `db_zhuzi`.`zz_user`  (
    <span class="hljs-comment">-- 用户ID字段：int类型、不允许为空、设为自增列、声明为主键</span>
    `user_id` <span class="hljs-type">int</span>(<span class="hljs-number">8</span>) <span class="hljs-keyword">NOT</span> <span class="hljs-keyword">NULL</span> AUTO_INCREMENT <span class="hljs-keyword">PRIMARY</span> "i_p_id" COMMENT <span class="hljs-string">'用户ID'</span>,
    <span class="hljs-comment">-- 用户名称字段：字符串类型、运行为空、默认值为“新用户”</span>
    `user_name` <span class="hljs-type">varchar</span>(<span class="hljs-number">255</span>)  <span class="hljs-keyword">NULL</span> <span class="hljs-keyword">DEFAULT</span> "新用户" COMMENT <span class="hljs-string">'用户名'</span>
)
<span class="hljs-comment">-- 存储引擎为InnoDB、编码格式为utf-8、字符排序规则为utf8_general_ci、行格式为Compact</span>
ENGINE <span class="hljs-operator">=</span> InnoDB 
<span class="hljs-type">CHARACTER</span> <span class="hljs-keyword">SET</span> <span class="hljs-operator">=</span> utf8 
<span class="hljs-keyword">COLLATE</span> <span class="hljs-operator">=</span> utf8_general_ci 
ROW_FORMAT <span class="hljs-operator">=</span> Compact;
<span class="copy-code-btn">复制代码</span></code></pre>
<p>上述代码块中就贴出了一个创建表的例子，大家在创建表时可根据需求自行选择需要的字段选项、表选项。</p>
<blockquote>
<p>接下来一起来看看其他关于表操作的<code>SQL</code>命令，但对于增删改查的命令会放在后面讲。</p>
</blockquote>
<ul>
<li><code>show table status like 'zz_users'\G;</code>：纵排输出一张表的状态信息。</li>
<li><code>alter table 表名 表选项;</code>：修改一张表的结构，如<code>alter table xxx engine=MyISAM</code>。</li>
<li><code>rename table 表名 to 新表名;</code>：修改一张表的表名。</li>
<li><code>alter table 表名 字段操作;</code>：修改一张表的字段结构，操作如下：
<ul>
<li><code>add column 字段名 数据类型</code>：向已有的表结构添加一个字段。</li>
<li><code>add primary key(字段名)</code>：将某个字段声明为主键。</li>
<li><code>add foreing key 外键字段 表名.字段名</code>：将一个字段设置为另一张表的外键。</li>
<li><code>add unique 索引名(字段名)</code>：为一个字段创建唯一索引。</li>
<li><code>add index 索引名(字段名)</code>：为一个字段创建普通索引。</li>
<li><code>drop column 字段名</code>：在已有的表结构中删除一个字段。</li>
<li><code>modify column 字段名 字段选项</code>：修改一个字段的字段选项。</li>
<li><code>change column 字段名 新字段名</code>：修改一个字段的字段名称。</li>
<li><code>drop primary key</code>：移除表中的主键。</li>
<li><code>drop index 索引名</code>：删除表中的一个索引。</li>
<li><code>drop foreing key 外键</code>：删除表中的一个外键。</li>
</ul>
</li>
<li><code>drop table if exists 表名</code>：如果一张表存在，则删除对应的表。</li>
<li><code>truncate table 表名</code>：清空一张表的所有数据。</li>
<li><code>create table 表名 like 要复制的表名</code>：复制一张表的结构，然后创建一张新表。</li>
<li><code>create table 表名 as select * from 要复制的表名</code>：同时复制表结构和数据创建新表。</li>
</ul>
<h3 data-id="heading-5">1.4、表的分析、检查、修复与优化操作</h3>
<p><code>MySQL</code>本身提供了一系列关于表的分析、检查与优化命令：</p>
<ul>
<li>①分析表：分析表中键的分布，如主键、唯一键、外键等是否合理。</li>
<li>②检查表：检查表以及表的数据文件是否存在错误。</li>
<li>③修复表：当一个表的数据或结构文件损坏时，可以修复表结构（仅支持<code>MyISAM</code>表）。</li>
<li>④优化表：消除<code>delete、update</code>语句执行时造成的空间浪费。</li>
</ul>
<h4 data-id="heading-6">分析表</h4>
<p>语法如下：</p>
<pre><code class="hljs language-sql copyable" lang="sql">analyze [<span class="hljs-keyword">local</span> <span class="hljs-operator">|</span> no_write_to_binlog] <span class="hljs-keyword">table</span> 表名<span class="hljs-number">1</span>;
<span class="copy-code-btn">复制代码</span></code></pre>
<p>其中的可选参数<code>local、no_write_to_binlog</code>代表是否将本条<code>SQL</code>记录进<code>bin-log</code>日志，默认情况下是记录的，加上这两个参数中的其中一个后则不会记录，执行效果如下：<br>
<img src="https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0cd0bb044c31492bbe454d50e1ba7dea~tplv-k3u1fbpfcp-zoom-in-crop-mark:4536:0:0:0.awebp?" alt="分析表" loading="lazy" class="medium-zoom-image"><br>
如果<code>Msg_text</code>显示的是<code>OK</code>，则代表这张表的键不存在问题，存在问题的情况我这边就不模拟了，后面举例聊。</p>
<h4 data-id="heading-7">检查表</h4>
<p>语法如下：</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-keyword">check</span> <span class="hljs-keyword">table</span> 表名<span class="hljs-number">1</span>,表名<span class="hljs-number">2.</span>.. [检查选项];
<span class="copy-code-btn">复制代码</span></code></pre>
<p>分析、检查、优化、修复的命令都支持同时操作多张表，不同的表之间只需用<code>,</code>逗号隔开即可。检查命令有多个可选项，如下：</p>
<ul>
<li><code>quick</code>：不扫描行数据，不检查链接错误，仅检查表结构是否有问题。</li>
<li><code>fast</code>：只检查表使用完成后，是否正确关闭了表文件的<code>FD</code>文件描述符。</li>
<li><code>changed</code>：从上述检查过的位置开始，只检查被更改的表数据。</li>
<li><code>medium</code>：检查行数据，收集每一行数据的键值（主键、外键...），并计算校验和，验证数据是否正确。</li>
<li><code>extended</code>：对每行数据的所有字段值进行检查，检查完成后可确保数据<code>100%</code>正确。</li>
</ul>
<p>先来看看执行结果吧，如下：<br>
<img src="https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bdbb69f859144beaa539b5f673a15699~tplv-k3u1fbpfcp-zoom-in-crop-mark:4536:0:0:0.awebp?" alt="检查表" loading="lazy" class="medium-zoom-image"><br>
这回的结果出现了些许不同，<code>Msg_text</code>中出现了一个<code>Error</code>信息，提示咱们检查的<code>zz_u</code>表不存在，而对于一张存在的<code>zz_users</code>表，则返回<code>OK</code>，表示没有任何问题。</p>
<blockquote>
<p>当然，这里对于其他的检查选项就不做测试了，大家可以自行实验，比如把表的结构文件或数据文件，在本地打开手动删除前面的一点点数据，然后再执行检查命令，其实你也可以观察到，提示“数据不完整”的信息（但需要先停止运行<code>MySQL</code>，并且用本地表测试，不要用线上表瞎搞）。</p>
</blockquote>
<h4 data-id="heading-8">修复表</h4>
<p>语法如下：</p>
<pre><code class="hljs language-sql copyable" lang="sql">repair [<span class="hljs-keyword">local</span> <span class="hljs-operator">|</span> no_write_to_binlog] <span class="hljs-keyword">table</span> 表名 [quick] [extended] [use_frm];
<span class="copy-code-btn">复制代码</span></code></pre>
<p>值得一提的是，修复表的命令不支持<code>InnoDB</code>引擎，仅支持<code>MyISAM、CSV、</code>引擎，比如基于<code>InnoDB</code>引擎的表执行修复命令时，提示如下：<br>
<img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3e6fca7f22054fc682a0f5a73e65d72e~tplv-k3u1fbpfcp-zoom-in-crop-mark:4536:0:0:0.awebp?" alt="修复表" loading="lazy" class="medium-zoom-image"><br>
上述<code>Msg_text</code>信息翻译过来的意思是：选择的表其引擎并不支持修复命令。</p>
<blockquote>
<p><code>InnoDB</code>引擎其实也有修复机制，可以在<code>my.ini/my.conf</code>文件中加一行配置：<code>[mysqld]innodb_force_recovery = 1</code>，这样在启动时会强制恢复<code>InnoDB</code>的数据。</p>
</blockquote>
<p>上述这个修复机制默认是不开启的，因为<code>InnoDB</code>不需要这个恢复机制，毕竟之前在<a href="https://juejin.cn/post/7160557698642083847" target="_blank" title="https://juejin.cn/post/7160557698642083847">《引擎篇》</a>中聊过：<code>InnoDB</code>有完善的事务和持久化机制，客户端提交的事务都会持久化到磁盘，除非你人为损坏<code>InnoDB</code>的数据文件，否则基本上不会出现<code>InnoDB</code>数据损坏的情况。</p>
<h4 data-id="heading-9">优化表</h4>
<p>语法如下：</p>
<pre><code class="hljs language-sql copyable" lang="sql">optimize [<span class="hljs-keyword">local</span> <span class="hljs-operator">|</span> no_write_to_binlog] <span class="hljs-keyword">table</span> 表名;
<span class="copy-code-btn">复制代码</span></code></pre>
<p>这里值得一提的是：此优化非彼优化，并不意味着你的表存在性能问题，执行后它会自动调优，而是指清除老数据，执行效果如下：<br>
<img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ff05e705aec248b99038ab0c1e485ba1~tplv-k3u1fbpfcp-zoom-in-crop-mark:4536:0:0:0.awebp?" alt="优化表" loading="lazy" class="medium-zoom-image"><br>
还记得之前在<a href="https://juejin.cn/post/7155359629050904584" target="_blank" title="https://juejin.cn/post/7155359629050904584">《MVCC机制》</a>中聊过的隐藏字段嘛？其实删除一条数据本质上并不会立马从磁盘移除，而是会先改掉隐藏的删除标识位，执行这条优化命令后，<code>MySQL</code>会将一些已经<code>delete</code>过的数据彻底从磁盘删除，从而释放这些“废弃数据”占用的空间。</p>
<blockquote>
<p>上面的执行结果显示：“目前表的数据已经是最新的了”，这是啥原因呢？因为我这张表中压根没有数据，哈哈哈，没有插入过数据，自然也不会有删除数据的动作，因此就会出现这个提示。</p>
</blockquote>
<p>OK~，到这里对于分析表、检查表、修复表以及优化表就已经介绍清楚啦！其实这几个功能，在<code>mysqlcheck</code>工具中也有提供。</p>
<h3 data-id="heading-10">1.5、MySQL忘记密码怎么办？</h3>
<p>到这里，对于一些MySQL基础命令、库表命令就打住了，最后再来讲一个比较实用的知识点：<strong><code>MySQL</code>忘记密码怎么办</strong>？对于这种情况其实也十分常见，哪忘记时该如何处理呢？可以重置密码！</p>
<p>①先停掉<code>MySQL</code>的后台服务：</p>
<ul>
<li><code>Windows</code>系统请执行：<code>net stop mysql</code></li>
<li><code>Linux</code>系统请执行：<code>安装目录/mysql shutdown</code>（<code>kill</code>强杀进程也可以）</li>
</ul>
<p>②进入到<code>MySQL</code>安装目录下的<code>bin</code>文件夹内，执行<code>mysqld --skip-grant-tables</code>去掉连接认证。</p>
<p>③因为上面关掉了连接认证，接着输入<code>mysql</code>敲下回车，进入<code>mysql</code>终端命令行。</p>
<p>④输入<code>use mysql;</code>，进入<code>MySQL</code>自身的系统数据库，然后输入<code>show tables;</code>查看所有表。</p>
<p>⑤查询<code>MySQL</code>中注册的所有用户：<code>select user,host,password from user;</code>。</p>
<p>⑥使用<code>update</code>语句，更改<code>root</code>超级管理员的账号密码，如下：</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-keyword">update</span> <span class="hljs-keyword">user</span> <span class="hljs-keyword">set</span> password<span class="hljs-operator">=</span>password(<span class="hljs-string">'123'</span>) <span class="hljs-keyword">where</span> <span class="hljs-keyword">user</span><span class="hljs-operator">=</span>"root" <span class="hljs-keyword">and</span> host<span class="hljs-operator">=</span>"localhost";
<span class="copy-code-btn">复制代码</span></code></pre>
<blockquote>
<p>因为<code>MySQL</code>本身会用一张用户表来存储所有已创建的账号信息，连接时的效验基准也是来自于该表中的数据，因此在这里修改密码后，再用新密码登录即可！</p>
</blockquote>
<p>如果不是<code>root</code>账号的密码忘记了，则可以直接登录<code>root</code>账号修改其他用户的密码，如果是<code>root</code>账号则按照上述流程操作。</p>
<blockquote>
<p>完成之后可以用<code>mysql -uroot -p123</code>连接一下，测试密码是否被重置。</p>
</blockquote>
<h2 data-id="heading-11">二、增删改查语句</h2>
<h3 data-id="heading-12">2.1、基本的增删改查语句</h3>
<h4 data-id="heading-13">插入数据</h4>
<p>增删改查俗称为<code>CRUD</code>，这也是<code>MySQL</code>运行之后执行次数最多的一类<code>SQL</code>语句，同时也是每位开发者写的最多的<code>SQL</code>语句，接下来则说说这块的语句，首先登场的是咱们的几位老伙伴，即<code>insert、delete、update、select...</code>这类普通<code>SQL</code>语句。</p>
<ul>
<li><code>insert into 表名(字段名...) values(字段值...);</code>：向指定的表中插入一条数据。</li>
<li><code>insert into 表名(字段名...) values(字段值...),(...)...;</code>：向表中插入多条数据。</li>
<li><code>insert into 表名 set 字段名=字段值,...;</code>：插入一条数据，但只插入某个字段的值。</li>
</ul>
<p>如果要插入一条完整的数据，字段名可以用<code>*</code>代替所有字段，除开上述两种插入数据的基本方式外，还有几种批量插入的方式，如下：</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- 使用insert语句批量插入另一张表中查询的数据</span>
<span class="hljs-keyword">insert</span> <span class="hljs-keyword">into</span> 表名(字段名...) <span class="hljs-keyword">select</span> 字段名... <span class="hljs-keyword">from</span> 表名...;

<span class="hljs-comment">-- 使用replace语句来实现批量插入</span>
replace <span class="hljs-keyword">into</span> 表名(字段名<span class="hljs-number">1</span>,字段名<span class="hljs-number">2.</span>..) <span class="hljs-keyword">values</span>(字段值....),(字段值...),...;
<span class="copy-code-btn">复制代码</span></code></pre>

<p>上述批量插入数据的方式中，还可以通过<code>replace</code>关键字来实现插入，它与<code>insert</code>有啥区别呢？答案在于它可以实现批量更新，使用<code>replace</code>关键字来插入数据的表必须要有主键，<code>MySQL</code>会根据主键值来决定新增或修改数据，当批量插入的数据中，主键字段值在表中不存在时，则会向表中插入一条相应的数据，而当插入数据中的主键值存在时，则会使用新数据覆盖原有的老数据。</p>
<h4 data-id="heading-14">删除数据</h4>
<ul>
<li><code>delete from 表名;</code>：删除一张表的所有数据。</li>
<li><code>delete from 表名 where 条件;</code>：根据条件删除一条或多条数据。</li>
<li><code>truncate table 表名</code>：清空一张表的所有数据。</li>
</ul>
<h4 data-id="heading-15">修改数据</h4>
<ul>
<li><code>update 表名 set 字段名=字段值,...;</code>：修改表中所有记录的数据。</li>
<li><code>update 表名 set 字段名=字段值,... where 条件;</code>：根据条件修改一条或多条记录的数据。</li>
<li><code>replace 表名(字段名1,...) values(字段值...),...;</code>：批量修改对应主键记录的数据。</li>
</ul>
<h4 data-id="heading-16">查询数据</h4>
<ul>
<li><code>select * from 表名;</code>：查询一张表的所有数据。</li>
<li><code>select * from 表名 where 条件;</code>：根据条件查询表中相应的数据。</li>
<li><code>select 字段1,字段2... from 表名 where 条件;</code>：根据条件查询表中相应数据的指定字段。</li>
<li><code>select 函数(字段) from 表名;</code>：对查询后的结果集，进行某个函数的特殊处理。</li>
</ul>
<p>上述三种是最基本的查询方式，接着来看一些高级查询语法，如下：</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- 为查询出来的字段取别名</span>
<span class="hljs-keyword">select</span> 字段<span class="hljs-number">1</span> <span class="hljs-keyword">as</span> 别名,... <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 条件;
<span class="hljs-keyword">select</span> 字段<span class="hljs-number">1</span> 别名,... <span class="hljs-keyword">from</span> 表名;

<span class="hljs-comment">-- 为查询出的表取别名</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">as</span> 别名;

<span class="hljs-comment">-- 以多条件查询数据</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 字段<span class="hljs-number">1</span><span class="hljs-operator">=</span>值<span class="hljs-number">1</span> <span class="hljs-keyword">and</span> 字段<span class="hljs-number">2</span><span class="hljs-operator">=</span>值<span class="hljs-number">2</span> <span class="hljs-keyword">and</span> ...; <span class="hljs-comment">-- 所有条件都符合时才匹配</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 字段<span class="hljs-number">1</span><span class="hljs-operator">=</span>值<span class="hljs-number">1</span> <span class="hljs-keyword">or</span> 字段<span class="hljs-number">2</span><span class="hljs-operator">=</span>值<span class="hljs-number">2</span> <span class="hljs-keyword">or</span> ...; <span class="hljs-comment">-- 符合任意条件的数据都会返回</span>
<span class="hljs-comment">-- =符号，可以根据情况换为&gt;、&lt;、&gt;=、&lt;=、!=、between and、is null、not is null这些</span>

<span class="hljs-comment">-- 对查询后的结果集使用函数处理</span>
<span class="hljs-keyword">select</span> 函数(字段) <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 条件;

<span class="hljs-comment">-- 对查询条件使用函数处理</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 函数(条件);

<span class="hljs-comment">-- 模糊查询</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 字段 <span class="hljs-keyword">like</span> "%字符"; <span class="hljs-comment">-- 查询字段值以指定字符结尾的所有记录</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 字段 <span class="hljs-keyword">like</span> "字符%"; <span class="hljs-comment">-- 查询字段值以指定字符开头的所有记录</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 字段 <span class="hljs-keyword">like</span> "%字符%"; <span class="hljs-comment">-- 查询字段值包含指定字符的所有记录</span>

<span class="hljs-comment">-- 按照多值查询对应行记录</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 字段 <span class="hljs-keyword">in</span> (值<span class="hljs-number">1</span>，值<span class="hljs-number">2</span>,...);
<span class="hljs-comment">-- 按照多值查询相反的行记录</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 字段 <span class="hljs-keyword">not</span> <span class="hljs-keyword">in</span> (值<span class="hljs-number">1</span>，值<span class="hljs-number">2</span>,...);
<span class="hljs-comment">-- 基于多个字段做多值查询</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> (字段<span class="hljs-number">1</span>,字段<span class="hljs-number">2.</span>..) <span class="hljs-keyword">in</span> ((值<span class="hljs-number">1</span>，值<span class="hljs-number">2</span>,...),(...),...);

<span class="hljs-comment">-- 只需要查询结果中的前N条数据</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 limit N;
<span class="hljs-comment">-- 返回查询结果中 N~M 区间的数据</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 limit N,M;

<span class="hljs-comment">-- 联合多条SQL语句查询（union all表示不去重，union表示对查询结果去重）</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 条件
<span class="hljs-keyword">union</span> <span class="hljs-keyword">all</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 条件;
<span class="copy-code-btn">复制代码</span></code></pre>

<p>当然，对于<code>MySQL</code>中支持的函数稍后再展开聊，下面再聊聊一些其他的高级查询语法，如分组、过滤、子查询、关联查询等。</p>
<h5 data-id="heading-17">分组过滤、数据排序</h5>
<p>写<code>SQL</code>语句时，有些需求往往无法通过最基本的查询语句来实现，因此就需要用到一些高级的查询语法，例如分组、过滤、排序等操作，接着先聊聊这个，语法如下：</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- 基于一个字段进行排序查询</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">order</span> <span class="hljs-keyword">by</span> 字段名 <span class="hljs-keyword">asc</span>; <span class="hljs-comment">-- 按字段值正序返回结果集</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">order</span> <span class="hljs-keyword">by</span> 字段名 <span class="hljs-keyword">desc</span>; <span class="hljs-comment">-- 按字段值倒序返回结果集</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">order</span> <span class="hljs-keyword">by</span> 字段<span class="hljs-number">1</span> <span class="hljs-keyword">asc</span>,字段<span class="hljs-number">2</span> <span class="hljs-keyword">desc</span>; <span class="hljs-comment">-- 按照多字段进行排序查询</span>

<span class="hljs-comment">-- 基于字段进行分组</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">group</span> <span class="hljs-keyword">by</span> 字段<span class="hljs-number">1</span>,字段<span class="hljs-number">2.</span>...;

<span class="hljs-comment">-- 基于分组查询后的结果做条件过滤</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">group</span> <span class="hljs-keyword">by</span> 字段<span class="hljs-number">1</span> <span class="hljs-keyword">having</span> 条件;
<span class="copy-code-btn">复制代码</span></code></pre>

<p>实际上<code>group by、having</code>这些语句，更多的要配合一些聚合函数使用，如<code>min()、max()、count()、sum()、avg()....</code>，这样才能更符合业务需求，但对于聚合函数后面再介绍，先简单说说<code>where、having</code>的区别：</p>
<blockquote>
<p>这两个关键字都是用来做条件过滤的，但<code>where</code>优先级会比<code>group by</code>高，因此当分组后需要再做条件过滤时，就无法使用<code>where</code>来做筛选，而<code>having</code>就是用来对分组后的结果做条件过滤的。查询语句中的各类关键字执行优先级为：<code>from → where → select → group by → having → order by</code>。</p>
</blockquote>
<h5 data-id="heading-18">子查询</h5>
<p>子查询也可以理解成是查询嵌套，是指一种由多条<code>SQL</code>语句组成的查询语句，语法如下：</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- 基于一条SQL语句的查询结果进一步做查询</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> (<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 条件) <span class="hljs-keyword">as</span> 别名 <span class="hljs-keyword">where</span> 条件;

<span class="hljs-comment">-- 将一条SQL语句的查询结果作为条件继续查询（只适用于子查询返回单值的情况）</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 字段名 <span class="hljs-operator">=</span> (<span class="hljs-keyword">select</span> 字段名 <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 条件);

<span class="hljs-comment">-- 将一条SQL语句的查询结果作为条件继续查询（适用于子查询返回多值的情况）</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 字段名 <span class="hljs-keyword">exists</span> (<span class="hljs-keyword">select</span> 字段名 <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 条件);
<span class="hljs-comment">-- 上述的exists可以换为not exists，表示查询不包含相应条件的数据</span>

<span class="hljs-comment">-- 将一条SQL语句的多个查询结果，作为条件与多个字段进行范围查询</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> (字段<span class="hljs-number">1</span>,字段<span class="hljs-number">2.</span>..) <span class="hljs-keyword">in</span> (<span class="hljs-keyword">select</span> 字段<span class="hljs-number">1</span>,字段<span class="hljs-number">2.</span>.. <span class="hljs-keyword">from</span> 表名);
<span class="copy-code-btn">复制代码</span></code></pre>

<p>在上述子查询语法中，<code>exists</code>的作用和<code>in</code>大致相同，只不过<code>not in</code>时会触发全表扫描，而<code>not exists</code>依旧可以走索引查询，因此通常情况下尽量使用<code>not exists</code>代替<code>not in</code>来查询数据。</p>
<h5 data-id="heading-19">关联查询</h5>
<p>关联查询也被称之为连表查询，也就是指利用主外键连接多张表去查询数据，这几乎也是日常开发中写的最多的一类查询语句，<code>MySQL</code>中支持多种关联类型，如：</p>
<ul>
<li>交叉连接</li>
<li>内连接</li>
<li>外连接：
<ul>
<li>左连接</li>
<li>右连接</li>
<li>全连接</li>
</ul>
</li>
</ul>
<p>语法如下：</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- 交叉连接：默认把前一张表的每一行数据与后一张表的所有数据做关联查询</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表<span class="hljs-number">1</span>,表<span class="hljs-number">2.</span>..; <span class="hljs-comment">-- 这种方式默认采用交叉连接的方式</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表<span class="hljs-number">1</span> <span class="hljs-keyword">cross</span> <span class="hljs-keyword">join</span> 表<span class="hljs-number">2</span>; <span class="hljs-comment">-- 显式声明采用交叉连接的方式</span>

<span class="hljs-comment">-- 内连接：只返回两张表条件都匹配的数据</span>
<span class="hljs-comment">-- 隐式的内连接写法</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表<span class="hljs-number">1</span>,表<span class="hljs-number">2.</span>.. <span class="hljs-keyword">where</span> 表<span class="hljs-number">1.</span>字段 <span class="hljs-operator">=</span> 表<span class="hljs-number">2.</span>字段 ...;
<span class="hljs-comment">-- 等值内连接</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表<span class="hljs-number">1</span> 别名<span class="hljs-number">1</span> <span class="hljs-keyword">inner</span> <span class="hljs-keyword">join</span> 表<span class="hljs-number">2</span> 别名<span class="hljs-number">2</span> <span class="hljs-keyword">on</span> 别名<span class="hljs-number">1.</span>字段 <span class="hljs-operator">=</span> 别名<span class="hljs-number">2.</span>字段;
<span class="hljs-comment">-- 不等式内连接</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表<span class="hljs-number">1</span> 别名<span class="hljs-number">1</span> <span class="hljs-keyword">inner</span> <span class="hljs-keyword">join</span> 表<span class="hljs-number">2</span> 别名<span class="hljs-number">2</span> <span class="hljs-keyword">on</span> 别名<span class="hljs-number">1.</span>字段 <span class="hljs-operator">&lt;</span> 别名<span class="hljs-number">2.</span>字段;

<span class="hljs-comment">-- 左外连接：左表为主，右表为次，无论左表在右表是否匹配，都返回左表数据，缺失的右表数据显示NULL</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表<span class="hljs-number">1</span> <span class="hljs-keyword">left</span> <span class="hljs-keyword">join</span> 表<span class="hljs-number">2</span> <span class="hljs-keyword">on</span> 表<span class="hljs-number">1.</span>字段 <span class="hljs-operator">=</span> 表<span class="hljs-number">2.</span>字段;

<span class="hljs-comment">-- 右外连接：和左连接相反，右表为主，左表为次，永远返回右表的所有数据</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表<span class="hljs-number">1</span> <span class="hljs-keyword">right</span> <span class="hljs-keyword">join</span> 表<span class="hljs-number">2</span> <span class="hljs-keyword">on</span> 表<span class="hljs-number">1.</span>字段 <span class="hljs-operator">=</span> 表<span class="hljs-number">2.</span>字段;

<span class="hljs-comment">-- 全外连接：两张表没有主次之分，每次查询都会返回两张表的所有数据，不匹配的显示NULL</span>
<span class="hljs-comment">-- MySQL中不支持全连接语法，只能通过union all语句，将左、右连接查询拼接起来实现</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表<span class="hljs-number">1</span> <span class="hljs-keyword">left</span> <span class="hljs-keyword">join</span> 表<span class="hljs-number">2</span> <span class="hljs-keyword">on</span> 表<span class="hljs-number">1.</span>字段 <span class="hljs-operator">=</span> 表<span class="hljs-number">2.</span>字段
<span class="hljs-keyword">union</span> <span class="hljs-keyword">all</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表<span class="hljs-number">1</span> <span class="hljs-keyword">right</span> <span class="hljs-keyword">join</span> 表<span class="hljs-number">2</span> <span class="hljs-keyword">on</span> 表<span class="hljs-number">1.</span>字段 <span class="hljs-operator">=</span> 表<span class="hljs-number">2.</span>字段;

<span class="hljs-comment">-- 继续拼接查询两张以上的表</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表<span class="hljs-number">1</span> <span class="hljs-keyword">left</span> <span class="hljs-keyword">join</span> 表<span class="hljs-number">2</span> <span class="hljs-keyword">on</span> 表<span class="hljs-number">1.</span>字段 <span class="hljs-operator">=</span> 表<span class="hljs-number">2.</span>字段 <span class="hljs-keyword">left</span> <span class="hljs-keyword">join</span> 表<span class="hljs-number">3</span> <span class="hljs-keyword">on</span> 表<span class="hljs-number">2.</span>字段 <span class="hljs-operator">=</span> 表<span class="hljs-number">3.</span>字段;
<span class="hljs-comment">-- 通过隐式连接的方式，查询两张以上的表</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表<span class="hljs-number">1</span>,表<span class="hljs-number">2</span>,表<span class="hljs-number">3.</span>.. <span class="hljs-keyword">where</span> 表<span class="hljs-number">1.</span>字段 <span class="hljs-operator">=</span> 表<span class="hljs-number">2.</span>字段 <span class="hljs-keyword">and</span> 表<span class="hljs-number">1.</span>字段 <span class="hljs-operator">=</span> 表<span class="hljs-number">3.</span>字段...;
<span class="hljs-comment">-- 通过子查询的方式，查询两张以上的表</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span>
(表<span class="hljs-number">1</span> <span class="hljs-keyword">as</span> 别名<span class="hljs-number">1</span> <span class="hljs-keyword">left</span> <span class="hljs-keyword">join</span> 表<span class="hljs-number">2</span> <span class="hljs-keyword">as</span> 别名<span class="hljs-number">2</span> <span class="hljs-keyword">on</span> 别名<span class="hljs-number">1.</span>字段 <span class="hljs-operator">=</span> 别名<span class="hljs-number">2.</span>字段)
<span class="hljs-keyword">left</span> <span class="hljs-keyword">join</span>
表<span class="hljs-number">3</span> <span class="hljs-keyword">as</span> 别名<span class="hljs-number">3</span> <span class="hljs-keyword">on</span> 别名<span class="hljs-number">1.</span>字段 <span class="hljs-operator">=</span> 别名<span class="hljs-number">3.</span>字段;
<span class="copy-code-btn">复制代码</span></code></pre>

<p>对于连表查询的语法相信大家都并不陌生，因此不做过多产生，重点讲一下多表联查时的笛卡尔积问题，所谓的笛卡尔积问题就是指两张表的所有数据都做关联查询，一般连表查询都需要指定连接的条件，但如果不指定时，<code>MySQL</code>默认会将左表每一条数据挨个和右表所有数据关联一次，然后查询一次数据。比如左表有<code>3</code>条数据，右表有<code>4</code>条数据，笛卡尔积情况出现时，一共就会查询出<code>3 x 4 = 12</code>条数据。</p>
<blockquote>
<p>笛卡尔积现象出现时，会随着表数据增长越来越大，因此在连表查询时一定要消除笛卡尔积问题，咋消除呢？其实就是指定加上关联条件即可。</p>
</blockquote>
<p>至此，对于一些增删改查的基本语句就已介绍清楚啦~，但实际业务开发过程中，往往会结合数据库所提供的函数一起操作，因此接下来再聊聊<code>MySQL</code>支持的函数。</p>
<h2 data-id="heading-20">三、MySQL数据库函数</h2>
<p><code>MySQL</code>中提供了丰富的函数支持，包括数学函数、字符串函数、日期和时间函数、条件判断函数、系统信息函数、加密函数、格式化函数等，通过这些函数，一方面可以简化业务的代码量，另一方面还能更好的实现各类特殊业务需求，下来一起来聊聊<code>MySQL</code>支持的函数。</p>
<h3 data-id="heading-21">3.1、数学函数</h3>
<p>数学函数是<code>MySQL</code>中最常用的一类函数，主要用来处理所有数值类型的字段值，一起来看看。</p>
<ul>
<li><code>abs(X)</code>：返回<code>X</code>的绝对值，如传进<code>-1</code>，则返回<code>1</code>。</li>
<li><code>ln(X)</code>：返回<code>X</code>的自然相对数。</li>
<li><code>log(X,Y)</code>：返回以<code>X</code>的以<code>Y</code>为底的对数。</li>
<li><code>log10(X)</code>:返回以<code>X</code>基数为<code>10</code>的对数。</li>
<li><code>bin(X)</code>：返回<code>X</code>的二进制值。</li>
<li><code>oct(X)</code>：返回<code>X</code>的八进制值。</li>
<li><code>hex(X)</code>：返回<code>X</code>的十六进制值。</li>
<li><code>mod(X,Y)</code>：返回<code>X</code>除以<code>Y</code>的余数。</li>
<li><code>ceil(X) | ceiling(X)</code>：返回不小于<code>X</code>的最小整数，如传入<code>1.23</code>，则返回<code>2</code>。</li>
<li><code>round(X)</code>：返回<code>X</code>四舍五入的整数。</li>
<li><code>floop(X)</code>：返回<code>X</code>向下取整后的值，如传入<code>2.34</code>，会返回<code>2</code>。</li>
<li><code>greatest(X1,X2....,Xn)</code>：返回集合中的最大整数值。</li>
<li><code>least(X1,X2....,Xn)</code>：返回集合中的最小整数值。</li>
<li><code>rand(N)</code>：返回一个<code>0~N``0~1</code>之间的随机小数（不传参默认返回<code>0~1</code>之间的随机小数）。</li>
<li><code>sign(X)</code>：传入正数，返回<code>1</code>；传入负数，返回<code>-1</code>；传入<code>0</code>，返回<code>0</code>。</li>
<li><code>pow(X,Y) | power(X,Y)</code>：返回<code>X</code>的<code>Y</code>次方值。</li>
<li><code>pi()</code>：返回四舍五入后的圆周率，<code>3.141593</code>。</li>
<li><code>sin(X)</code>：返回<code>X</code>的正弦值。</li>
<li><code>asin(X)</code>：返回<code>X</code>的反正弦值。</li>
<li><code>cos(X)</code>：返回<code>X</code>的余弦值。</li>
<li><code>acos(X)</code>：返回<code>X</code>的反余弦值。</li>
<li><code>tan(X)</code>：返回<code>X</code>的正切值。</li>
<li><code>atan(X)</code>：返回<code>X</code>的反正切值。</li>
<li><code>cot(X)</code>：返回<code>X</code>的余切值。</li>
<li><code>radians(x)</code>：返回<code>x</code>由角度转化为弧度的值。</li>
<li><code>degrees(x)</code>：返回<code>x</code>由弧度转化为角度的值。</li>
<li><code>sqrt(X)</code>：返回<code>X</code>的平方根。</li>
<li><code>exp(e,X)</code>：返回<code>e</code>的<code>x</code>乘方的值。</li>
<li><code>truncate(X,N)</code>：返回小数<code>X</code>保留<code>N</code>位精准度的小数。</li>
<li><code>format(x,y)</code>：将<code>x</code>格式化位以逗号隔开的数字列表，<code>y</code>是结果的小数位数。</li>
<li><code>inet_aton(ip)</code>：将<code>IP</code>地址以数字的形式展现。</li>
<li><code>inet_ntoa(number)</code>：显示数字代表的<code>IP</code>地址。</li>
<li><code>......</code></li>
</ul>
<h3 data-id="heading-22">3.2、字符串函数</h3>
<ul>
<li><code>ascii(C)</code>：返回字符<code>C</code>的<code>ASCII</code>码。</li>
<li><code>length(S)</code>：返回字符串的占位空间，传入“竹子爱熊猫”，返回<code>15</code>，一个汉字占位<code>3</code>字节。</li>
<li><code>bit_length(S)</code>：返回字符串的比特长度。</li>
<li><code>concat(S1,S2,...)</code>：合并传入的多个字符串。</li>
<li><code>concat_wa(sep,S1,S2...)</code>：合并传入的多个字符串，每个字符串之间用<code>sep</code>间隔。</li>
<li><code>position(str,s) | locate(str,s)</code>：返回<code>s</code>在<code>str</code>中第一次出现的位置，没有则返回<code>0</code>。</li>
<li><code>find_in_set(S,list)</code>：返回字符串<code>S</code>在<code>list</code>列表中的位置。</li>
<li><code>insert(S1,start,end,S2)</code>：使用<code>S2</code>字符串替换掉<code>S1</code>字符串中<code>start~end</code>的内容。</li>
<li><code>lcase(S) | lower(S)</code>：将传入的字符串中所有大写字母转换为小写。</li>
<li><code>ucase(S) | upper(S)</code>：将传入的字符串中所有小写字母转换为大写。</li>
<li><code>left(S,index)</code>：从左侧开始截取字符串<code>S</code>的<code>index</code>个字符。</li>
<li><code>right(S,index)</code>：从右侧开始截取字符串<code>S</code>的<code>index</code>个字符。</li>
<li><code>trim(S)</code>：删除字符<code>S</code>左右两侧的空格。</li>
<li><code>rtrim(S)</code>：删除字符<code>S</code>右侧的空格。</li>
<li><code>replace(S,old,new)</code>：使用<code>new</code>新字符替换掉<code>S</code>字符串中的<code>old</code>字符。</li>
<li><code>repeat(str,count)</code>：将<code>str</code>字符串重复<code>count</code>次后返回。</li>
<li><code>substring(S,index,N)</code>：截取<code>S</code>字符串，从<code>index</code>位置开始，返回长度为<code>N</code>的字符串。</li>
<li><code>reverse(S)</code>：将传入的字符串反转，即传入<code>Java</code>，返回<code>avaJ</code>。</li>
<li><code>quote(str)</code>：用反斜杠转移<code>str</code>中的英文单引号。</li>
<li><code>strcmp(S1,S2)</code>：比较两个字符是否相同。</li>
<li><code>lpad(str,len,s)</code>：对<code>str</code>字符串左边填充<code>len</code>个<code>s</code>字符。</li>
<li><code>rpad(str,len,s)</code>：对<code>str</code>字符串右边填充<code>len</code>个<code>s</code>字符。</li>
<li><code>......</code></li>
</ul>
<h3 data-id="heading-23">3.3、日期和时间函数</h3>
<ul>
<li><code>curdate() | current_date()</code>：返回当前系统的日期，如<code>2022-10-21</code>。</li>
<li><code>curtime() | current_time()</code>：返回当前系统的时间，如<code>17:30:52</code>。</li>
<li><code>now() | sysdate()</code>：返回当前系统的日期时间，如<code>2022-10-21 17:30:59</code>。</li>
<li><code>unix_timestamp()</code>：获取一个数值类型的<code>unix</code>时间戳，如<code>1666348711</code>。</li>
<li><code>from_unixtime()</code>：将<code>unix_timestamp()</code>获取的数值时间戳，格式化成日期格式。</li>
<li><code>month(date)</code>：获取<code>date</code>中的月份。</li>
<li><code>year(date)</code>：获取<code>date</code>中的年份。</li>
<li><code>hour(date)</code>：获取<code>date</code>中的小时。</li>
<li><code>minute(date)</code>：获取<code>date</code>中的分钟。</li>
<li><code>second(date)</code>：获取<code>date</code>中的秒数。</li>
<li><code>monthname(date)</code>：返回<code>date</code>中月份的英文名称。</li>
<li><code>dayname(date)</code>：获取日期<code>date</code>是星期几，如<code>Friday</code>。</li>
<li><code>dayofweek(date)</code>：获取<code>date</code>位于一周的索引位置，周日是<code>1</code>、周一是<code>2</code>...周六是<code>7</code>。</li>
<li><code>week(date)</code>：获取<code>date</code>是本年的第多少周。</li>
<li><code>quarter(date)</code>：获取<code>date</code>位于一年中的哪个季度（<code>1~4</code>）。</li>
<li><code>dayofyear(date)</code>：获取<code>date</code>是本年的第多少天。</li>
<li><code>dayofmonth(date)</code>：获取<code>date</code>是本月的第多少天。</li>
<li><code>time_to_sec(time)</code>：将传入的时间<code>time</code>转换为秒数，比如<code>"01:00:00" = 3600s</code>。</li>
<li><code>date_add(date,interval 时间 单位) | adddate(...)</code>：将<code>date</code>与给定的时间按单位相加。</li>
<li><code>date_sub(date,interval 时间 单位) | subdate(...)</code>：将<code>date</code>与给定的时间按单位相减。</li>
<li><code>addtime(date,time)</code>：将<code>date</code>加上指定的时间，如<code>addtime(now(),"01:01:01")</code>。</li>
<li><code>subtime(date,time)</code>：将<code>date</code>减去指定的时间。</li>
<li><code>datediff(date1,date2)</code>：计算两个日期之间的间隔天数。</li>
<li><code>last_day(date)</code>：获取<code>date</code>日期这个月的最后一天。</li>
<li><code>date_format(date,format)</code>：将一个日期格式化成指定格式，<code>format</code>可选项如下：
<ul>
<li><code>%a</code>：工作日的英文缩写（<code>Sun~Sat</code>）。</li>
<li><code>%b</code>：月份的英文缩写（<code>Jan~Dec</code>）。</li>
<li><code>%c</code>：月份的数字格式（<code>1~12</code>）。</li>
<li><code>%M</code>：月份的英文全称（<code>January~December</code>）。</li>
<li><code>%D</code>：带有英文后缀的数字月份（<code>1th、2st、3nd....</code>）。</li>
<li><code>%d</code>：一个月内的天数，双数形式（<code>01、02、03....31</code>）。</li>
<li><code>%e</code>：一个月内的天数，单数形式（<code>1、2、3、4....31</code>）。</li>
<li><code>%f</code>：微妙（<code>000000~999999</code>）。</li>
<li><code>%H</code>：一天内的小时，<code>24</code>小时的周期（<code>00、01、02...23</code>）。</li>
<li><code>%h | %I</code>：一天内的小时，<code>12</code>小时的周期（<code>01、02、03...12</code>）。</li>
<li><code>%i</code>：一小时内的分钟（<code>00~59</code>）。</li>
<li><code>%j</code>：一年中的天数（<code>001~366</code>）。</li>
<li><code>%k</code>：以<code>24</code>小时制显示时间（<code>00~23</code>）。</li>
<li><code>%l</code>：以<code>12</code>小时制显示时间（<code>01~12</code>）。</li>
<li><code>%m</code>：月份的数字形式，双数形式（<code>01~12</code>）。</li>
<li><code>%p</code>：一天内的时间段（上午<code>AM</code>、下午<code>PM</code>）。</li>
<li><code>%r</code>：<code>12</code>小时制的时间（<code>12:01:09 AM</code>）。</li>
<li><code>%S | %s</code>：秒数，双数形式（<code>00~59</code>）。</li>
<li><code>%T</code>：<code>24</code>小时制的时间（<code>23:18:22</code>）。</li>
<li><code>%U</code>：一年内的周（<code>00~53</code>）。</li>
</ul>
</li>
<li><code>time_format(time,format)</code>：将一个时间格式化成指定格式。</li>
<li><code>str_to_date(str,format)</code>：将日期字符串，格式化成指定格式。</li>
<li><code>timestampdiff(unit,start,end)</code>：计算两个日期之间间隔的具体时间，<code>unit</code>是单位：
<ul>
<li><code>year</code>：年。</li>
<li><code>quarter</code>：季度。</li>
<li><code>month</code>：月。</li>
<li><code>week</code>：周。</li>
<li><code>day</code>：天。</li>
<li><code>hour</code>：小时。</li>
<li><code>minute</code>：分钟。</li>
<li><code>second</code>：秒数。</li>
<li><code>microsecond</code>：微妙。</li>
</ul>
</li>
<li><code>weekday(date)</code>：返回<code>date</code>位于一周内的索引（<code>0</code>是周一...<code>6</code>是周日）。</li>
</ul>
<h3 data-id="heading-24">3.4、聚合函数</h3>
<p>聚合函数一般是会结合<code>select、group by having</code>筛选数据使用。</p>
<ul>
<li><code>max(字段名)</code>：查询指定字段值中的最大值。</li>
<li><code>min(字段名)</code>：查询指定字段值中的最小值。</li>
<li><code>count(字段名)</code>：统计查询结果中的行数。</li>
<li><code>sum(字段名)</code>：求和指定字段的所有值。</li>
<li><code>avg(字段名)</code>：对指定字段的所有值，求出平均值。</li>
<li><code>group_concat(字段名)</code>：返回指定字段所有值组合成的结果，如下：</li>
<li><code>distinct(字段名)</code>：对于查询结果中的指定的字段去重。</li>
</ul>
<p>这里稍微介绍一个日常业务中碰到次数较多的需求：</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> zz_users;
<span class="hljs-operator">+</span><span class="hljs-comment">---------+-----------+----------+----------+---------------------+</span>
<span class="hljs-operator">|</span> user_id <span class="hljs-operator">|</span> user_name <span class="hljs-operator">|</span> user_sex <span class="hljs-operator">|</span> password <span class="hljs-operator">|</span> register_time       <span class="hljs-operator">|</span>
<span class="hljs-operator">+</span><span class="hljs-comment">---------+-----------+----------+----------+---------------------+</span>
<span class="hljs-operator">|</span>       <span class="hljs-number">1</span> <span class="hljs-operator">|</span> 熊猫      <span class="hljs-operator">|</span> 女       <span class="hljs-operator">|</span> <span class="hljs-number">6666</span>     <span class="hljs-operator">|</span> <span class="hljs-number">2022</span><span class="hljs-number">-08</span><span class="hljs-number">-14</span> <span class="hljs-number">15</span>:<span class="hljs-number">22</span>:<span class="hljs-number">01</span> <span class="hljs-operator">|</span>
<span class="hljs-operator">|</span>       <span class="hljs-number">2</span> <span class="hljs-operator">|</span> 竹子      <span class="hljs-operator">|</span> 男       <span class="hljs-operator">|</span> <span class="hljs-number">1234</span>     <span class="hljs-operator">|</span> <span class="hljs-number">2022</span><span class="hljs-number">-09</span><span class="hljs-number">-14</span> <span class="hljs-number">16</span>:<span class="hljs-number">17</span>:<span class="hljs-number">44</span> <span class="hljs-operator">|</span>
<span class="hljs-operator">|</span>       <span class="hljs-number">3</span> <span class="hljs-operator">|</span> 子竹      <span class="hljs-operator">|</span> 男       <span class="hljs-operator">|</span> <span class="hljs-number">4321</span>     <span class="hljs-operator">|</span> <span class="hljs-number">2022</span><span class="hljs-number">-09</span><span class="hljs-number">-16</span> <span class="hljs-number">07</span>:<span class="hljs-number">42</span>:<span class="hljs-number">21</span> <span class="hljs-operator">|</span>
<span class="hljs-operator">|</span>       <span class="hljs-number">4</span> <span class="hljs-operator">|</span> 黑熊      <span class="hljs-operator">|</span> 男       <span class="hljs-operator">|</span> <span class="hljs-number">8888</span>     <span class="hljs-operator">|</span> <span class="hljs-number">2022</span><span class="hljs-number">-09</span><span class="hljs-number">-17</span> <span class="hljs-number">23</span>:<span class="hljs-number">48</span>:<span class="hljs-number">29</span> <span class="hljs-operator">|</span>
<span class="hljs-operator">|</span>       <span class="hljs-number">8</span> <span class="hljs-operator">|</span> 猫熊      <span class="hljs-operator">|</span> 女       <span class="hljs-operator">|</span> <span class="hljs-number">8888</span>     <span class="hljs-operator">|</span> <span class="hljs-number">2022</span><span class="hljs-number">-09</span><span class="hljs-number">-27</span> <span class="hljs-number">17</span>:<span class="hljs-number">22</span>:<span class="hljs-number">29</span> <span class="hljs-operator">|</span>
<span class="hljs-operator">|</span>       <span class="hljs-number">9</span> <span class="hljs-operator">|</span> 棕熊      <span class="hljs-operator">|</span> 男       <span class="hljs-operator">|</span> <span class="hljs-number">0369</span>     <span class="hljs-operator">|</span> <span class="hljs-number">2022</span><span class="hljs-number">-10</span><span class="hljs-number">-17</span> <span class="hljs-number">23</span>:<span class="hljs-number">48</span>:<span class="hljs-number">29</span> <span class="hljs-operator">|</span>
<span class="hljs-operator">+</span><span class="hljs-comment">---------+-----------+----------+----------+---------------------+</span>

<span class="hljs-comment">-- 基于性别字段分组，然后显示各组中的所有ID</span>
<span class="hljs-keyword">select</span>
<span class="hljs-keyword">convert</span>(
group_concat(user_id <span class="hljs-keyword">order</span> <span class="hljs-keyword">by</span> user_id <span class="hljs-keyword">asc</span> separator ",")
<span class="hljs-keyword">using</span> utf8) <span class="hljs-keyword">as</span> "分组统计"
<span class="hljs-keyword">from</span> `zz_users` <span class="hljs-keyword">group</span> <span class="hljs-keyword">by</span> user_sex;
<span class="hljs-operator">+</span><span class="hljs-comment">-------------+</span>
<span class="hljs-operator">|</span> 分组统计    <span class="hljs-operator">|</span>
<span class="hljs-operator">+</span><span class="hljs-comment">-------------+</span>
<span class="hljs-operator">|</span> <span class="hljs-number">1</span>,<span class="hljs-number">8</span>         <span class="hljs-operator">|</span>
<span class="hljs-operator">|</span> <span class="hljs-number">2</span>,<span class="hljs-number">3</span>,<span class="hljs-number">4</span>,<span class="hljs-number">9</span>     <span class="hljs-operator">|</span>
<span class="hljs-operator">+</span><span class="hljs-comment">-------------+</span>
<span class="copy-code-btn">复制代码</span></code></pre>

<p>上述利用了<code>group_concat()、group by</code>实现了按照一个字段分组后，显示对应分组的所有<code>ID</code>。</p>
<h3 data-id="heading-25">3.5、控制流程函数</h3>
<ul>
<li><code>if(expr,r1,r2)</code>：<code>expr</code>是表达式，如果成立返回<code>r1</code>，否则返回<code>r2</code>。</li>
<li><code>ifnull(v,r)</code>：如果<code>v</code>不为<code>null</code>则返回<code>v</code>，否则返回<code>r</code>。</li>
<li><code>nullif(v1,v2)</code>：如果<code>v1 == v2</code>，则返回<code>null</code>，如果不相等则返回<code>V1</code>。</li>
</ul>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- if的用例</span>
<span class="hljs-keyword">select</span> if(user_id <span class="hljs-operator">&gt;</span> <span class="hljs-number">3</span>,"√","×") <span class="hljs-keyword">from</span> zz_users;

<span class="hljs-comment">-- ifnull的用例</span>
<span class="hljs-keyword">select</span> ifnull(user_id,"×") <span class="hljs-keyword">from</span> zz_users;

<span class="hljs-comment">-- case语法1：</span>
<span class="hljs-keyword">case</span> <span class="hljs-operator">&lt;</span>表达式<span class="hljs-operator">&gt;</span>
<span class="hljs-keyword">when</span> <span class="hljs-operator">&lt;</span>值<span class="hljs-number">1</span><span class="hljs-operator">&gt;</span> <span class="hljs-keyword">then</span> <span class="hljs-operator">&lt;</span>操作<span class="hljs-operator">&gt;</span>
<span class="hljs-keyword">when</span> <span class="hljs-operator">&lt;</span>值<span class="hljs-number">2</span><span class="hljs-operator">&gt;</span> <span class="hljs-keyword">then</span> <span class="hljs-operator">&lt;</span>操作<span class="hljs-operator">&gt;</span>
...
<span class="hljs-keyword">else</span> <span class="hljs-operator">&lt;</span>操作<span class="hljs-operator">&gt;</span>
<span class="hljs-keyword">end</span>;
<span class="hljs-comment">-- 用例：判断当前时间是星期几</span>
<span class="hljs-keyword">select</span> <span class="hljs-keyword">case</span> weekday(now())
<span class="hljs-keyword">when</span> <span class="hljs-number">0</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期一'</span>
<span class="hljs-keyword">when</span> <span class="hljs-number">1</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期二'</span>
<span class="hljs-keyword">when</span> <span class="hljs-number">2</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期三'</span>
<span class="hljs-keyword">when</span> <span class="hljs-number">3</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期四'</span>
<span class="hljs-keyword">when</span> <span class="hljs-number">4</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期五'</span>
<span class="hljs-keyword">when</span> <span class="hljs-number">5</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期六'</span>
<span class="hljs-keyword">else</span> <span class="hljs-string">'星期天'</span>
<span class="hljs-keyword">end</span> <span class="hljs-keyword">as</span> "今天是星期几？";

<span class="hljs-comment">-- case语法2：</span>
<span class="hljs-keyword">case</span>
<span class="hljs-keyword">when</span> <span class="hljs-operator">&lt;</span>条件<span class="hljs-number">1</span><span class="hljs-operator">&gt;</span> <span class="hljs-keyword">then</span> <span class="hljs-operator">&lt;</span>命令<span class="hljs-operator">&gt;</span>
<span class="hljs-keyword">when</span> <span class="hljs-operator">&lt;</span>条件<span class="hljs-number">2</span><span class="hljs-operator">&gt;</span> <span class="hljs-keyword">then</span> <span class="hljs-operator">&lt;</span>命令<span class="hljs-operator">&gt;</span>
...
<span class="hljs-keyword">else</span> commands
<span class="hljs-keyword">end</span>;
<span class="hljs-comment">-- 用例：判断今天是星期几</span>
<span class="hljs-keyword">select</span> <span class="hljs-keyword">case</span>
<span class="hljs-keyword">when</span> weekday(now()) <span class="hljs-operator">=</span> <span class="hljs-number">0</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期一'</span>
<span class="hljs-keyword">when</span> weekday(now()) <span class="hljs-operator">=</span> <span class="hljs-number">1</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期二'</span>
<span class="hljs-keyword">when</span> weekday(now()) <span class="hljs-operator">=</span> <span class="hljs-number">2</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期三'</span>
<span class="hljs-keyword">when</span> weekday(now()) <span class="hljs-operator">=</span> <span class="hljs-number">3</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期四'</span>
<span class="hljs-keyword">when</span> weekday(now()) <span class="hljs-operator">=</span> <span class="hljs-number">4</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期五'</span>
<span class="hljs-keyword">when</span> weekday(now()) <span class="hljs-operator">=</span> <span class="hljs-number">5</span> <span class="hljs-keyword">then</span> <span class="hljs-string">'星期六'</span>
<span class="hljs-keyword">else</span> <span class="hljs-string">'星期天'</span>
<span class="hljs-keyword">end</span> <span class="hljs-keyword">as</span> "今天是星期几？";
<span class="copy-code-btn">复制代码</span></code></pre>

<p>简单聊一下<code>CASE</code>语法，第一种语法就类似于<code>Java</code>中的<code>switch</code>，而第二种语法就类似于多重<code>if</code>，通过<code>CASE</code>语法能够让<code>SQL</code>更加灵活，完成类似于存储过程的工作。</p>
<h3 data-id="heading-26">3.6、加密函数</h3>
<ul>
<li><code>password(str)</code>：将<code>str</code>字符串以数据库密码的形式加密，一般用在设置<code>DB</code>用户密码上。</li>
<li><code>md5(str)</code>：对<code>str</code>字符串以<code>MD5</code>不可逆算法模式加密。</li>
<li><code>encode(str,key)</code>：通过<code>key</code>密钥对<code>str</code>字符串进行加密（对称加密算法）。</li>
<li><code>decode(str,key)</code>：通过<code>key</code>密钥对<code>str</code>字符串进行解密。</li>
<li><code>aes_encrypt(str,key)</code>：通过<code>key</code>密钥对<code>str</code>字符串，以<code>AES</code>算法进行加密。</li>
<li><code>aes_decrypt(str,key)</code>：通过<code>key</code>密钥对<code>str</code>字符串，以<code>AES</code>算法进行解密。</li>
<li><code>sha(str)</code>：计算<code>str</code>字符串的散列算法校验值。</li>
<li><code>encrypt(str,salt)</code>：使用<code>salt</code>盐值对<code>str</code>字符串进行加密。</li>
<li><code>decrypt(str,salt)</code>：使用<code>salt</code>盐值对<code>str</code>字符串进行解密。</li>
</ul>
<h3 data-id="heading-27">3.7、系统函数</h3>
<ul>
<li><code>version()</code>：查询当前数据库的版本。</li>
<li><code>connection_id()</code>：返回当前数据库连接的<code>ID</code>。</li>
<li><code>database() | schema()</code>：返回当前连接位于哪个数据库，即<code>use</code>进入的库。</li>
<li><code>user()</code>：查询当前的登录的所有用户信息。</li>
<li><code>system_user()</code>：返回当前登录的所有系统用户信息。</li>
<li><code>session_user()</code>：查询所有连接的用户信息。</li>
<li><code>current_user()</code>：查询当前连接的用户信息。</li>
<li><code>charset(str)</code>：返回当前数据库的编码格式。</li>
<li><code>collation(str)</code>：返回当前数据库的字符排序规则。</li>
<li><code>benchmark(count,expr)</code>：将<code>expr</code>表达式重复运行<code>count</code>次。</li>
<li><code>found_rows()</code>：返回最后一个<code>select</code>查询语句检索的数据总行数。</li>
<li><code>cast(v as 类型)</code>：将<code>v</code>转换为指定的数据类型。</li>
</ul>
<h3 data-id="heading-28">3.8、......</h3>
<blockquote>
<p>除开上述这些函数之外，其实在<code>MySQL</code>还有很多很多的函数，但目前几乎已经将所有常用的函数全部列出来了，因此对于其他偏冷门一些的函数就不再介绍。当然，就算你需要的某个功能在<code>MySQL</code>中没有提供函数支持，你也可以通过<code>create function</code>的方式自定义存储函数，其逻辑与上篇讲到的<a href="https://juejin.cn/post/7161662496460242980" target="_blank" title="https://juejin.cn/post/7161662496460242980">《MySQL存储过程》</a>大致相同。</p>
</blockquote>
<h2 data-id="heading-29">四、MySQL支持的数据类型</h2>
<p>这里所谓的数据类型，也就是只在创建表时可以选择的列字段类型，在<code>MySQL</code>中其实可以通过：</p>
<ul>
<li><code>help data types;</code>：查看当前版本支持的所有数据类型。如下(<code>MySQL5.1</code>版本)：</li>
</ul>
<p><img src="https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/25042ebb408e44dda16b3ebff5d48129~tplv-k3u1fbpfcp-zoom-in-crop-mark:4536:0:0:0.awebp?" alt="数据类型" loading="lazy" class="medium-zoom-image"><br>
总体可分为数值类型、字符/串类型、时间/日期类型、其他类型四种，下面一起来聊聊吧。</p>
<h3 data-id="heading-30">4.1、数值类型</h3>
<ul>
<li><code>tinyint</code>：小整数类型，占位<code>1Bytes</code>，取值范围<code>-128~127</code>。</li>
<li><code>smallint</code>：中整数类型，占位<code>2Bytes</code>，取值范围<code>-32768~32767</code>。</li>
<li><code>mediumint</code>：中大整数类型，占位<code>3Bytes</code>，取值范围<code>-8388608~8388607</code>。</li>
<li><code>int | integer</code>：常用整数类型，占位<code>4Bytes</code>，取值范围<code>-2147483548~2147483647</code>。</li>
<li><code>bigint</code>：超大整数类型，占位<code>8Bytes</code>，取值范围<code>-9223372036854775808~9223372036854775807</code>。</li>
<li><code>float</code>：单精度浮点数类型，占位<code>4Bytes</code>，取值范围<code>-3.4E+38 ~ 3.4E+38</code>。</li>
<li><code>double</code>：双精度浮点数类型，占位<code>8Bytes</code>，取值范围<code>-1.7E-308～1.7E+308</code>。</li>
<li><code>decimal(m,d)</code>：小数类型，占位和取值范围都依赖<code>m、d</code>值决定，<code>m</code>是小数点后面的精度，<code>d</code>是小数点前面的标度。</li>
<li><code>bit(m)</code>：存储位值，可存储<code>m</code>个比特位，取值范围是<code>1~64</code>。</li>
</ul>
<h3 data-id="heading-31">4.2、字符串类型</h3>
<ul>
<li><code>char</code>：定长字符串类型，存储空间<code>0~255Bytes</code>。</li>
<li><code>varchar</code>：变长字符串类型，存储空间<code>0~65535Bytes</code>。</li>
<li><code>tinyblob</code>：二进制短字符串类型，存储空间<code>0~255Bytes</code>。</li>
<li><code>tinytext</code>：短文本字符串类型，存储空间<code>0~255Bytes</code>。</li>
<li><code>blob</code>：二进制长字符串类型，存储空间<code>0~65535Bytes</code>。</li>
<li><code>text</code>：长文本字符串类型，存储空间<code>0~65535Bytes</code>。</li>
<li><code>mediumblob</code>：二进制大字符串类型，存储空间<code>0~16777215Bytes</code>。</li>
<li><code>mediumtext</code>：大文本字符串类型，存储空间<code>0~16777215Bytes</code>。</li>
<li><code>longblob</code>：二进制超大字符串类型，存储空间<code>0~4294967295Bytes</code>。</li>
<li><code>longtext</code>：超大文本字符串类型，存储空间<code>0~4294967295Bytes</code>。</li>
<li><code>binary(m)</code>：定长字符串类型，存储空间为<code>M</code>个字符。</li>
<li><code>varbinary(m)</code>：定长字符串类型，存储空间为<code>M</code>个字符<code>+1</code>个字节。</li>
</ul>
<p>一般在为列指定数据类型时，都会<code>varchar(255)</code>这样写，其实中间的这个数字限制的并不是字节长度，而是字符数量，比如<code>varchar(255)</code>，表示该列最大能存储<code>255</code>个字符。</p>
<h3 data-id="heading-32">4.3、时间/日期类型</h3>
<ul>
<li><code>date</code>：日期类型，占位<code>3Bytes</code>，格式为<code>YYYY-MM-DD</code>。</li>
<li><code>time</code>：时间类型，占位<code>3Bytes</code>，格式为<code>hh:mm:ss</code>。</li>
<li><code>year</code>：年份类型，占位<code>1Bytes</code>，格式为<code>YYYY</code>。</li>
<li><code>datetime</code>：日期时间类型，占位<code>8Bytes</code>，格式为<code>YYYY-MM-DD hh:mm:ss</code>。</li>
<li><code>timestamp</code>：时间戳类型，占位<code>4Bytes</code>，格式为<code>YYYYMMDDhhmmss</code>，最大可精确到微妙。</li>
</ul>
<h3 data-id="heading-33">4.4、其他类型</h3>
<ul>
<li><code>json</code>：<code>MySQL5.7</code>版本引入的，在此之前只能用字符串类型来存储<code>json</code>数据，需要通过函数辅助使用：
<ul>
<li><code>json_array(...)</code>：存储一个<code>json</code>数组的数据。</li>
<li><code>json_array_insert(字段,'$[下标]',"值")</code>：在指定的<code>json</code>数组下标位置上插入数据。</li>
<li><code>json_object(...)</code>：存储一个<code>json</code>对象。</li>
<li><code>json_extract(字段,'$.键')</code>：查询键为某个值的所有数据。</li>
<li><code>json_search(....)</code>：通过值查询键。</li>
<li><code>json_keys(字段)</code>：获取某个字段的所有<code>json</code>键。</li>
<li><code>json_set(字段,'$.键',"值")</code>：更新某个键的<code>json</code>数据。</li>
<li><code>json_replace(...)</code>：替换某个<code>json</code>中的数据。</li>
<li><code>json_remove(字段,'$.键')</code>：删除某个<code>json</code>数据。</li>
<li><code>.....</code>：还有一些其他<code>json</code>类型的函数，这里不再说明，一般<code>json</code>类型用的较少。</li>
</ul>
</li>
<li><code>enum(选项1,选项2...选项n)</code>：新增数据时只能从已有的选项中选择一个并插入。</li>
<li><code>set(选项1,选项2...选项n)</code>：新增数据时可以从已有的选项中选择多个并插入。</li>
<li><code>eometry、point、linestring、polygon</code>：空间类型（接触不多）。</li>
</ul>
<p>稍微解释一下<code>enum、set</code>类型，这两种类型就类似于平时的单选框和多选框，必须从已有的选项中选择，两者的区别在于：<code>enum</code>枚举类型只能选择一个选项，而<code>set</code>集合类型可以选择多个选项（其实用的比较少，多数情况下都是直接在客户端中处理）。</p>
<blockquote>
<p>OK~，简单了解<code>MySQL</code>支持的数据类型后，接着再来看看其他一些常用的<code>SQL</code>命令。</p>
</blockquote>
<h2 data-id="heading-34">五、索引相关的命令</h2>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- 创建一个普通索引（方式①）</span>
<span class="hljs-keyword">create</span> index 索引名 <span class="hljs-keyword">ON</span> 表名 (列名(索引键长度) [<span class="hljs-keyword">ASC</span><span class="hljs-operator">|</span><span class="hljs-keyword">DESC</span>]);
<span class="hljs-comment">-- 创建一个普通索引（方式②）</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 <span class="hljs-keyword">add</span> index 索引名(列名(索引键长度) [<span class="hljs-keyword">ASC</span><span class="hljs-operator">|</span><span class="hljs-keyword">DESC</span>]);
<span class="hljs-comment">-- 创建一个普通索引（方式③）</span>
<span class="hljs-keyword">CREATE</span> <span class="hljs-keyword">TABLE</span> tableName(  
  columnName1 <span class="hljs-type">INT</span>(<span class="hljs-number">8</span>) <span class="hljs-keyword">NOT</span> <span class="hljs-keyword">NULL</span>,   
  columnName2 ....,
  .....,
  index [索引名称] (列名(长度))  
);
<span class="hljs-comment">-- 后续其他类型的索引都可以通过这三种方式创建</span>

<span class="hljs-comment">-- 创建一个唯一索引</span>
<span class="hljs-keyword">create</span> <span class="hljs-keyword">unique</span> 索引名 <span class="hljs-keyword">ON</span> 表名 (列名(索引键长度) [<span class="hljs-keyword">ASC</span><span class="hljs-operator">|</span><span class="hljs-keyword">DESC</span>]);

<span class="hljs-comment">-- 创建一个主键索引</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 <span class="hljs-keyword">add</span> <span class="hljs-keyword">primary</span> key 索引名(列名);

<span class="hljs-comment">-- 创建一个全文索引</span>
<span class="hljs-keyword">create</span> fulltext index 索引名 <span class="hljs-keyword">ON</span> 表名(列名);

<span class="hljs-comment">-- 创建一个前缀索引</span>
<span class="hljs-keyword">create</span> index 索引名 <span class="hljs-keyword">ON</span> 表名 (列名(索引键长度));

<span class="hljs-comment">-- 创建一个空间索引</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 <span class="hljs-keyword">add</span> spatial key 索引名(列名);

<span class="hljs-comment">-- 创建一个联合索引</span>
<span class="hljs-keyword">create</span> index 索引名 <span class="hljs-keyword">ON</span> 表名 (列名<span class="hljs-number">1</span>(索引键长度),列名<span class="hljs-number">2</span>,...列名n);
<span class="copy-code-btn">复制代码</span></code></pre>

<p>上面将<code>MySQL</code>中创建各类索引的多种方式都列出来了，接着再聊聊索引查看、使用与管理的命令。</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- 查看一张表上的所有索引</span>
<span class="hljs-keyword">show</span> index <span class="hljs-keyword">from</span> 表名;

<span class="hljs-comment">-- 删除一张表上的某个索引</span>
<span class="hljs-keyword">drop</span> index 索引名 <span class="hljs-keyword">on</span> 表名;

<span class="hljs-comment">-- 强制指定一条SQL走某个索引查找数据</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 force index(索引名) <span class="hljs-keyword">where</span> .....;

<span class="hljs-comment">-- 使用全文索引（自然搜索模式）</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> <span class="hljs-keyword">match</span>(索引列) against(<span class="hljs-string">'关键字'</span>);
<span class="hljs-comment">-- 使用全文索引（布尔搜索模式）</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> <span class="hljs-keyword">match</span>(索引列) against(<span class="hljs-string">'布尔表达式'</span> <span class="hljs-keyword">in</span> <span class="hljs-type">boolean</span> mode);
<span class="hljs-comment">-- 使用全文索引（拓展搜索模式）</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> <span class="hljs-keyword">match</span>(索引列) against(<span class="hljs-string">'关键字'</span> <span class="hljs-keyword">with</span> query expansion);

<span class="hljs-comment">-- 分析一条SQL是否命中了索引</span>
explain <span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">where</span> 条件....;
<span class="copy-code-btn">复制代码</span></code></pre>

<h2 data-id="heading-35">六、事务与锁相关的命令</h2>
<ul>
<li><code>start transaction; | begin; | begin work;</code>：开启一个事务。</li>
<li><code>commit;</code>：提交一个事务。</li>
<li><code>rollback;</code>：回滚一个事务。</li>
<li><code>savepoint 事务点名称;</code>：添加一个事务点。</li>
<li><code>rollback to 事务点名称;</code>：回滚到指定名称的事务点。</li>
<li><code>release savepoint 事务点名称;</code>：删除一个事务点。</li>
<li><code>select @@tx_isolation;</code>：查询事务隔离级别（方式一）。</li>
<li><code>show variables like '%tx_isolation%';</code>：查询事务隔离级别（方式二）。</li>
<li><code>set transaction isolation level 级别</code>：设置当前连接的事务隔离级别。</li>
<li><code>set @@tx_isolation = "隔离级别";</code>：设置当前会话的事务隔离级别。</li>
<li><code>set global transaction isolation level 级别;</code>：设置全局的事务隔离级别，选项如下：
<ul>
<li><code>read uncommitted</code>：读未提交级别。</li>
<li><code>read committed</code>：读已提交级别。</li>
<li><code>repeatable-read</code>：可重复读级别。</li>
<li><code>serializable</code>：序列化级别。</li>
</ul>
</li>
<li><code>show variables like 'autocommit';</code>：查看自动提交事务机制是否开启。</li>
<li><code>set @@autocommit = 0|1|ON|OFF;</code>：开启或关闭事务的自动提交。</li>
<li><code>select ... lock in share mode;</code>：手动获取共享锁执行<code>SQL</code>语句。</li>
<li><code>select ... for share;</code>：<code>MySQL8.0</code>之后优化版的共享锁写法。</li>
<li><code>select ... for update;</code>：手动获取排他锁执行。</li>
<li><code>lock tables 表名 read;</code>：获取表级别的共享锁。</li>
<li><code>lock tables 表名 write;</code>：获取表级别的排他锁。</li>
<li><code>show open tables where in_use &gt; 0;</code>：查看目前数据库中正在使用的表锁。</li>
<li><code>flush tables with read lock;</code>：获取全局锁。</li>
<li><code>unlock tables;</code>：释放已获取的表锁/全局锁。</li>
<li><code>update 表名 set version=version+1 ... where... and version=version;</code>：乐观锁模式执行。</li>
</ul>
<h2 data-id="heading-36">七、存储过程、存储函数与触发器</h2>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- 创建一个存储过程</span>
DELIMITER $
<span class="hljs-keyword">CREATE</span> 
    <span class="hljs-keyword">PROCEDURE</span> 存储过程名称(返回类型 参数名<span class="hljs-number">1</span> 参数类型<span class="hljs-number">1</span>, ....)
    [ ...... ]
<span class="hljs-keyword">BEGIN</span>
    <span class="hljs-comment">-- 具体组成存储过程的SQL语句....</span>
<span class="hljs-keyword">END</span> $
DELIMITER ;

<span class="hljs-comment">-- 创建一个存储函数</span>
DELIMITER $
<span class="hljs-keyword">CREATE</span>
<span class="hljs-keyword">FUNCTION</span> 存储函数名称(参数名<span class="hljs-number">1</span> 参数类型<span class="hljs-number">1</span>, ....)
<span class="hljs-keyword">RETURNS</span> 数据类型
[<span class="hljs-keyword">NOT</span>] <span class="hljs-keyword">DETERMINISTIC</span> statements
<span class="hljs-keyword">BEGIN</span>
<span class="hljs-comment">-- 具体组成存储函数的SQL语句....</span>
<span class="hljs-keyword">END</span> $
DELIMITER ;

<span class="hljs-comment">-- 创建一个触发器</span>
<span class="hljs-keyword">CREATE</span> <span class="hljs-keyword">TRIGGER</span> 触发器名称
{BEFORE <span class="hljs-operator">|</span> AFTER} {<span class="hljs-keyword">INSERT</span> <span class="hljs-operator">|</span> <span class="hljs-keyword">UPDATE</span> <span class="hljs-operator">|</span> <span class="hljs-keyword">DELETE</span>} <span class="hljs-keyword">ON</span> 表名
<span class="hljs-keyword">FOR</span> <span class="hljs-keyword">EACH</span> <span class="hljs-type">ROW</span>
<span class="hljs-comment">-- 触发器的逻辑（代码块）;</span>

<span class="hljs-comment">-- ------------- 用户变量与局部变量 ---------------</span>
<span class="hljs-comment">-- 定义、修改用户变量</span>
<span class="hljs-keyword">set</span> @变量名称 <span class="hljs-operator">=</span> 变量值;
<span class="hljs-comment">-- 查询用户变量</span>
<span class="hljs-keyword">select</span> @变量名称;

<span class="hljs-comment">-- 定义局部变量</span>
<span class="hljs-keyword">DECLARE</span> 变量名称 数据类型 <span class="hljs-keyword">default</span> 默认值;
<span class="hljs-comment">-- 为局部变量赋值（方式1）</span>
<span class="hljs-keyword">SET</span> 变量名 <span class="hljs-operator">=</span> 变量值;
<span class="hljs-comment">-- 为局部变量赋值（方式2）</span>
<span class="hljs-keyword">SET</span> 变量名 :<span class="hljs-operator">=</span> 变量值;
<span class="hljs-comment">-- 为局部变量赋值（方式3）</span>
<span class="hljs-keyword">select</span> 查询结果字段 <span class="hljs-keyword">into</span> 变量名 <span class="hljs-keyword">from</span> 表名;

<span class="hljs-comment">-- ------------- 流程控制 ---------------</span>
<span class="hljs-comment">-- if、elseif、else条件分支语法</span>
IF 条件判断 <span class="hljs-keyword">THEN</span>
<span class="hljs-comment">-- 分支操作.....</span>
ELSEIF 条件判断 THWN
<span class="hljs-comment">-- 分支操作.....</span>
<span class="hljs-keyword">ELSE</span>
<span class="hljs-comment">-- 分支操作.....</span>
<span class="hljs-keyword">END</span> IF

<span class="hljs-comment">-- case分支判断语句</span>
<span class="hljs-comment">-- 第一种语法</span>
<span class="hljs-keyword">CASE</span> 变量
<span class="hljs-keyword">WHEN</span> 值<span class="hljs-number">1</span> <span class="hljs-keyword">THEN</span>
<span class="hljs-comment">-- 分支操作1....</span>
<span class="hljs-keyword">WHEN</span> 值<span class="hljs-number">2</span> <span class="hljs-keyword">THEN</span>
<span class="hljs-comment">-- 分支操作2....</span>
.....
<span class="hljs-keyword">ELSE</span>
<span class="hljs-comment">-- 分支操作n....</span>
<span class="hljs-keyword">END</span> <span class="hljs-keyword">CASE</span>;

<span class="hljs-comment">-- 第二种语法</span>
<span class="hljs-keyword">CASE</span>
<span class="hljs-keyword">WHEN</span> 条件判断<span class="hljs-number">1</span> <span class="hljs-keyword">THEN</span>
<span class="hljs-comment">-- 分支操作1....</span>
<span class="hljs-keyword">WHEN</span> 条件判断<span class="hljs-number">2</span> <span class="hljs-keyword">THEN</span>
<span class="hljs-comment">-- 分支操作2....</span>
.....
<span class="hljs-keyword">ELSE</span>
<span class="hljs-comment">-- 分支操作n....</span>
<span class="hljs-keyword">END</span> <span class="hljs-keyword">CASE</span>;

<span class="hljs-comment">-- 循环：LOOP、WHILE、REPEAT</span>
<span class="hljs-comment">-- loop循环</span>
循环名称:LOOP
<span class="hljs-comment">-- 循环体....</span>
<span class="hljs-keyword">END</span> LOOP 循环名称;

<span class="hljs-comment">-- while循环</span>
【循环名称】:WHILE 循环条件 DO
<span class="hljs-comment">-- 循环体....</span>
<span class="hljs-keyword">END</span> WHILE 【循环名称】;

<span class="hljs-comment">-- repeat循环</span>
【循环名称】:REPEAT
<span class="hljs-comment">-- 循环体....</span>
UNTIL 结束循环的条件判断
<span class="hljs-keyword">END</span> REPEAT 【循环名称】;

<span class="hljs-comment">-- 循环跳转</span>
LEAVE 【循环名称】; <span class="hljs-comment">-- 结束某个循环体</span>
ITERATE 【循环名称】; <span class="hljs-comment">-- 跳出某个循环体，继续下次循环</span>

<span class="hljs-comment">-- ------------- 存储过程的游标 ---------------</span>
<span class="hljs-comment">-- ①声明（创建）游标</span>
<span class="hljs-keyword">DECLARE</span> 游标名称 <span class="hljs-keyword">CURSOR</span> <span class="hljs-keyword">FOR</span> <span class="hljs-keyword">select</span> ...;

<span class="hljs-comment">-- ②打开游标</span>
<span class="hljs-keyword">OPEN</span> 游标名称;

<span class="hljs-comment">-- ③使用游标</span>
<span class="hljs-keyword">FETCH</span> 游标名称 <span class="hljs-keyword">INTO</span> 变量名称;

<span class="hljs-comment">-- ④关闭游标</span>
<span class="hljs-keyword">CLOSE</span> 游标名称;
<span class="copy-code-btn">复制代码</span></code></pre>

<p>在上面列出了<code>MySQL</code>中存储过程、存储函数与触发器的相关语法，接着再来聊聊管理的命令：</p>
<ul>
<li><code>SHOW PROCEDURE STATUS;</code>：查看当前数据库中的所有存储过程。</li>
<li><code>SHOW PROCEDURE STATUS WHERE db = '库名' AND NAME = '过程名';</code>：查看指定库中的某个存储过程。</li>
<li><code>SHOW CREATE PROCEDURE 存储过程名;</code>：查看某个存储过程的源码。</li>
<li><code>ALTER PROCEDURE 存储过程名称 ....</code>：修改某个存储过程的特性。</li>
<li><code>DROP PROCEDURE 存储过程名;</code>：删除某个存储过程。</li>
<li><code>SHOW FUNCTION STATUS;</code>：查看当前数据库中的所有存储函数。</li>
<li><code>SHOW CREATE FUNCTION 存储过程名;</code>：查看某个存储函数的源码。</li>
<li><code>ALTER FUNCTION 存储过程名称 ....</code>：修改某个存储函数的特性。</li>
<li><code>DROP FUNCTION 存储过程名;</code>：删除某个存储函数。</li>
<li><code>SHOW TRIGGERS;</code>：查看当前数据库中定义的所有触发器。</li>
<li><code>SHOW CREATE TRIGGER 触发器名称;</code>：查看当前库中指定名称的触发器。</li>
<li><code>SELECT * FROM information_schema.TRIGGERS;</code>：查看<code>MySQL</code>所有已定义的触发器。</li>
<li><code>DROP TRIGGER IF EXISTS 触发器名称;</code>：删除某个指定的触发器。</li>
</ul>
<p>当然，如若你对这块感兴趣，详细的教程可参考上篇：<a href="https://juejin.cn/post/7161662496460242980" target="_blank" title="https://juejin.cn/post/7161662496460242980">《MySQL存储过程与触发器》</a>。</p>
<h2 data-id="heading-37">八、MySQL用户与权限管理</h2>
<ul>
<li><code>create user 用户名@'IP' identified by 密码;</code>：创建一个新用户。</li>
<li><code>drop user 用户名@'IP';</code>：删除某个用户。</li>
<li><code>set password = password(新密码);</code>：为当前用户设置新密码。</li>
<li><code>set password for 用户名 = password(新密码);</code>：为指定用户设置新密码（需要权限）。</li>
<li><code>alter user 用户名@'IP' identified by 新密码;</code>：使用<code>root</code>账号修改密码。</li>
<li><code>mysqladmin -u用户名 -p旧密码 password 新密码;</code>：使用<code>mysqladmin</code>工具更改用户密码。</li>
<li><code>rename user 原用户名 to 新用户名;</code>：对某个用户重命名。</li>
<li><code>show grants;</code>：查看当前用户拥有的权限。</li>
<li><code>show grants for 用户名;</code>：查看指定用户拥有的权限。</li>
<li><code>grant 权限1,权限2... on 库名.表名 to 用户名;</code>：为指定用户授予权限。
<ul>
<li>权限可选项：
<ul>
<li><code>insert</code>：插入表数据的权限。</li>
<li><code>delete</code>：删除表数据的权限。</li>
<li><code>update</code>：修改表数据的权限。</li>
<li><code>select</code>：查询表数据的权限。</li>
<li><code>alter</code>：修改表结构的<code>alter</code>权限。</li>
<li><code>alter routine</code>：修改子程序（存储过程、函数、触发器）的<code>alter</code>权限。</li>
<li><code>create</code>：创建表的<code>create</code>权限。</li>
<li><code>create routine</code>：创建存储过程、存储函数、触发器的权限。</li>
<li><code>create temporary tables</code>：创建临时表的权限。</li>
<li><code>create user</code>：创建/删除/重命名/授权用户的权限。</li>
<li><code>create view</code>：创建视图的权限。</li>
<li><code>drop</code>：删除表的权限。</li>
<li><code>execute</code>：执行存储过程的权限。</li>
<li><code>file</code>：导出、导入表数据的权限。</li>
<li><code>index</code>：创建和删除索引的权限。</li>
<li><code>lock tables</code>：获取表锁的权限。</li>
<li><code>process</code>：查询工作线程的权限。</li>
<li><code>references</code>：这个在<code>MySQL</code>中没有。</li>
<li><code>reload</code>：请空表的权限。</li>
<li><code>replication clinet</code>：获取主节点、从节点地址的权限。</li>
<li><code>replication slave</code>：复制主节点数据的权限。</li>
<li><code>show databases</code>：查看所有数据库的权限。</li>
<li><code>show view</code>：查看所有视图的权限。</li>
<li><code>shutdown</code>：关闭数据库服务的权限。</li>
<li><code>super</code>：修改主节点信息的权限。</li>
<li><code>all privileges</code>：所有权限。</li>
</ul>
</li>
<li><code>usage</code>：不授予这些权限。其他权限全部授予。</li>
<li><code>grant option</code>：授予这些权限，其他权限全部不授予。</li>
<li>权限范围可选项：
<ul>
<li><code>*.*</code>：全局权限，表示该用户可对所有库、所有表进行增删改查操作。</li>
<li><code>库名.*</code>：单库权限，表示该用户可对指定库下的所有表进行增删改查操作。</li>
<li><code>库名.表名</code>：单表权限，表示该用户可对指定表进行增删改查操作。</li>
</ul>
</li>
</ul>
</li>
<li><code>revoke 权限1,权限2... on 库名.表名 from 用户名;</code>：撤销指定用户的指定权限。</li>
<li><code>revoke all privileges from 用户名 with grant option;</code>：撤销一个用户的所有权限。</li>
<li><code>flush privileges;</code>：刷新权限。</li>
<li><code>select user,password,host from mysql.user;</code>：查询当前库中的所有用户信息。</li>
<li><code>MySQL8.0</code>版本后推出的密码管理机制：
<ul>
<li><code>set persist default_password_lifetime=90;</code>：设置所有用户的密码在<code>90</code>天后失效。</li>
<li><code>create user 用户@IP password expire interval 90 day;</code>：创建用户时设置失效时间。</li>
<li><code>alter user 用户名@IP password expire interval 90 day;</code>：设置指定用户密码失效。</li>
<li><code>alter user 用户名@IP password expire never;</code>：设置指定用户的密码永不失效。</li>
<li><code>alter user 用户名@IP password expire default;</code>：使用默认的密码失效策略。
上述给出了一系列的用户管理和权限管理的命令，最后稍微提一下创建用户时的注意事项：</li>
</ul>
</li>
</ul>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- 创建一个名为 zhuzi 的用户</span>
<span class="hljs-keyword">create</span> <span class="hljs-keyword">user</span> <span class="hljs-string">'zhuzi'</span>@<span class="hljs-string">'196.xxx.xxx.xxx'</span> identified <span class="hljs-keyword">by</span> "123456";
<span class="copy-code-btn">复制代码</span></code></pre>
<p>在创建用户时需要在用户名称后面跟一个<code>IP</code>地址，这个<code>IP</code>的作用是用来限制登录用户的机器，如果指定为具体<code>IP</code>，则表示只能由该<code>IP</code>的机器登录该用户，如果写<code>%</code>表示任意设备都能使用该用户名登录连接。</p>
<blockquote>
<p>同时也最后提一嘴，<code>MySQL</code>对于所有的用户信息，都会放在自带的<code>mysql</code>库的<code>user</code>表中存储，因此也可以对表执行<code>insert、delete、update、select</code>操作，来实现管理用户的功能。</p>
</blockquote>
<h2 data-id="heading-38">九、MySQL视图与临时表</h2>
<ul>
<li><code>create view 视图名 as select ...;</code>：对查询出的结果集建立一个指定名称的视图。</li>
<li><code>select * from 视图名;</code>：基于某个已经创建的视图查询数据。</li>
<li><code>show create view 视图名;</code>：查看某个已存在的视图其详细信息。</li>
<li><code>desc 视图名;</code>：查看某个视图的字段结构。</li>
<li><code>alter view 视图名(字段1,...) as select 字段1...;</code>：修改某个视图的字段为查询字段。</li>
<li><code>drop view 视图名;</code>：删除某个视图。</li>
<li><code>create temporary table 表名(....);</code>：创建一张临时表（方式1）。</li>
<li><code>create temporary view 表名 as select ...;</code>：创建一张临时表（方式2）。</li>
<li><code>truncate table 临时表名;</code>：清空某张临时表的数据。</li>
</ul>
<p><code>MySQL</code>的临时表本质上是一种特殊的视图，被称为不可更新的视图，也就是临时表只支持查询数据，不支持增删改操作，因此也可以通过创建视图的方式创建临时表，在创建语句中加入<code>temporary</code>关键字即可，不指定默认为<code>undedined</code>，意思是自动选择视图结构，一般为<code>merge</code>结构，表示创建一个支持增删改查的视图。</p>
<h2 data-id="heading-39">十、数据的导出、导入与备份、还原</h2>
<p>数据库的备份其实本质上就是指通过导出数据的形式，或者拷贝表文件的方式来制作数据的副本，数据恢复/还原即是指在数据库故障、异常、错误的情况下，通过导入原本的数据副本，将数据恢复到正常状态，下面来介绍<code>MySQL</code>中提供的相关命令。</p>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- --------使用 mysqldump 工具做数据的逻辑备份（导出的是sql语句）-----------</span>
<span class="hljs-comment">-- 导出MySQL中全部的库数据（使用--all-databases 或者 -A 参数）</span>
mysqldump <span class="hljs-operator">-</span>uroot <span class="hljs-operator">-</span>p密码 <span class="hljs-comment">--all-databases &gt; 备份文件名.sql</span>

<span class="hljs-comment">-- 导出MySQL中一部分的库数据（使用--databases 或者 -B 参数）</span>
mysqldump <span class="hljs-operator">-</span>uroot <span class="hljs-operator">-</span>p密码 <span class="hljs-comment">--databases &gt; 备份文件名.sql</span>

<span class="hljs-comment">-- 导出MySQL单库中的一部分表数据</span>
mysqldump –u 用户名 –h主机名 –p密码 库名[表名<span class="hljs-number">1</span>,表名<span class="hljs-number">2.</span>..]<span class="hljs-operator">&gt;</span> 备份文件名.<span class="hljs-keyword">sql</span>

<span class="hljs-comment">-- 导出MySQL单表的部分数据（使用 --where 参数）</span>
mysqldump <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p 库名 表名 <span class="hljs-comment">--where="条件" &gt; 备份文件名.sql</span>

<span class="hljs-comment">-- 排除某些表，导出库中其他的所有数据（使用 --ignore-table 参数）</span>
mysqldump <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p 库名 <span class="hljs-comment">--ignore-table=表名1,表名2... &gt; 备份文件名.sql</span>

<span class="hljs-comment">-- 只导出表的结构（使用 --no-data 或者 -d 选项）</span>
mysqldump <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p 库名 <span class="hljs-comment">--no-data &gt; 备份文件名.sql</span>

<span class="hljs-comment">-- 只导出表的数据（使用 --no-create-info 或者 -t 选项）</span>
mysqldump <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p 库名 <span class="hljs-comment">--no-create-info &gt; 备份文件名.sql</span>

<span class="hljs-comment">-- 导出包含存储过程、函数的库数据（使用--routines 或者 -R选项）</span>
mysqldump <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p <span class="hljs-operator">-</span>R <span class="hljs-comment">--databases 库名 &gt; 备份文件名.sql</span>

<span class="hljs-comment">-- 导出包含事件（触发器）的库数据（使用 --events 或者 -E选项）</span>
mysqldump <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p <span class="hljs-operator">-</span>E <span class="hljs-comment">--databases 库名 &gt; 备份文件名.sql</span>

<span class="hljs-comment">-- --------使用 mysql 工具来恢复备份的数据（导入xx.sql文件执行）-----------</span>
<span class="hljs-comment">-- 恢复库级别的数据（包含了建库语句的情况下使用）</span>
mysql <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p <span class="hljs-operator">&lt;</span> xxx.sql

<span class="hljs-comment">-- 恢复库中表级别的数据</span>
mysql <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p 库名 <span class="hljs-operator">&lt;</span> xxx.sql

<span class="hljs-comment">-- ----------以物理形式备份数据（导出的是表数据） ------------</span>
<span class="hljs-comment">-- 查看数据库导出数据的路径（如果没有则需在`my.ini/my.conf`中配置）</span>
<span class="hljs-keyword">show</span> variables <span class="hljs-keyword">like</span> <span class="hljs-string">'%secure_file_priv%'</span>;

<span class="hljs-comment">-- 导出一张表的数据为txt文件（使用 select ... into outfile 语句）</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">into</span> outfile "备份文件名.txt";

<span class="hljs-comment">-- 导出一张表的数据为txt文件（使用 mysql 工具）</span>
mysql <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p <span class="hljs-comment">--execute="select ...;" 库名 &gt; "数据存放目录/xxx.txt"</span>

<span class="hljs-comment">-- 导出一张表的结构和数据为sql、txt文件（使用 mysqldump -T 的方式）</span>
mysqldump <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p <span class="hljs-operator">-</span>T "数据存放目录" 库名 文件名

<span class="hljs-comment">-- 导出一张表的数据为txt文件，以竖排形式存储（使用 mysql –veritcal 的方式）</span>
mysql <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p <span class="hljs-operator">-</span>veritcal <span class="hljs-comment">--execute="select ...;" 库名 &gt; "数据存放目录/xxx.txt"</span>

<span class="hljs-comment">-- 导出一张表的数据为xml文件（使用 mysql -xml 的方式）</span>
mysql <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p <span class="hljs-operator">-</span>xml <span class="hljs-comment">--execute="select ...;" 库名 &gt; "数据存放目录/xxx.xml"</span>

<span class="hljs-comment">-- -----------通过物理数据文件恢复数据----------------</span>
<span class="hljs-comment">-- 使用load data infile 的方式导入.txt 物理数据</span>
load data infile "数据目录/xxx.txt" <span class="hljs-keyword">into</span> <span class="hljs-keyword">table</span> 库名.表名;

<span class="hljs-comment">-- 使用 mysqlimport 工具导入xxx.txt物理数据</span>
mysqlimport <span class="hljs-operator">-</span>u用户名 <span class="hljs-operator">-</span>p 库名 <span class="hljs-string">'数据存放目录/xxx.txt'</span>
<span class="hljs-comment">--fields-terminatedby=',' </span>
<span class="hljs-comment">--fields-optionally-enclosed-by='\"'</span>

<span class="hljs-comment">-- 使用 mysqldump 工具迁移数据</span>
mysqldump –h 地址<span class="hljs-number">1</span> –u用户名 –p密码 –<span class="hljs-operator">-</span><span class="hljs-keyword">all</span><span class="hljs-operator">-</span>databases <span class="hljs-operator">|</span> mysql –h地址<span class="hljs-number">2</span> –u用户名 –p密码
<span class="copy-code-btn">复制代码</span></code></pre>

<p>上述列出了一系列数据导出导入、备份恢复、迁移等命令，这些都是<code>MySQL</code>自身就支持的方式，但这些自带的命令或工具，在一些情况下往往没有那么灵活、方便，因此在实际情况下，可以适当结合第三方工具来完成，比如：</p>
<ul>
<li>较大的数据需要做物理备份时，可以通过<code>xtrabackup</code>备份工具来完成。</li>
<li><code>MySQL5.5</code>版本之前的<code>MyISAM</code>表，可以通过<code>MySQLhotcopy</code>工具做逻辑备份（速度最快）。</li>
<li>不同版本的<code>MySQL</code>可以使用<code>XtraBackup</code>备份工具来做数据迁移。</li>
<li><code>MySQL、Oracle</code>之间可以通过<code>MySQL Migration Toolkit</code>工具来做数据迁移。</li>
<li><code>MySQL、SQL Server</code>之间可以通过<code>MyODBC</code>工具来做数据迁移。</li>
</ul>
<blockquote>
<p>当然，无论是<code>MySQL</code>自身提供的工具也好，亦或是第三方提供的工具也罢，因为本身就写死了逻辑，因此在有些场景下依旧存在局限性，因此有时咱们也需要写自动化脚本，以此来完成一些特殊的需求。</p>
</blockquote>
<h2 data-id="heading-40">十一、表分区相关的命令</h2>
<pre><code class="hljs language-sql copyable" lang="sql"><span class="hljs-comment">-- 创建范围分区</span>
<span class="hljs-keyword">create</span> <span class="hljs-keyword">table</span> `表名`(
	`xxx` xxx <span class="hljs-keyword">not</span> <span class="hljs-keyword">null</span>,
	 ....
) 
<span class="hljs-keyword">partition</span> <span class="hljs-keyword">by</span> <span class="hljs-keyword">range</span>(xxx)(
	<span class="hljs-keyword">partition</span> 分区名<span class="hljs-number">1</span> <span class="hljs-keyword">values</span> less than (范围) data directory <span class="hljs-operator">=</span> "/xxx/xxx/xxx",
	<span class="hljs-keyword">partition</span> 分区名<span class="hljs-number">2</span> <span class="hljs-keyword">values</span> less than (范围) data directory <span class="hljs-operator">=</span> "/xxx/xxx/xxx",
	......
);

<span class="hljs-comment">-- 创建枚举分区</span>
<span class="hljs-keyword">create</span> <span class="hljs-keyword">table</span> `表名`(
`xxx` xxx <span class="hljs-keyword">not</span> <span class="hljs-keyword">null</span>,
....
)
<span class="hljs-keyword">partition</span> <span class="hljs-keyword">by</span> list(xxx)(
<span class="hljs-keyword">partition</span> 分区名<span class="hljs-number">1</span> <span class="hljs-keyword">values</span> <span class="hljs-keyword">in</span> (枚举值<span class="hljs-number">1</span>,枚举值<span class="hljs-number">2.</span>..),
<span class="hljs-keyword">partition</span> 分区名<span class="hljs-number">2</span> <span class="hljs-keyword">values</span> <span class="hljs-keyword">in</span> (枚举值),
......
);

<span class="hljs-comment">-- 创建常规哈希分区</span>
<span class="hljs-keyword">create</span> <span class="hljs-keyword">table</span> `表名`(
`xxx` xxx <span class="hljs-keyword">not</span> <span class="hljs-keyword">null</span>,
....
)
<span class="hljs-keyword">partition</span> <span class="hljs-keyword">by</span> hash(xxx)
partitions 分区数量;

<span class="hljs-comment">-- 创建线性哈希分区</span>
<span class="hljs-keyword">create</span> <span class="hljs-keyword">table</span> `表名`(
`xxx` xxx <span class="hljs-keyword">not</span> <span class="hljs-keyword">null</span>,
....
)
<span class="hljs-keyword">partition</span> <span class="hljs-keyword">by</span> linear hash(xxx)
partitions 分区数量;

<span class="hljs-comment">-- 创建Key键分区</span>
<span class="hljs-keyword">create</span> <span class="hljs-keyword">table</span> `表名`(
`xxx` xxx <span class="hljs-keyword">not</span> <span class="hljs-keyword">null</span>,
....
)
<span class="hljs-keyword">partition</span> <span class="hljs-keyword">by</span> key(xxx)
partitions 分区数量;

<span class="hljs-comment">-- 创建Sub子分区</span>
<span class="hljs-keyword">create</span> <span class="hljs-keyword">table</span> `表名`(
`xxx` xxx <span class="hljs-keyword">not</span> <span class="hljs-keyword">null</span>,
....
)
<span class="hljs-keyword">partition</span> <span class="hljs-keyword">by</span> <span class="hljs-keyword">range</span>(父分区键)
subpartition <span class="hljs-keyword">by</span> hash(子分区键)(
<span class="hljs-keyword">partition</span> 分区名<span class="hljs-number">1</span> <span class="hljs-keyword">values</span> less than (范围<span class="hljs-number">1</span>)(
subpartition 子分区名<span class="hljs-number">1</span>,
subpartition 子分区名<span class="hljs-number">2</span>,
......
),
<span class="hljs-keyword">partition</span> 分区名<span class="hljs-number">2</span> <span class="hljs-keyword">values</span> less than (范围<span class="hljs-number">2</span>)(
subpartition 子分区名<span class="hljs-number">1</span>,
subpartition 子分区名<span class="hljs-number">2</span>,
......
),
......
);

<span class="hljs-comment">-- 查询一张表各个分区的数据量</span>
<span class="hljs-keyword">select</span>
partition_name <span class="hljs-keyword">as</span> "分区名称",table_rows <span class="hljs-keyword">as</span> "数据行数"
<span class="hljs-keyword">from</span>
information_schema.partitions
<span class="hljs-keyword">where</span>
table_name <span class="hljs-operator">=</span> <span class="hljs-string">'表名'</span>;

<span class="hljs-comment">-- 查询一张表父子分区的数据量</span>
<span class="hljs-keyword">select</span>
partition_name <span class="hljs-keyword">as</span> "父分区名称",
subpartition_name <span class="hljs-keyword">as</span> "子分区名称",
table_rows <span class="hljs-keyword">as</span> "子分区行数"
<span class="hljs-keyword">from</span>
information_schema.partitions
<span class="hljs-keyword">where</span>
table_name <span class="hljs-operator">=</span> <span class="hljs-string">'表名'</span>;

<span class="hljs-comment">-- 查询MySQL中所有表分区的信息</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> information_schema.partitions;

<span class="hljs-comment">-- 查询一张表某个分区中的所有数据</span>
<span class="hljs-keyword">select</span> <span class="hljs-operator">*</span> <span class="hljs-keyword">from</span> 表名 <span class="hljs-keyword">partition</span> (分区名);

<span class="hljs-comment">-- 对于一张已存在的表添加分区</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 reorganize <span class="hljs-keyword">partition</span> 分区名 <span class="hljs-keyword">into</span> (
<span class="hljs-keyword">partition</span> 分区名<span class="hljs-number">1</span> <span class="hljs-keyword">values</span> less than (范围) data directory <span class="hljs-operator">=</span> "/xxx/xxx/xxx",
<span class="hljs-keyword">partition</span> 分区名<span class="hljs-number">2</span> <span class="hljs-keyword">values</span> less than (范围) data directory <span class="hljs-operator">=</span> "/xxx/xxx/xxx",
......
);

<span class="hljs-comment">-- 将多个分区合并成一个分区</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表明 reorganize <span class="hljs-keyword">partition</span> 分区名<span class="hljs-number">1</span>,分区名<span class="hljs-number">2.</span>.. <span class="hljs-keyword">into</span> (
<span class="hljs-keyword">partition</span> 新分区名 <span class="hljs-keyword">values</span> less than (范围)
);

<span class="hljs-comment">-- 清空一个分区中的所有数据</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 <span class="hljs-keyword">truncate</span> <span class="hljs-keyword">partition</span> 分区名;

<span class="hljs-comment">-- 删除一个表的指定分区</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 <span class="hljs-keyword">drop</span> <span class="hljs-keyword">partition</span> 分区名;

<span class="hljs-comment">-- 重建一张表的分区</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 rebuild <span class="hljs-keyword">partition</span> 分区名;

<span class="hljs-comment">-- 分析一个表分区</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 analyze <span class="hljs-keyword">partition</span> 分区名;
<span class="hljs-comment">-- 优化一个表分区</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 optimize <span class="hljs-keyword">partition</span> 分区名;
<span class="hljs-comment">-- 检查一个表分区</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 <span class="hljs-keyword">check</span> <span class="hljs-keyword">partition</span> 分区名;
<span class="hljs-comment">-- 修复一个表分区</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 repair <span class="hljs-keyword">partition</span> 分区名;

<span class="hljs-comment">-- 减少hash、key分区方式的 n 个分区</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 coalesce <span class="hljs-keyword">partition</span> n;

<span class="hljs-comment">-- 将一张表的分区切换到另一张表</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名<span class="hljs-number">1</span> exchange <span class="hljs-keyword">partition</span> 分区名 <span class="hljs-keyword">with</span> <span class="hljs-keyword">table</span> 表名<span class="hljs-number">2</span>;

<span class="hljs-comment">-- 移除一张表的所有分区</span>
<span class="hljs-keyword">alter</span> <span class="hljs-keyword">table</span> 表名 remove partitioning;
<span class="copy-code-btn">复制代码</span></code></pre>

<h2 data-id="heading-41">十二、MySQL、InnoDB、MyISAM的参数</h2>
<p>``参数，也被称之为<code>MySQL</code>的系统变量，这些变量是影响<code>MySQL</code>运行的关键，对每个参数做出不同调整，都有可能直接影响到线上数据库的性能，具体的完整系统参数可参考<a href="https://link.juejin.cn?target=https%3A%2F%2Fdev.mysql.com%2Fdoc%2Frefman%2F8.0%2Fen%2Fserver-system-variables.html" target="_blank" rel="nofollow noopener noreferrer" title="https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html" ref="nofollow noopener noreferrer">《MySQL官网文档-系统变量》</a>，官方提供的系统参数数量大致如下：<br>
<img src="https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/dc950659fa70489d98e704fb08f2db41~tplv-k3u1fbpfcp-zoom-in-crop-mark:4536:0:0:0.awebp?" alt="MySQL系统变量" loading="lazy" class="medium-zoom-image"><br>
通过<code>xpath</code>的方式提取数据，大概能够得知<code>MySQL</code>系统变量大概一千个上下，因此这里就不做过多的详细介绍，简单介绍一些较为常用的即可，其他具体的可参考前面给出的官网链接。</p>
<blockquote>
<p>但是要注意，虽说<code>MySQL</code>中有一千多个对外暴露的系统参数，但并不是所有的参数都可以让用户调整，<code>MySQL</code>的系统参数分为了三类：<br>
一类是由<code>MySQL</code>自己维护的参数，这类参数用户无法调整。<br>
第二类是以配置文件的形式加载的参数，这类参数必须在<code>MySQL</code>停机的情况下才能更改。<br>
第三类是运行时的系统参数，这类是可以由用户去做动态调整的。</p>
</blockquote>
<p>咱们需要关心的重点就是第三类参数，那如何观察这类参数呢？方式如下：</p>
<ul>
<li><code>show global variables;</code>：查看全局所有用户级别可以看到的系统变量。</li>
<li><code>show session variables; | show variables;</code>：查看当前会话的所有系统变量。</li>
<li><code>show variables like '%关键字%';</code>：使用模糊查询搜索某个系统变量。</li>
</ul>
<p><code>MySQL5.1</code>与<code>MySQL8.0</code>版本的执行结果如下：<br>
<img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/adcdfbba969c4dc79be50984d1b5529b~tplv-k3u1fbpfcp-zoom-in-crop-mark:4536:0:0:0.awebp?" alt="可调整的系统变量" loading="lazy" class="medium-zoom-image"><br>
可以很明显的从结果中得知：<code>MySQL5.1</code>版本中存在<code>278</code>个系统变量，<code>MySQL8.0</code>版本中存在<code>557</code>个系统变量，这仅仅只是社区版，而在商业版的<code>MySQL</code>中，其系统参数会更多，下面调出一些重点来聊一聊。</p>
<ul>
<li><code>max_connections</code>：<code>MySQL</code>的最大连接数，超出后新到来的连接会阻塞或被拒绝。</li>
<li><code>version</code>：当前数据库的版本。</li>
<li><code>ft_min_word_len</code>：使用<code>MyISAM</code>引擎的表中，全文索引最小搜索长度。</li>
<li><code>ft_max_word_len</code>：使用<code>MyISAM</code>引擎的表中，全文索引最大搜索长度。</li>
<li><code>ft_query_expansion_limit</code>：<code>MyISAM</code>中使用<code>with query expansion</code>搜索的最大匹配数。</li>
<li><code>innodb_ft_min_token_size</code>：<code>InnoDB</code>引擎的表中，全文索引最小搜索长度。</li>
<li><code>innodb_ft_max_token_size</code>：<code>InnoDB</code>引擎的表中，全文索引最大搜索长度。</li>
<li><code>optimizer_switch</code>：<code>MySQL</code>隐藏参数的开关。</li>
<li><code>skip_scan</code>：是否开启索引跳跃扫描机制。</li>
<li><code>innodb_page_size</code>：<code>InnoDB</code>引擎数据页的大小。</li>
<li><code>tx_isolation</code>：事务的隔离级别。</li>
<li><code>autocommit</code>：事务自动提交机制。</li>
<li><code>innodb_autoinc_lock_mode</code>：插入意向锁的工作模式。</li>
<li><code>innodb_lock_wait_timeout</code>：<code>InnoDB</code>锁冲突时，阻塞的超时时间。</li>
<li><code>innodb_deadlock_detect</code>：是否开启<code>InnoDB</code>死锁检测机制。</li>
<li><code>innodb_max_undo_log_size</code>：本地磁盘文件中，<code>Undo-log</code>的最大值，默认<code>1GB</code>。</li>
<li><code>innodb_rollback_segments</code>：指定回滚段的数量，默认为<code>1</code>个。</li>
<li><code>innodb_undo_directory</code>：指定<code>Undo-log</code>的存放目录，默认放在<code>.ibdata</code>文件中。</li>
<li><code>innodb_undo_logs</code>：指定回滚段的数量，默认为<code>128</code>个，也就是之前的<code>innodb_rollback_segments</code>。</li>
<li><code>innodb_undo_tablespaces</code>：指定<code>Undo-log</code>分成几个文件来存储，必须开启<code>innodb_undo_directory</code>参数。</li>
<li><code>back_log</code>：回滚日志的最大回撤长度（一条数据的最长版本链长度）。</li>
<li><code>innodb_undo_log_truncate</code>：是否开启<code>Undo-log</code>的压缩功能，即日志文件超过一半时自动压缩，默认关闭。</li>
<li><code>innodb_flush_log_at_trx_commit</code>：设置<code>redo_log_buffer</code>的刷盘策略，默认每次提交事务都刷盘。</li>
<li><code>innodb_log_group_home_dir</code>：指定<code>redo-log</code>日志文件的保存路径，默认为<code>./</code>。</li>
<li><code>innodb_log_buffer_size</code>：指定<code>redo_log_buffer</code>缓冲区的大小，默认为<code>16MB</code>。</li>
<li><code>innodb_log_files_in_group</code>：指定<code>redo</code>日志的磁盘文件个数，默认为<code>2</code>个。</li>
<li><code>innodb_log_file_size</code>：指定<code>redo</code>日志的每个磁盘文件的大小限制，默认为<code>48MB</code>。</li>
<li><code>innodb_log_write_ahead_size</code>：设置<code>checkpoint</code>刷盘机制每次落盘动作的大小。</li>
<li><code>innodb_log_compressed_pages</code>：是否对<code>Redo</code>日志开启页压缩机制，默认<code>ON</code>。</li>
<li><code>innodb_log_checksums</code>：<code>Redo</code>日志完整性效验机制，默认开启。</li>
<li><code>log_bin</code>：是否开启<code>bin-log</code>日志，默认<code>ON</code>开启，表示会记录变更<code>DB</code>的操作。</li>
<li><code>log_bin_basename</code>：设置<code>bin-log</code>日志的存储目录和文件名前缀，默认为<code>./bin.0000x</code>。</li>
<li><code>log_bin_index</code>：设置<code>bin-log</code>索引文件的存储位置，因为本地有多个日志文件，需要用索引来确定目前该操作的日志文件。</li>
<li><code>binlog_format</code>：指定<code>bin-log</code>日志记录的存储方式，可选<code>Statment、Row、Mixed</code>。</li>
<li><code>max_binlog_size</code>：设置<code>bin-log</code>本地单个文件的最大限制，最多只能调整到<code>1GB</code>。</li>
<li><code>binlog_cache_size</code>：设置为每条线程的工作内存，分配多大的<code>bin-log</code>缓冲区。</li>
<li><code>sync_binlog</code>：控制<code>bin-log</code>日志的刷盘频率。</li>
<li><code>binlog_do_db</code>：设置后，只会收集指定库的<code>bin-log</code>日志，默认所有库都会记录。</li>
<li><code>log-error</code>：<code>error-log</code>错误日志的保存路径和名字。</li>
<li><code>slow_query_log</code>：设置是否开启慢查询日志，默认<code>OFF</code>关闭。</li>
<li><code>slow_query_log_file</code>：指定慢查询日志的存储目录及文件名。</li>
<li><code>general_log</code>：是否开启查询日志，默认<code>OFF</code>关闭。</li>
<li><code>general_log_file</code>：指定查询日志的存储路径和文件名。</li>
<li><code>innodb_buffer_pool_size</code>：<code>InnoDB</code>缓冲区的大小。</li>
<li><code>innodb_adaptive_hash_index</code>：是否开启<code>InnoDB</code>的自适应哈希索引机制。</li>
<li><code>innodb_compression_level</code>：调整压缩的级别，可控范围在<code>1~9</code>，越高压缩效果越好，但压缩速度也越慢。</li>
<li><code>innodb_compression_failure_threshold_pct</code>：当压缩失败的数据页超出该比例时，会加入数据填充来减小失败率，为<code>0</code>表示禁止填充。</li>
<li><code>innodb_compression_pad_pct_max</code>：一个数据页中最大允许填充多少比例的空白数据。</li>
<li><code>innodb_log_compressed_pages</code>：控制是否对<code>redo-log</code>日志的数据也开启压缩机制。</li>
<li><code>innodb_cmp_per_index_enabled</code>：是否对索引文件开启压缩机制。</li>
<li><code>character_set_client</code>：客户端的字符编码格式。</li>
<li><code>character_set_connection</code>：数据库连接的字符编码格式。</li>
<li><code>character_set_database</code>：数据库的字符编码格式。</li>
<li><code>character_set_results</code>：返回的结果集的编码格式。</li>
<li><code>character_set_server</code>：<code>MySQL-Server</code>的字符编码格式。</li>
<li><code>character_set_system</code>：系统的字符编码格式。</li>
<li><code>collation_database</code>：数据库的字符排序规则。</li>
<li><code>......</code>：剩下的就不再列出来了，大家可根据查询出的变量名，去官网文档查询释义即可。</li>
</ul>
<h2 data-id="heading-42">十三、MySQL常见的错误码</h2>
<p>&nbsp; &nbsp;程序<code>Bug</code>、错误、异常.....，这些词汇天生与每位程序员挂钩，当一个程序出现问题时，用户第一时间想到的是这个平台的程序员不行，而身为开发者逃不开一点是：<strong>又得背锅和加班解决问题</strong>！</p>
<p>&nbsp; &nbsp;而<code>MySQL</code>作为整个系统的后方大本营，自然也无法避免会出现错误与异常，在<code>MySQL</code>内部其实定义了一系列错误码，当运行过程中发生错误，或执行语句时出现异常时，一般情况下都会向客户端返回错误码以及错误信息。</p>
<blockquote>
<p>但往往很多时候有些错误咱们没见过，所以面对问题时难免有些束手无策，也正因为如此，本节将罗列<code>MySQL</code>中常见的错误码，当你碰到问题时可以直接通过错误码在此搜索，以此来定位问题出现的原因，以此进一步推导出问题的解决方案。</p>
</blockquote>
<p><code>MySQL</code>的错误信息由<code>ErrorCode、SQLState、ErrorInfo</code>三部分组成，即错误码、<code>SQL</code>状态、错误信息三部分组成，如下：</p>
<blockquote>
<p><code>ERROR 1045 (28000): Access denied for user 'zhuzi'@'localhost' (using password: YES)</code></p>
</blockquote>
<p>其中<code>1045</code>属于错误状态码，<code>28000</code>属于<code>SQL</code>状态，后面跟着的则是具体的错误信息，不过<code>MySQL</code>内部大致定义了两三千个错误码，其错误码的定义位于<code>include/mysqld_error.h、include/mysqld_ername.h</code>文件中，而<code>SQLState</code>的定义则位于<code>include/sql_state.h</code>文件中，所有的错误信息列表则位于<code>share/errmsg.txt</code>文件中，因此大家感兴趣的可自行编译<code>MySQL</code>源码查看。</p>
<p>OK~，由于本章篇幅过长，就不再罗列细致的错误码详情了，毕竟当出现错误时，百度、谷歌才是最好的选择，毕竟从上面不仅仅能找到错误码的含义，同时还能找到错误码的解决方案，但为了文章的完整性，再贴一位大佬的<a href="https://link.juejin.cn?target=https%3A%2F%2Fwww.cnblogs.com%2Fcuianbing%2Fp%2F16260796.html" target="_blank" rel="nofollow noopener noreferrer" title="https://www.cnblogs.com/cuianbing/p/16260796.html" ref="nofollow noopener noreferrer">→《错误码大全》←</a>的整理：<br>
<img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3cf38af323984c8486444d28f00d4b25~tplv-k3u1fbpfcp-zoom-in-crop-mark:4536:0:0:0.awebp?" alt="字数" loading="lazy" class="medium-zoom-image"><br>
通篇下来共计<code>16.07W</code>字，里面对于<code>MySQL</code>中<code>90%+</code>的错误码都罗列出来了，但我大致看了一些，有些错误码的描述并不恰当，应该是直接根据<code>share/errmsg.txt</code>文件中的错误信息直接翻译过来的，大家有兴趣可以看看~</p>
<h2 data-id="heading-43">十四、MySQL命令大全总结</h2>
<p>&nbsp; &nbsp;到这里为止，对于<code>MySQL</code>中大部分常用的命令基本上都已经罗列出来啦！以后如若忘记某个函数名称、某条语句的语法等等，都可以直接在本章中快捷搜索，但本篇仅仅只写出了基本的语法，实际数据库开发中往往还需要结合业务，来编写更为复杂的<code>SQL</code>语句~。本章的主要目的是当成《<code>MySQL</code>命令手册》，本质上没有太多可以学习的知识点，但它却非常实用，能够协助咱们的日常开发。</p></div><style>.markdown-body pre,.markdown-body pre>code.hljs{color:#333;background:#f8f8f8}.hljs-comment,.hljs-quote{color:#998;font-style:italic}.hljs-keyword,.hljs-selector-tag,.hljs-subst{color:#333;font-weight:700}.hljs-literal,.hljs-number,.hljs-tag .hljs-attr,.hljs-template-variable,.hljs-variable{color:teal}.hljs-doctag,.hljs-string{color:#d14}.hljs-section,.hljs-selector-id,.hljs-title{color:#900;font-weight:700}.hljs-subst{font-weight:400}.hljs-class .hljs-title,.hljs-type{color:#458;font-weight:700}.hljs-attribute,.hljs-name,.hljs-tag{color:navy;font-weight:400}.hljs-link,.hljs-regexp{color:#009926}.hljs-bullet,.hljs-symbol{color:#990073}.hljs-built_in,.hljs-builtin-name{color:#0086b3}.hljs-meta{color:#999;font-weight:700}.hljs-deletion{background:#fdd}.hljs-addition{background:#dfd}.hljs-emphasis{font-style:italic}.hljs-strong{font-weight:700}</style></div>

