title: NodeJs--简单实现co升级到Async
date: '2022-06-10 17:45:03'
updated: '2022-06-10 17:45:03'
tags: [NodeJs]
permalink: /articles/2019/12/14/1576311999409.html
---
## 一、co 实现同步代码执行

```
let request = require("request")
function testPromise() {
	return new Promise(resolve => {
		request('https://www.xiaozao520.cn/IRServer/user/userLogin', function (error, response, body) {
			console.log(body) // 请求成功的处理逻辑
			resolve()
		});

	})
}
function* testYield(){
	console.log(666)
}
let co = require("co")
co(function* () {
	yield testPromise
})
```

## 二、通过async 实现同步代码执行

```
let request = require("request")
function testPromise() {
	return new Promise(resolve => {
		request('https://www.xiaozao520.cn/IRServer/user/userLogin', function (error, response, body) {
			console.log(body) // 请求成功的处理逻辑
			resolve()
		});

	})
}
async function test() {
	await testPromise()
	console.log(1)
}
test()
```

## 三、co升级至async

1. 使用AST解析旧代码，将类型为`generator`的函数转成`async`
2. 全局匹配将yield替换成await
3. 执行命令 jscodeshift -t ./jscode.js ./项目目录

```
附：jscode.js
module.exports =(fileInfo, api) => {
	const j = api.jscodeshift;
	if(fileInfo.path.indexOf("node_modules")>=0
	|| fileInfo.path.indexOf("test")>=0
	||fileInfo.path.indexOf("script")>=0
	||fileInfo.path.indexOf("nodejssupport")>=0
	||fileInfo.path.indexOf("definition")>=0
	||fileInfo.path.indexOf("support")>=0
	||fileInfo.path.indexOf("crontab")>=0
	||fileInfo.path.indexOf("mq")>0
	||fileInfo.path.indexOf("mongo")>=0
	||fileInfo.path.indexOf("cache")>=0
	||fileInfo.path.indexOf("smallUtil")>=0
	){
		return;
	}
	var ast = j(fileInfo.source);
	var functions=ast.find(j.FunctionDeclaration)
	console.info(`deal ${fileInfo.path} ${functions.length}`);
	functions.forEach(nodePath=>{
		var node=nodePath.node;
		if(node.generator){
			node.generator=!node.generator;
			node.async=!node.async;
		}
	})
	return ast.toSource()
}
```

```
附2：替换class中的`generator`
module.exports =(fileInfo, api) => {
	const j = api.jscodeshift;
	// if(fileInfo.path.indexOf("node_modules")>=0
	// || fileInfo.path.indexOf("test")>=0
	// ||fileInfo.path.indexOf("script")>=0
	// ||fileInfo.path.indexOf("nodejssupport")>=0
	// ||fileInfo.path.indexOf("definition")>=0
	// ||fileInfo.path.indexOf("support")>=0
	// ||fileInfo.path.indexOf("mongo")>=0){
	// 	return;
	// }0
	var ast = j(fileInfo.source);
	var functions=ast.find(j.ClassDeclaration)
	console.info(`deal ${fileInfo.path} ${functions.length}`);
	functions.forEach(nodePath=>{
        var node=nodePath.node.body.body;
        node.forEach(arr=>{
            let value = arr.value
            if(value.generator){
                value.generator=!value.generator;
                value.async=!value.async;
            }
        })
		
	})
	return ast.toSource()
}
```
