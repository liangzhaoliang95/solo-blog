title: docker启动SOLO
date: '2022-06-10 17:45:03'
updated: '2022-06-10 17:45:03'
tags: [docker]
permalink: /articles/2019/09/08/1567926913909.html
---
```
docker run --detach --name solo --network=host \
    --volume /usr/src/soloSkin/skins/:/opt/solo/skins/ \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="passward" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://host:port/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=https --server_host=www.xiaozao520.cn --server_port=
```
