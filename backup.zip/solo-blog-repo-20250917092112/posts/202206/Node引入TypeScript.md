title: Node引入TypeScript
date: '2022-06-10 17:45:03'
updated: '2022-06-10 17:45:03'
tags: [Solo]
permalink: /articles/2021/06/28/1624866294625.html
---
###### 安装

1. 执行 npm install -g typescript 安装ts编译器
2. 执行 npm install -g ts-node 可直接执行ts文件

###### 一、基础类型

```ts
//字符串
let a:string = "hello ts"

//数字
let b:number = 1

//bool
let c:boolean = false

//数组
let d:string[] = ["a","b"]

//泛型数组
let e:Array<string> = ["a","B"]

//元祖
let f:[string,number,boolean] = ["a",1,true]

//枚举类型
enum Flag {success=1,error=2}
let g:Flag = Flag.success

//任意类型
let h:any = {}

//对象
let i:object = {}

//never类型，其他类型，从不会出现的值
let j:null = null;
let k:undefined = undefined;

//多类型
let l:number | string = "s"

//void类型，无返回值
function run(age:number):void {

}

//断言
let someValue: any = "this is a string";
let strLength: number = (<string>someValue).length;
```

二、函数

1. 函数声明(入参，返回值按照定义传入传出)
   
   ```ts
   function add(x: number, y: number): number {
       return x + y;
   }
   
   let myAdd = function(x: number, y: number): number { return x + y; };
   ```
2. 无返回值函数
   
   ```js
   function run():void{
      console.log('run')
   }
   run();
   ```
3. 可选参数函数(ts中实参和形参必须一样，如果不一样可以配置可选参数，可选参数必须配置到最后一个参数)
   
   ```ts
   function getInfo(name:string,age?:number):string{
   
   }
   ```
4. 配置默认参数
   
   ```ts
   function getInfo(name:string="name",age:number=20):string{
   
   }
   ```

###### 三、接口

TypeScript的核心原则之一是对值所具有的*结构*进行类型检查。 它有时被称做“鸭式辨型法”或“结构性子类型化”。 在TypeScript里，接口的作用就是为这些类型命名和为你的代码或第三方代码定义契约。

1. 属性接口（对象的约束）
   
   ```ts
   //函数形参约束
   function run(params:{pageSize:number,pageNum:number}):void{
   
   }
   //定义接口约束 推荐此方式
   interface Params {
   	pageSize:number,
   	pageNum:number
   }
   function run(params:Params):void{
   
   }
   ```
2. 函数类型接口
   
   ```ts
   //限定函数的入参入参和返回值
   interface encrypt{
       (key:string,value:string):string;
   }
   var md5:encrypt=function(key:string,value:string):string{
           //模拟操作
           return key+value;
   }
   console.log(md5('name','zhangsan'));
   ```
3. 可索引接口 不常用(对数组和对象的约束)
   
   ```ts
   //对数组约束
   interface UserArr{
   	[index:number]:string //索引为数字，值为字符串
   }
   let arr:UserArr=["aaa","bbb"]
   //对对象的约束
   interface UserObj{
   	[index:string]:number //索引为字符串，值为数字
   }
   let obj obj:UserObk = {age:100}
   ```
4. 类类型接口
   
   ```ts
   interface Animal{
           name:string;
           eat(str:string):void;
       }
       class Dog implements Animal{
           name:string;
           constructor(name:string){
               this.name=name;
           }
           eat(){
   
               console.log(this.name+'吃粮食')
           }
       }
       var d=new Dog('小黑');
       d.eat();
   ```
5. 接口扩展,类似java
   
   ```ts
   interface Animal{
      eat():void;
   }
   
   interface Person extends Animal{
       work():void;
   }
   
   
   class Programmer{
       public name:string;
       constructor(name:string){
           this.name=name;
       }
       coding(code:string){
           console.log(this.name+code)
       }
   }
   
   
   class Web extends Programmer implements Person{
        constructor(name:string){
            super(name)
        }
        eat(){
             console.log(this.name+'喜欢吃馒头')
        }
        work(){
           console.log(this.name+'写代码');
        }
   }
   var w=new Web('小李');
   w.coding('写ts代码');
   ```

###### 四、泛型

1. 泛型变量
   
   ```ts
   function identity<T>(arg: T): T {
       return arg;
   }
   let rs = identity<string>("111")
   let rs2 = identity<number>(111)
   ```
2. 泛型类
   
   ```ts
   class MinClas<T>{
   
       public list:T[]=[];
   
       add(value:T):void{
   
           this.list.push(value);
       }
   
       min():T{  
           var minNum=this.list[0];
           for(var i=0;i<this.list.length;i++){
               if(minNum>this.list[i]){
                   minNum=this.list[i];
               }
           }
           return minNum;
       }
   }
   
   var m1=new MinClas<number>();   /*实例化类 并且制定了类的T代表的类型是number*/
   m1.add(11);
   m1.add(3);
   m1.add(2);
   alert(m1.min())
   
   
   var m2=new MinClas<string>();   /*实例化类 并且制定了类的T代表的类型是string*/
   
   m2.add('c');
   m2.add('a');
   m2.add('v');
   alert(m2.min())
   ```
3. 泛型类接口
   
   ```ts
   interface ConfigFn<T>{
       (value:T):T;
   }
   function getData<T>(value:T):T{
       return value;
   }
   var myGetData:ConfigFn<string>=getData;   
   myGetData('20');  /*正确*/
   ```
4. 类作为参数类型的泛型类
   
   ```ts
   class MysqlDb<T>{
       add(info:T):boolean{
           console.log(info);   
           return true;
       }
       updated(info:T,id:number):boolean {
           console.log(info);  
   
           console.log(id); 
   
           return true;
       }
   }
   class ArticleCate{
       title:string | undefined;
       desc:string | undefined;
       status:number | undefined;
       constructor(params:{
           title:string | undefined,
           desc:string | undefined,
           status?:number | undefined
       }){
   
           this.title=params.title;
           this.desc=params.desc;
           this.status=params.status;
   
   
       }
   }
   var a=new ArticleCate({
           title:'分类111',
           desc:'2222'  
   });
   
   a.status=0;
   var Db=new MysqlDb<ArticleCate>();
   Db.updated(a,12);
   ```
5. 泛型约束,对泛型进行约束
   
   ```ts
   interface Lengthwise {
       length: number;
   }
   
   function loggingIdentity<T extends Lengthwise>(arg: T): T {
       console.log(arg.length);  // Now we know it has a .length property, so no more error
       return arg;
   }
   loggingIdentity(3);  // Error, number doesn't have a .length property
   loggingIdentity({length: 10, value: 3});
   ```

###### 五、模块

我们可以把一些公共的功能单独抽离成一个文件作为一个模块。
模块里面的变量 函数 类等默认是私有的，如果我们要在外部访问模块里面的数据（变量、函数、类），
我们需要通过export暴露模块里面的数据（变量、函数、类...）。
暴露后我们通过 import 引入模块就可以使用模块里面暴露的数据（变量、函数、类...）。

1. 导出声明 任何声明（比如变量，函数，类，类型别名或接口）都能够通过添加`export`关键字来导出。
   
   ```ts
   export const numberRegexp = /^[0-9]+$/;
   
   export class ZipCodeValidator implements StringValidator {
       isAcceptable(s: string) {
           return s.length === 5 && numberRegexp.test(s);
       }
   }
   ```
2. 导出语句 导出语句很便利，因为我们可能需要对导出的部分重命名，所以上面的例子可以这样改写：
   
   ```ts
   class ZipCodeValidator implements StringValidator {
       isAcceptable(s: string) {
           return s.length === 5 && numberRegexp.test(s);
       }
   }
   export { ZipCodeValidator };
   export { ZipCodeValidator as mainValidator };
   ```
3. 重新导出 导出其他模块中的内容
   
   ```ts
   export {ZipCodeValidator as RegExpBasedZipCodeValidator} from "./ZipCodeValidator";
   export * from "./StringValidator"; // exports interface StringValidator
   export * from "./LettersOnlyValidator"; // exports class LettersOnlyValidator
   export * from "./ZipCodeValidator";  // exports class ZipCodeValidator
   ```
4. 导入模块中某一内容 可重命名
   
   ```ts
   import { ZipCodeValidator as ZCV} from "./ZipCodeValidator";
   
   let myValidator = new ZCV();
   ```
5. 完整导入
   
   ```ts
   import * as validator from "./ZipCodeValidator";
   let myValidator = new validator.ZipCodeValidator();
   ```

###### 六、命名空间

命名空间和模块的区别：

命名空间：内部模块，主要用于组织代码，避免命名冲突。
模    块：ts的外部模块的简称，侧重代码的复用，一个模块里可能会有多个命名空间。

1. 定义命名空间 一个模块可以有多个命名空间
   
   ```ts
   export namespace A {
       interface Animal {
   	name:string;
   	eat():void;
       }
       export class B implements Animal{
   	name:striong;
   	constructor(name:string){
   	    this.name = name
   	}
   	eat():void{
   
   	}
       }
       export a = 100
   }
   var c=new A.B('小花');
   
   c.eat();
   ```
2. 多文件
   
   ```ts
   //可以配合export使用
   import {B} from "./index"
   
   //可以使用以下方式引用命名空间
   /// <reference path="./index.ts" />
   ```

