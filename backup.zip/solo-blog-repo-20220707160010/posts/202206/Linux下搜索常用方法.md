title: Linux下搜索常用方法
date: '2022-06-10 17:45:03'
updated: '2022-06-10 17:45:03'
tags: [Linux]
permalink: /articles/2019/11/19/1574130801050.html
---
不定期更新，用到就更新


```
从当前目录开始查找所有扩展名为.log的文本文件，并找出包含”ERROR”的行

find ./ -type f -name “*.log” | xargs grep “ERROR” 
```
 
```
查找文件中包含"ERRPR"的行，并统计行数，并显示当前行号
显示行号-n 忽略大小写-i

cat file.log | grep -n "ERROR" | wc -l
```

```
监听日志输出，并监听"ERRPR"输出

tail -f file.log | grep "ERROR"
```

```
查找文件中"ERROR"前后几行

grep -C 5 foo file.log 显示file文件里匹配foo字串那行以及上下5行  
grep -B 5 foo file.log 显示foo及前5行  
grep -A 5 foo file.log 显示foo及后5行
```
