title: Git常用的一些操作
date: '2022-06-10 17:45:03'
updated: '2022-06-10 18:42:55'
tags: [Solo]
permalink: /gitOperation
---
### 撤销修改

1.未git add	git checkout -- filename  撤销文件在工作区的全部修改
2.已git add 	git reset HEAD filename --> git checkout -- filename  先将暂存区的修改还原至工作区，再撤销工作区中的修改
3.已git add同时有新的修改  git checkout -- filename  撤销文件在工作区的全部修改,但是暂存区中提交嫩然存在

### 版本回退

```
git log 或者git reflog获取历史纪录
git reset --hard HEAD^^ 或者git reset --hard HEAD~2
```

### 文件删除

```
通过rm filename 误删除文件
文件恢复 git checkout -- filename	从版本库将误删除的文件恢复
版本库删除 git rm filename -->git commit -m "" 先从版本库删除，再提交
```

### 关联远程仓库

```
git remote add origin git@github.com:michaelliao/learngit.git  产生关联
git push -u origin master	将本地分支推送至服务器
```

### 创建分支

```
git checkout -b dev 创建并切换分支
或者 git branch dev -->git checkout dev
```

### 基于远程分支创建本地关联分支

```
git checkout -b dev origin/dev
```

### 合并分支(合并某分支到当前分支)

在master下git merge dev 将dev合并到mster分支

### 删除分支

```
git branch -d dev
```

### 删除未合并的分支

```
git branch -D dev
```

### 冻结现场

```
git stash
```

### 恢复现场

```
git stash pop
```

### 添加子模块

```
git submodule <url> <path>
```

### 初始化子模块

```
git submodule init ->git submodule update
```

### git修改本地及远程分支名

**1. 本地分支重命名(还没有推送到远程)**

```
git branch -m oldName newName
```

**2. 远程分支重命名 (已经推送远程-假设本地分支和远程对应分支名称相同)**
a. 重命名远程分支对应的本地分支

```
git branch -m oldName newName
```

b. 删除远程分支

```
git push --delete origin oldName
```

c. 上传新命名的本地分支

```
git push origin newName
```

d.把修改后的本地分支与远程分支关联

```
git branch --set-upstream-to origin/newName
```

