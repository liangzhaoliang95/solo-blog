title: JS中的集合：Map
date: '2019-08-27 15:18:55'
updated: '2019-08-27 15:18:55'
tags: [JavaScript]
permalink: /JavaScriptMap
---
**`Map`** 对象保存键值对。任何值(对象或者[原始值](https://developer.mozilla.org/en-US/docs/Glossary/Primitive "原始值: In JavaScript, a primitive (primitive value, primitive data type) is data that is not an object and has no methods. There are 7 primitive data types: string, number, bigint, boolean, null, undefined, and symbol.")) 都可以作为一个键或一个值。

```
new Map([iterable])
```
### 参数
`iterable`
Iterable 可以是一个[`数组`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Array "REDIRECT Array")或者其他 iterable 对象，其元素为键值对(两个元素的数组，例如: [[ 1, 'one' ],[ 2, 'two' ]])。 每个键值对都会添加到新的 Map。`null` 会被当做 `undefined。`

## [描述](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map#描述)

一个Map对象在迭代时会根据对象中元素的插入顺序来进行 — 一个  [`for...of`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Statements/for...of "for...of语句在可迭代对象（包括 Array，Map，Set，String，TypedArray，arguments 对象等等）上创建一个迭代循环，调用自定义迭代钩子，并为每个不同属性的值执行语句") 循环在每次迭代后会返回一个形式为[key，value]的数组。

### [键的相等(Key equality)](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map#键的相等(Key_equality))

键的比较是基于 "SameValueZero" 算法：`NaN` 是与 `NaN` 相等的（虽然 `NaN !== NaN`），剩下所有其它的值是根据 `===` 运算符的结果判断是否相等。在目前的ECMAScript规范中，`-0`和`+0`被认为是相等的，尽管这在早期的草案中并不是这样。有关详细信息，请参阅[浏览器兼容性](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map#浏览器兼容性) 表中的“Value equality for -0 and 0”。

### [Objects 和 maps 的比较](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map#Objects_和_maps_的比较)

[`Objects`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Object "Object 构造函数创建一个对象包装器。") 和 `Maps` 类似的是，它们都允许你按键存取一个值、删除键、检测一个键是否绑定了值。因此（并且也没有其他内建的替代方式了）过去我们一直都把对象当成 `Maps` 使用。不过 `Maps` 和 `Objects` 有一些重要的区别，在下列情况里使用 `Map` 会是更好的选择：

* 一个`Object`的键只能是[`字符串`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/String "此页面仍未被本地化, 期待您的翻译!")或者 [`Symbols`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Symbol "Symbol()函数会返回symbol类型的值，该类型具有静态属性和静态方法。它的静态属性会暴露几个内建的成员对象；它的静态方法会暴露全局的symbol注册，且类似于内建对象类，但作为构造函数来说它并不完整，因为它不支持语法："new Symbol()"。")，但一个 `Map` 的键可以是**任意值**，包括函数、对象、基本类型。
* Map 中的键值是有序的，而添加到对象中的键则不是。因此，当对它进行遍历时，Map 对象是按插入的顺序返回键值。
* 你可以通过 `size` 属性直接获取一个 `Map` 的键值对个数，而 `Object` 的键值对个数只能手动计算。
* `Map` 可直接进行迭代，而 `Object` 的迭代需要先获取它的键数组，然后再进行迭代。
* `Object` 都有自己的原型，原型链上的键名有可能和你自己在对象上的设置的键名产生冲突。虽然 ES5 开始可以用 `map = Object.create(null)` 来创建一个没有原型的对象，但是这种用法不太常见。
* `Map` 在涉及频繁增删键值对的场景下会有些性能优势。

### [方法](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map#方法)

[`Map.prototype.clear()`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map/clear "clear()方法会移除Map对象中的所有元素。")

移除Map对象的所有键/值对 。

[`Map.prototype.delete(key)`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map/delete " delete() 方法用于移除 Map 对象中指定的元素。")

如果 `Map` 对象中存在该元素，则移除它并返回`true`；否则如果该元素不存在则返回 `false`

[`Map.prototype.entries()`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map/entries "entries() ?方法返回一个新的包含 [key, value] ?对的 Iterator ?对象，返回的迭代器的迭代顺序与 Map 对象的插入顺序相同。")

返回一个新的 `Iterator` 对象，它按插入顺序包含了Map对象中每个元素的 **`[key, value]`**`**数组**`。

[`Map.prototype.forEach(callbackFn[, thisArg])`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map/forEach "forEach() 方法将会以插入顺序对 Map 对象中的每一个键值对执行一次参数中提供的回调函数。")

按插入顺序，为 `Map`对象里的每一键值对调用一次callbackFn函数。如果为forEach提供了thisArg，它将在每次回调中作为this值。

[`Map.prototype.get(key)`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map/get "get() 方法返回某个 Map 对象中的一个指定元素。")

返回键对应的值，如果不存在，则返回undefined。

[`Map.prototype.has(key)`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map/has "方法has() 返回一个bool值，用来表明map 中是否存在指定元素.")

返回一个布尔值，表示Map实例是否包含键对应的值。

[`Map.prototype.keys()`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map/keys "keys() 返回一个新的 Iterator 对象。它包含按照顺序插入 Map 对象中每个元素的key值。")

返回一个新的 `Iterator`对象， 它按插入顺序包含了Map对象中每个元素的**键 **。

[`Map.prototype.set(key, value)`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map/set "set() 方法为 Map 对象添加或更新一个指定了键（key）和值（value）的（新）键值对。")

设置Map对象中键的值。返回该Map对象。

[`Map.prototype.values()`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map/values "一个新的 Map 可迭代对象.")

返回一个新的`Iterator`对象，它按插入顺序包含了Map对象中每个元素的**值** 。

[`Map.prototype[@@iterator]()`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map/@@iterator "@@iterator 属性的初始值与 entries 属性的初始值是同一个函数对象。")

返回一个新的`Iterator`对象，它按插入顺序包含了Map对象中每个元素的 **`[key, value]`**`**数组**`。
