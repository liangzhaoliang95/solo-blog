title: 个人DIY：分体式带屏幕键盘
date: '2021-07-08 15:17:25'
updated: '2021-08-31 19:28:34'
tags: [DIY]
permalink: /articles/2021/07/08/1625728645374.html
---
## 分体式键盘

> 采用cherry红轴
> 带OLED显示屏，可定制LOGO，输出基本信息
> 通过AUX线，使用IIC协议通信

![1.jpg](https://b3logfile.com/file/2021/07/1-3fa0b020.jpg)

[1.mp4](https://oss.xiaozao520.cn/video/crkbd/1.mp4)

![2.jpg](https://b3logfile.com/file/2021/07/2-2c8f0ebc.jpg)

[2.mp4](https://oss.xiaozao520.cn/video/crkbd/2.mp4)

![3.jpg](https://b3logfile.com/file/2021/07/3-3feb93c8.jpg)

[3.mp4](https://oss.xiaozao520.cn/video/crkbd/3.mp4)

![4.jpg](https://b3logfile.com/file/2021/07/4-c21a763d.jpg)

